import React from 'react';
import PropTypes from 'prop-types';
import './ErrorButton.css';

const ErrorButton = ({ onClick, children, variant = 'primary' }) => {
  return (
    <button 
      onClick={onClick}
      className={`error-button error-button--${variant}`}
    >
      {children}
    </button>
  );
};

ErrorButton.propTypes = {
  onClick: PropTypes.func.isRequired,
  children: PropTypes.node.isRequired,
  variant: PropTypes.oneOf(['primary', 'secondary'])
};

export default ErrorButton;
