import api from './api';
import axios from 'axios';

const authService = {
  /**
   * Login user with username and password
   * @param {string} username 
   * @param {string} password 
   * @returns {Promise} Response with tokens
   */
  login: async (username, password) => {
    try {
      const params = new URLSearchParams();
      params.append('username', username);
      params.append('password', password);
      params.append('grant_type', 'password');
      // Use shared api instance
      const response = await api.post('/auth/jwt/login', params, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Accept': 'application/json'
        }
      });
      return response.data;
    } catch (error) {
      console.error('Login error details:', error);
      if (error.response) {
        throw error;
      } else if (error.request) {
        // If there was no response from the server
        console.error('No response received from server', error.request);
        throw new Error('Could not connect to authentication server. Please check your network connection and try again.');
      } else {
        throw error;
      }
    }
  },

  /**
   * Register new user
   * @param {string} email 
   * @param {string} password 
   * @returns {Promise} Response with registration status
   */
  register: async (email, password) => {
    try {
      const response = await api.post('/auth/register', { email, password });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  /**
   * Refresh the access token using the refresh token
   * @returns {Promise} Response with new tokens
   */
  refreshToken: async () => {
    try {
      const refreshToken = localStorage.getItem('refresh_token');
      if (!refreshToken) throw new Error('No refresh token available');
      const response = await api.post('/auth/jwt/refresh', { refresh_token: refreshToken });
      const { access_token, refresh_token } = response.data;
      localStorage.setItem('access_token', access_token);
      localStorage.setItem('refresh_token', refresh_token);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  /**
   * Logout user and clear tokens
   */
  logout: async () => {
    try {
      await api.post('/auth/logout');
    } catch (error) {
      // Ignore errors on logout
    }
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
  },

  /**
   * Check if user is authenticated
   * @returns {boolean} Authentication status
   */
  isAuthenticated: () => {
    return !!localStorage.getItem('access_token');
  },
};

export default authService;
