from __future__ import annotations


from typing import TypedDict


from langgraph.graph import END, StateGraph


agent_id = "echo"
description = "Echo agent that returns the provided input and session id"


class EchoState(TypedDict, total=False):
    input: str
    session_id: str
    output: str


def _echo(state: EchoState) -> EchoState:
    text = state.get("input") or ""
    session = state.get("session_id") or ""
    return {"output": f"[session={session}] {text}"}


_graph_builder = StateGraph(EchoState)
_graph_builder.add_node("echo", _echo)
_graph_builder.set_entry_point("echo")
_graph_builder.add_edge("echo", END)
graph = _graph_builder.compile()


def invoke(payload: dict) -> dict:
    # Normalize inputs for the state
    session_id = str(payload.get("session_id") or payload.get("sessionId") or "")
    text = str(
        payload.get("input") or payload.get("message") or payload.get("query") or ""
    )
    result = graph.invoke({"input": text, "session_id": session_id}, config={})
    return {"agent": agent_id, "output": result.get("output", "")}
