// Context providers exports
export { AuthProvider, useAuthContext } from './AuthContext';
export { DatasetsProvider, useDatasetsContext } from './DatasetsContext';
export { ChatProvider, useChatContext } from './ChatContext';
export { AgentProvider, useAgentContext } from './AgentContext';

// Combined App Providers Component
import PropTypes from 'prop-types';
import { useNavigate } from 'react-router-dom';
import { AuthProvider } from './AuthContext';
import { DatasetsProvider } from './DatasetsContext';
import { ChatProvider } from './ChatContext';
import { AgentProvider } from './AgentContext';
import useAuth from '../hooks/useAuth';

const AuthProviderWrapper = ({ children }) => {
  const navigate = useNavigate();
  const authData = useAuth(navigate);

  return (
    <AuthProvider authData={authData}>
      {children}
    </AuthProvider>
  );
};

AuthProviderWrapper.propTypes = {
  children: PropTypes.node.isRequired,
};

export const AppProviders = ({ children }) => {
  return (
    <AuthProviderWrapper>
      <DatasetsProvider>
        <ChatProvider>
          <AgentProvider>
            {children}
          </AgentProvider>
        </ChatProvider>
      </DatasetsProvider>
    </AuthProviderWrapper>
  );
};

AppProviders.propTypes = {
  children: PropTypes.node.isRequired,
};
