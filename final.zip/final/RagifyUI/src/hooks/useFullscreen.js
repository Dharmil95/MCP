import { useState, useEffect, useCallback } from 'react';

export const useFullscreen = (initialState = false) => {
  const [isFullscreen, setIsFullscreen] = useState(initialState);

  const toggleFullscreen = useCallback(() => {
    setIsFullscreen(prev => !prev);
  }, []);

  const enterFullscreen = useCallback(() => {
    setIsFullscreen(true);
  }, []);

  const exitFullscreen = useCallback(() => {
    setIsFullscreen(false);
  }, []);

  // Handle escape key to exit fullscreen
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' && isFullscreen) {
        exitFullscreen();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isFullscreen, exitFullscreen]);

  // Get fullscreen styles
  const getFullscreenStyles = useCallback(() => {
    if (!isFullscreen) return {};
    
    return {
      height: '100vh',
      position: 'fixed',
      top: '0',
      left: '0',
      right: '0',
      bottom: '0',
      zIndex: '9999',
      background: 'white',
      overflow: 'hidden'
    };
  }, [isFullscreen]);

  return {
    isFullscreen,
    toggleFullscreen,
    enterFullscreen,
    exitFullscreen,
    getFullscreenStyles
  };
};
