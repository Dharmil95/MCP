import React, { forwardRef } from 'react';
import PropTypes from 'prop-types';
import './Input.css';

const Input = forwardRef(({ 
  type = 'text',
  placeholder,
  value,
  onChange,
  onFocus,
  onBlur,
  disabled = false,
  error = false,
  size = 'medium',
  fullWidth = false,
  className = '',
  icon: Icon,
  ...props 
}, ref) => {
  const inputClasses = [
    'input',
    `input--${size}`,
    error && 'input--error',
    fullWidth && 'input--full-width',
    Icon && 'input--with-icon',
    className
  ].filter(Boolean).join(' ');

  return (
    <div className="input-wrapper">
      {Icon && <Icon className="input__icon" />}
      <input
        ref={ref}
        type={type}
        className={inputClasses}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        onFocus={onFocus}
        onBlur={onBlur}
        disabled={disabled}
        {...props}
      />
    </div>
  );
});

Input.propTypes = {
  type: PropTypes.string,
  placeholder: PropTypes.string,
  value: PropTypes.string,
  onChange: PropTypes.func,
  onFocus: PropTypes.func,
  onBlur: PropTypes.func,
  disabled: PropTypes.bool,
  error: PropTypes.bool,
  size: PropTypes.oneOf(['small', 'medium', 'large']),
  fullWidth: PropTypes.bool,
  className: PropTypes.string,
  icon: PropTypes.elementType
};

Input.displayName = 'Input';

export default Input;
