import { useEffect } from 'react';
import { FaTimes } from 'react-icons/fa';
import '../styles/modal.css';

const DatasetModal = ({ 
  isOpen, 
  onClose, 
  formData, 
  onChange, 
  onSubmit, 
  isLoading, 
  error 
}) => {
  // Prevent body scrolling when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-container">
        <div className="modal-header">
          <h2>Create New Dataset</h2>
          <button className="modal-close-btn" onClick={onClose}>
            <FaTimes />
          </button>
        </div>
        
        <form onSubmit={onSubmit} className="modal-form">
          {error && (
            <div className="error-message">{error}</div>
          )}
          <div className="form-group">
            <label htmlFor="name">Dataset Name</label>
            <input type="text" id="name" name="name" value={formData.name} onChange={onChange} required />
          </div>
          <div className="form-group">
            <label htmlFor="description">Description</label>
            <textarea id="description" name="description" value={formData.description} onChange={onChange} rows="3" required></textarea>
          </div>
          <div className="form-group">
            <label htmlFor="aws_s3_folder_path">AWS S3 Folder Path</label>
            <input type="text" id="aws_s3_folder_path" name="aws_s3_folder_path" value={formData.aws_s3_folder_path} onChange={onChange} required />
          </div>
          <div className="form-group">
            <label htmlFor="aws_access_key_id">AWS Access Key ID</label>
            <input type="text" id="aws_access_key_id" name="aws_access_key_id" value={formData.aws_access_key_id} onChange={onChange} required />
          </div>
          <div className="form-group">
            <label htmlFor="aws_secret_access_key">AWS Secret Access Key</label>
            <input type="password" id="aws_secret_access_key" name="aws_secret_access_key" value={formData.aws_secret_access_key} onChange={onChange} required />
          </div>
          <div className="form-group">
            <label htmlFor="embedding_model">Embedding Model</label>
            <select id="embedding_model" name="embedding_model" value={formData.embedding_model} onChange={onChange} required>
              <option value="text-embedding-ada-002">OpenAI Ada 002</option>
              <option value="bge-m3">BGE-M3</option>
              <option value="bge-large-en-v1.5">BGE Large v1.5</option>
              <option value="e5-large-v2">E5 Large v2</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="chunking_strategy">Chunking Strategy</label>
            <select id="chunking_strategy" name="chunking_strategy" value={formData.chunking_strategy} onChange={onChange} required>
              <option value="recursive_character">Recursive Character</option>
              <option value="sliding">Sliding</option>
            </select>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="chunk_size">Chunk Size</label>
              <input type="number" id="chunk_size" name="chunk_size" value={formData.chunking_parameters?.chunk_size || ''} onChange={onChange} min="64" max="8192" required />
            </div>
            <div className="form-group">
              <label htmlFor="chunk_overlap">Chunk Overlap</label>
              <input type="number" id="chunk_overlap" name="chunk_overlap" value={formData.chunking_parameters?.chunk_overlap || ''} onChange={onChange} min="0" max="1024" required />
            </div>
          </div>
          <div className="form-group">
            <label>Allowed File Types</label>
            <div className="checkbox-group">
              {['.pdf', '.txt', '.docx', '.md'].map(type => (
                <label key={type} style={{ marginRight: '1em' }}>
                  <input
                    type="checkbox"
                    name="allowed_file_types"
                    value={type}
                    checked={formData.allowed_file_types?.includes(type) || false}
                    onChange={onChange}
                  />
                  {type.toUpperCase()}
                </label>
              ))}
            </div>
            <span className="form-hint">Select at least one file type</span>
          </div>
          <div className="modal-footer">
            <button type="button" className="secondary-btn" onClick={onClose} disabled={isLoading}>Cancel</button>
            <button type="submit" className="primary-btn" disabled={isLoading}>{isLoading ? 'Creating...' : 'Create Dataset'}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DatasetModal;
