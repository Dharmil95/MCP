"""AWS service for S3 operations and credential validation."""

import logging
from typing import Any, Dict
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.application.facades.aws_facade import AWSS3Facade
from app.domain.schemas import AWSValidationResponse

logger = logging.getLogger(__name__)


class AWSService:
    """Service for AWS S3 operations and credential validation using AWS facade"""

    def __init__(self):
        self.aws_facade = AWSS3Facade()

    async def validate_credentials(
        self,
        aws_access_key_id: str,
        aws_secret_access_key: str,
        bucket_name: str,
        folder_path: str,
    ) -> AWSValidationResponse:
        """
        Validate AWS credentials and S3 access permissions

        Args:
            aws_access_key_id: AWS Access Key ID
            aws_secret_access_key: AWS Secret Access Key
            bucket_name: S3 bucket name
            folder_path: S3 folder path

        Returns:
            AWSValidationResponse with validation status
        """
        try:
            # Check for missing or invalid credentials
            if not aws_access_key_id or not aws_secret_access_key:
                logger.warning(
                    "Missing or invalid AWS credentials during validation. Possibly legacy or decryption error."
                )
                return AWSValidationResponse(
                    status="failure",
                    message="Missing or invalid AWS credentials. Please update your dataset credentials.",
                )

            # Prepare credentials for facade
            aws_credentials = {
                "aws_access_key_id": aws_access_key_id,
                "aws_secret_access_key": aws_secret_access_key,
                "aws_region": "us-east-1",
            }

            # Use facade to validate credentials
            validation_result = await self.aws_facade.validate_credentials(
                aws_credentials
            )

            if validation_result["status"] == "failure":
                return AWSValidationResponse(
                    status="failure", message=validation_result["message"]
                )

            # Test bucket and folder access by listing files
            try:
                files = await self.aws_facade.list_bucket_files(
                    aws_credentials, bucket_name, folder_path
                )

                logger.info(
                    f"Successfully validated AWS credentials for bucket: {bucket_name}, "
                    f"found {len(files)} files in folder: {folder_path}"
                )

                return AWSValidationResponse(
                    status="success",
                    message="AWS credentials are valid and have access to the specified S3 location",
                )

            except Exception as e:
                return AWSValidationResponse(
                    status="failure", message=f"Cannot access bucket/folder: {str(e)}"
                )

        except Exception as e:
            logger.error(f"Unexpected error validating AWS credentials: {str(e)}")
            return AWSValidationResponse(
                status="failure", message=f"Unexpected error: {str(e)}"
            )

    @staticmethod
    def extract_bucket_and_path(s3_url: str) -> tuple[str, str]:
        """
        Extract bucket name and path from S3 URL

        Args:
            s3_url: S3 URL in format s3://bucket-name/path/to/folder

        Returns:
            Tuple of (bucket_name, folder_path)
        """
        if not s3_url.startswith("s3://"):
            raise ValueError("S3 URL must start with 's3://'")

        logger.info(f"Extracting bucket and path from S3 URL: '{s3_url}'")

        # Remove s3:// prefix
        path = s3_url[5:]

        # Split bucket and path
        parts = path.split("/", 1)
        bucket_name = (
            parts[0].strip().rstrip("/")
        )  # Remove any trailing slashes from bucket
        folder_path = parts[1] if len(parts) > 1 else ""

        # Remove any trailing slashes from folder_path
        folder_path = folder_path.rstrip("/")

        # Validate bucket name format
        if not bucket_name or "/" in bucket_name:
            raise ValueError(
                f"Invalid bucket name extracted: '{bucket_name}'. Bucket names cannot contain slashes."
            )

        logger.info(f"Extracted bucket: '{bucket_name}', folder: '{folder_path}'")
        return bucket_name, folder_path

    async def upload_file(
        self,
        aws_access_key_id: str,
        aws_secret_access_key: str,
        bucket_name: str,
        file_obj,
        file_name: str,
        folder_path: str = "",
    ) -> Dict[str, Any]:
        """
        Upload a file to S3 using the facade

        Args:
            aws_access_key_id: AWS Access Key ID
            aws_secret_access_key: AWS Secret Access Key
            bucket_name: S3 bucket name
            file_obj: File-like object to upload
            file_name: Name to use for the file in S3
            folder_path: S3 folder path (optional)

        Returns:
            Dict with upload status and message
        """
        try:
            # Convert file object to BytesIO if needed
            import io

            # Read the file content
            file_obj.seek(0)
            file_content = file_obj.read()
            file_bytes_io = io.BytesIO(file_content)

            # Upload using facade with the correct signature
            result = await self.aws_facade.upload_file(
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
                bucket_name=bucket_name,
                file_obj=file_bytes_io,
                file_name=file_name,
                folder_path=folder_path if folder_path else None,
            )

            return result

        except Exception as e:
            logger.error(f"Error uploading file to S3: {str(e)}")
            return {"status": "failure", "message": str(e)}
