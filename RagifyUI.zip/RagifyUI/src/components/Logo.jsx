import React from 'react';

const Logo = ({ className = '' }) => {
  return (
    <div className={`logo ${className}`}>
      <span className="logo-text">
        <span className="logo-rag">RAG</span>
        <span className="logo-ify">ify</span>
      </span>
    </div>
  );
};

export default Logo;
