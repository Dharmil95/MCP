from celery import Celery

from app.core.config import settings

# Create Celery app
celery_app = Celery(
    "ragservice",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
    include=["app.tasks"],
)

# Configure Celery
celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    result_expires=3600,
    task_track_started=True,
    task_time_limit=10 * 60,  # 10 minutes
    task_soft_time_limit=8 * 60,  # 8 minutes
    worker_prefetch_multiplier=1,
    worker_max_tasks_per_child=10,  # Restart worker after 10 tasks
    worker_max_memory_per_child=1000000,  # 1GB memory limit per child
)

# Task routing
celery_app.conf.task_routes = {
    "app.tasks.process_dataset": {"queue": "dataset_processing"},
    "app.tasks.process_file": {"queue": "file_processing"},
    "app.tasks.generate_embeddings": {"queue": "embedding_generation"},
}

# Configure queues
celery_app.conf.task_default_queue = "default"
celery_app.conf.task_queues = {
    "default": {
        "exchange": "default",
        "routing_key": "default",
    },
    "dataset_processing": {
        "exchange": "dataset_processing",
        "routing_key": "dataset_processing",
    },
    "file_processing": {
        "exchange": "file_processing",
        "routing_key": "file_processing",
    },
    "embedding_generation": {
        "exchange": "embedding_generation",
        "routing_key": "embedding_generation",
    },
}

if __name__ == "__main__":
    celery_app.start()
