"""Embedding service for generating and searching vector embeddings."""

import logging
from typing import Any, Dict, List, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.application.facades.embedding_facade import EmbeddingFacade
from app.core.config import settings

logger = logging.getLogger(__name__)


class EmbeddingService:
    """Service for generating embeddings and performing vector searches using embedding facade."""
    
    def __init__(self, api_key: Optional[str] = None):
        """Initialize the embedding service.
        
        Args:
            api_key: OpenAI API key, defaults to settings value
        """
        self.api_key = api_key or settings.openai_api_key
        self.model = "text-embedding-ada-002"
        self.embedding_facade = EmbeddingFacade(self.api_key)
    
    async def generate_embeddings(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for a list of texts using the facade.
        
        Args:
            texts: List of text strings to embed
            
        Returns:
            List of embedding vectors
        """
        try:
            return await self.embedding_facade.generate_embeddings(texts, self.model)
        except Exception as e:
            logger.error(f"Failed to generate embeddings: {str(e)}")
            raise
    
    async def generate_single_embedding(self, text: str) -> List[float]:
        """Generate embedding for a single text using the facade.
        
        Args:
            text: Text string to embed
            
        Returns:
            Embedding vector
        """
        try:
            return await self.embedding_facade.generate_single_embedding(text, self.model)
        except Exception as e:
            logger.error(f"Failed to generate single embedding: {str(e)}")
            raise
    
    async def validate_model(self, model: str) -> Dict[str, Any]:
        """Validate embedding model using the facade.
        
        Args:
            model: Model name to validate
            
        Returns:
            Validation result dictionary
        """
        return await self.embedding_facade.validate_model(model)
    
    def get_supported_models(self) -> List[str]:
        """Get list of supported models from the facade.
        
        Returns:
            List of supported model names
        """
        return self.embedding_facade.get_supported_models()
    
    async def search_chunks(
        self,
        db: AsyncSession,
        query: str,
        top_k: int = 5,
        dataset_id: Optional[str] = None,
        owner_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Search for similar text chunks using vector similarity.
        
        Args:
            db: Database session
            query: Search query text
            top_k: Number of top results to return
            dataset_id: Optional dataset ID to filter by
            owner_id: Optional owner ID to filter by
            
        Returns:
            List of search results with similarity scores
        """
        try:
            # Generate embedding for the query
            query_embedding = await self.generate_embeddings([query])
            query_embedding = query_embedding[0]
            
            # Build SQL for searching chunks
            sql_lines = [
                "SELECT ev.dataset_object_id, dobj.file_name, ev.chunk_text, "
                "(ev.embedding <-> cast(:query_embedding AS vector)) AS similarity_score",
                "FROM embedding_vectors ev",
                "JOIN dataset_objects dobj ON ev.dataset_object_id = dobj.id",
            ]
            
            # Convert embedding to PostgreSQL vector format
            vec_str = "[" + ",".join(map(str, query_embedding)) + "]"
            params = {"query_embedding": vec_str, "top_k": top_k}
            
            # Add filtering conditions
            if owner_id:
                sql_lines.append("JOIN datasets ds ON dobj.dataset_id = ds.id")
                sql_lines.append("WHERE ds.owner_id = :owner_id")
                params["owner_id"] = str(owner_id)
            elif dataset_id:
                sql_lines.append("WHERE dobj.dataset_id = :dataset_id")
                params["dataset_id"] = str(dataset_id)
            
            # Order by similarity and limit results
            sql_lines.append("ORDER BY similarity_score ASC LIMIT :top_k")
            
            # Execute the query
            base_sql = "\n".join(sql_lines)
            result = await db.execute(text(base_sql), params)
            rows = result.fetchall()
            
            # Format results
            return [
                {
                    "dataset_object_id": str(row.dataset_object_id),
                    "file_name": row.file_name,
                    "chunk_text": row.chunk_text,
                    "similarity_score": float(row.similarity_score),
                }
                for row in rows
            ]
            
        except Exception as e:
            logger.error(f"Failed to search chunks: {str(e)}")
            raise
    
    async def store_embeddings(
        self,
        db: AsyncSession,
        dataset_object_id: str,
        text_chunks: List[str],
        metadata_list: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        """Store embeddings for text chunks in the database.
        
        Args:
            db: Database session
            dataset_object_id: ID of the dataset object
            text_chunks: List of text chunks to embed and store
            metadata_list: Optional metadata for each chunk
        """
        try:
            # Generate embeddings for all chunks
            embeddings = await self.generate_embeddings(text_chunks)
            
            # Prepare metadata list if not provided
            if metadata_list is None:
                metadata_list = [{}] * len(text_chunks)
            
            # Store each embedding
            for i, (chunk_text, embedding, metadata) in enumerate(zip(
                text_chunks, embeddings, metadata_list
            )):
                # Convert embedding to PostgreSQL vector format
                vec_str = "[" + ",".join(map(str, embedding)) + "]"
                
                # Insert embedding vector
                insert_sql = """
                    INSERT INTO embedding_vectors 
                    (dataset_object_id, chunk_text, chunk_index, embedding, file_metadata)
                    VALUES (:dataset_object_id, :chunk_text, :chunk_index, 
                           cast(:embedding AS vector), :metadata)
                """
                
                await db.execute(text(insert_sql), {
                    "dataset_object_id": dataset_object_id,
                    "chunk_text": chunk_text,
                    "chunk_index": i,
                    "embedding": vec_str,
                    "metadata": metadata,
                })
            
            await db.commit()
            logger.info(f"Stored {len(embeddings)} embeddings for dataset object {dataset_object_id}")
            
        except Exception as e:
            logger.error(f"Failed to store embeddings: {str(e)}")
            await db.rollback()
            raise
