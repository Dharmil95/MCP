"""Global exception handlers for the FastAPI application."""

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.application.exceptions import (
    ApplicationException,
    DatasetProcessingError,
    DatasetValidationError,
    ForbiddenError,
    InvalidCredentialsError,
    NotFoundError,
    UnauthorizedError,
    UserInactiveError,
    ValidationError,
)


def register_exception_handlers(app: FastAPI) -> None:
    """Register global exception handlers for the application."""
    
    @app.exception_handler(NotFoundError)
    async def not_found_handler(request: Request, exc: NotFoundError):
        return JSONResponse(
            status_code=404,
            content={
                "error": "Not Found",
                "message": exc.message,
                "code": exc.code,
            }
        )
    
    @app.exception_handler(UnauthorizedError)
    async def unauthorized_handler(request: Request, exc: UnauthorizedError):
        return JSONResponse(
            status_code=401,
            content={
                "error": "Unauthorized",
                "message": exc.message,
                "code": exc.code,
            }
        )
    
    @app.exception_handler(ForbiddenError)
    async def forbidden_handler(request: Request, exc: ForbiddenError):
        return JSONResponse(
            status_code=403,
            content={
                "error": "Forbidden",
                "message": exc.message,
                "code": exc.code,
            }
        )
    
    @app.exception_handler(ValidationError)
    async def validation_error_handler(request: Request, exc: ValidationError):
        return JSONResponse(
            status_code=400,
            content={
                "error": "Validation Error",
                "message": exc.message,
                "code": exc.code,
            }
        )
    
    @app.exception_handler(DatasetProcessingError)
    async def dataset_processing_handler(request: Request, exc: DatasetProcessingError):
        return JSONResponse(
            status_code=422,
            content={
                "error": "Processing Error",
                "message": exc.message,
                "code": exc.code,
            }
        )
    
    @app.exception_handler(ApplicationException)
    async def application_exception_handler(request: Request, exc: ApplicationException):
        return JSONResponse(
            status_code=400,
            content={
                "error": "Application Error",
                "message": exc.message,
                "code": exc.code or "APPLICATION_ERROR",
            }
        )
    
    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        # Safely convert errors to serializable format
        try:
            error_details = []
            for error in exc.errors():
                if isinstance(error, dict):
                    # Convert any non-serializable values to strings
                    safe_error = {}
                    for key, value in error.items():
                        try:
                            # Try to serialize the value
                            import json
                            json.dumps(value)
                            safe_error[key] = value
                        except (TypeError, ValueError):
                            # If it can't be serialized, convert to string
                            safe_error[key] = str(value)
                    error_details.append(safe_error)
                else:
                    error_details.append(str(error))
        except Exception:
            # Fallback: convert all errors to strings
            error_details = [str(error) for error in exc.errors()]
        
        return JSONResponse(
            status_code=422,
            content={
                "error": "Validation Error",
                "message": "Request validation failed",
                "details": error_details,
            }
        )
    
    @app.exception_handler(StarletteHTTPException)
    async def http_exception_handler(request: Request, exc: StarletteHTTPException):
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "error": "HTTP Error",
                "message": exc.detail,
            }
        )
    
    @app.exception_handler(ValueError)
    async def value_error_handler(request: Request, exc: ValueError):
        return JSONResponse(
            status_code=400,
            content={
                "error": "Validation Error",
                "message": str(exc),
                "error_code": "VALUE_ERROR",
            }
        )
