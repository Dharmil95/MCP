from typing import Any, Dict, Protocol


class Agent(Protocol):
    """Lightweight protocol that agent modules should satisfy.

    Implementations can be simple callables or objects with an `invoke` method.
    This file is intentionally minimal so agents don't need heavy deps to import.
    """

    id: str
    description: str

    def invoke(self, payload: Dict[str, Any]) -> Dict[str, Any]: ...
