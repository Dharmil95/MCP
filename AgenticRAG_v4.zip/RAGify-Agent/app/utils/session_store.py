from __future__ import annotations

import threading
from typing import Dict, Optional


class SessionStore:
    """Thread-safe in-memory session store.

    Replace with Redis or database for production multi-instance setups.
    """

    _lock = threading.RLock()
    _store: Dict[str, Dict] = {}

    @classmethod
    def create_session(cls, session_id: str) -> None:
        with cls._lock:
            cls._store[session_id] = {}

    @classmethod
    def get_session(cls, session_id: str) -> Optional[Dict]:
        with cls._lock:
            return cls._store.get(session_id)

    @classmethod
    def update_session(cls, session_id: str, data: Dict) -> None:
        with cls._lock:
            state = cls._store.setdefault(session_id, {})
            state.update(data)


