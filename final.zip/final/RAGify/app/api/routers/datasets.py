import logging
from typing import List
from uuid import UUID

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import (
    get_async_session,
    get_current_user,
    get_dataset_facade,
    get_dataset_service,
)
from app.application.facades.dataset_facade import DatasetFacade
from app.application.services.dataset_service import DatasetService
from app.application.dto.dataset_dto import (
    CreateDatasetDTO,
    UpdateDatasetDTO,
    DatasetDTO,
)
from app.application.utils.logging_utils import add_log_context
from app.domain.models import User
from app.domain.schemas import (
    DatasetCreate,
    DatasetObjectRead,
    DatasetRead,
    DatasetStatus,
    DatasetUpdate,
    SuccessResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/datasets", tags=["datasets"])


@router.post("", response_model=DatasetRead, status_code=status.HTTP_201_CREATED)
async def create_dataset(
    dataset_data: DatasetCreate,
    request: Request,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    dataset_facade: DatasetFacade = Depends(get_dataset_facade),
):
    """
    Create a new dataset with S3 integration
    Example: {"aws_s3_folder_path": "s3://ragify-bucket/chapter_4709_barber/", ...}
    """
    try:
        # Add context for logging
        add_log_context(
            request,
            operation="create",
            dataset_name=dataset_data.name,
            s3_path=dataset_data.aws_s3_folder_path,
        )

        # Convert Pydantic schema to DTO
        create_dto = CreateDatasetDTO(
            name=dataset_data.name,
            description=dataset_data.description,
            aws_s3_folder_path=dataset_data.aws_s3_folder_path,
            aws_access_key_id=dataset_data.aws_access_key_id,
            aws_secret_access_key=dataset_data.aws_secret_access_key,
            embedding_model=dataset_data.embedding_model,
            chunking_strategy=dataset_data.chunking_strategy,
            allowed_file_types=dataset_data.allowed_file_types,
            owner_id=current_user.id,
        )

        logger.info(f"Creating dataset with S3 path: {dataset_data.aws_s3_folder_path}")

        # Create dataset using facade (includes AWS validation)
        dataset_dto = await dataset_facade.create_dataset(create_dto)

        # Prepare for background processing
        aws_credentials = {
            "aws_access_key_id": dataset_data.aws_access_key_id,
            "aws_secret_access_key": dataset_data.aws_secret_access_key,
        }

        # Trigger Celery task for processing
        from app.tasks import process_dataset

        task = process_dataset.delay(
            dataset_id=str(dataset_dto.id), aws_credentials=aws_credentials
        )

        logger.info(
            f"Dataset {dataset_dto.id} created and processing started (task: {task.id})"
        )

        # Convert DTO back to schema for response
        return DatasetRead(
            id=dataset_dto.id,
            owner_id=dataset_dto.owner_id,
            name=dataset_dto.name,
            description=dataset_dto.description,
            aws_s3_folder_path=dataset_dto.aws_s3_folder_path,
            embedding_model=dataset_dto.embedding_model,
            chunking_strategy=dataset_dto.chunking_strategy,
            chunking_parameters={},  # Default
            allowed_file_types=dataset_dto.allowed_file_types,
            status="processing",  # Default initial status
            created_at=dataset_dto.created_at,
            updated_at=dataset_dto.updated_at,
        )

    except ValueError as e:
        logger.error(f"Dataset validation error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid dataset configuration: {str(e)}",
        )
    except Exception as e:
        logger.error(f"Dataset creation error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Dataset creation failed",
        )


@router.get("", response_model=List[DatasetRead])
async def get_datasets(
    request: Request,
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_current_user),
    dataset_facade: DatasetFacade = Depends(get_dataset_facade),
):
    """
    Get all datasets owned by the current user
    """
    try:
        # Add context for logging
        add_log_context(
            request,
            operation="list",
            pagination={"skip": skip, "limit": limit},
            user_id=str(current_user.id),
        )
        dataset_dtos = await dataset_facade.list_datasets(
            owner_id=current_user.id, limit=limit, offset=skip
        )

        # Convert DTOs to schema response
        datasets = []
        for dto in dataset_dtos:
            datasets.append(
                DatasetRead(
                    id=dto.id,
                    owner_id=dto.owner_id,
                    name=dto.name,
                    description=dto.description,
                    aws_s3_folder_path=dto.aws_s3_folder_path,
                    embedding_model=dto.embedding_model,
                    chunking_strategy=dto.chunking_strategy,
                    chunking_parameters={},  # Default
                    allowed_file_types=dto.allowed_file_types,
                    status="active",  # Default
                    created_at=dto.created_at,
                    updated_at=dto.updated_at,
                )
            )

        return datasets

    except Exception as e:
        logger.error(f"Error getting datasets: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get datasets",
        )


@router.get("/{dataset_id}", response_model=DatasetRead)
async def get_dataset(
    dataset_id: UUID,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session),
    dataset_service: DatasetService = Depends(get_dataset_service),
):
    """
    Get a specific dataset by ID
    """
    try:
        # Add context for logging
        add_log_context(
            request,
            operation="read",
            resource_id=str(dataset_id),
            user_id=str(current_user.id),
        )
        dataset = await dataset_service.get_dataset_by_id(
            db=db, dataset_id=dataset_id, owner_id=current_user.id
        )

        if not dataset:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found"
            )

        return DatasetRead.from_orm(dataset)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting dataset: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get dataset",
        )


@router.put("/{dataset_id}", response_model=DatasetRead)
async def update_dataset(
    dataset_id: UUID,
    dataset_data: DatasetUpdate,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session),
    dataset_service: DatasetService = Depends(get_dataset_service),
):
    """
    Update an existing dataset
    """
    try:
        # Add context for logging
        add_log_context(
            request,
            operation="update",
            resource_id=str(dataset_id),
            user_id=str(current_user.id),
            updated_fields=dataset_data.dict(exclude_unset=True).keys(),
        )
        dataset = await dataset_service.update_dataset(
            db=db,
            dataset_id=dataset_id,
            dataset_data=dataset_data,
            owner_id=current_user.id,
        )

        if not dataset:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found"
            )

        return DatasetRead.from_orm(dataset)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating dataset: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update dataset",
        )


@router.delete("/{dataset_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_dataset(
    dataset_id: UUID,
    request: Request,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session),
    dataset_service: DatasetService = Depends(get_dataset_service),
):
    """
    Delete a dataset and trigger cleanup
    """
    try:
        # Add context for logging
        add_log_context(
            request,
            operation="delete",
            resource_id=str(dataset_id),
            user_id=str(current_user.id),
        )
        success = await dataset_service.delete_dataset(
            db=db, dataset_id=dataset_id, owner_id=current_user.id
        )

        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found"
            )

        logger.info(f"Dataset {dataset_id} deleted")
        return None

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting dataset: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete dataset",
        )


@router.get("/{dataset_id}/status", response_model=DatasetStatus)
async def get_dataset_status(
    dataset_id: UUID,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session),
    dataset_service: DatasetService = Depends(get_dataset_service),
):
    """
    Get dataset processing status
    """
    try:
        # Add context for logging
        add_log_context(
            request,
            operation="status_check",
            resource_id=str(dataset_id),
            user_id=str(current_user.id),
        )
        status_info = await dataset_service.get_dataset_status(
            db=db, dataset_id=dataset_id, owner_id=current_user.id
        )

        if not status_info:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found"
            )

        return status_info

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting dataset status: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get dataset status",
        )


@router.post("/{dataset_id}/process", status_code=202)
async def process_dataset_endpoint(
    dataset_id: UUID,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session),
    dataset_service: DatasetService = Depends(get_dataset_service),
):
    """Trigger processing (or reprocessing) for a dataset."""
    # Add context for logging
    add_log_context(
        request,
        operation="process",
        resource_id=str(dataset_id),
        user_id=str(current_user.id),
    )
    # Get AWS credentials for the dataset
    creds = await dataset_service.get_aws_credentials(db, dataset_id, current_user.id)
    if not creds:
        raise HTTPException(
            status_code=404, detail="Dataset not found or not owned by user"
        )
    # Trigger Celery task
    from app.tasks import process_dataset

    task = process_dataset.delay(dataset_id=str(dataset_id), aws_credentials=creds)
    return {"message": "Processing started", "task_id": task.id}
