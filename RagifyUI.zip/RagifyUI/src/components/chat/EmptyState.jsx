import React from 'react';
import PropTypes from 'prop-types';
import './EmptyState.css';

const EmptyState = ({
  icon: Icon,
  title,
  description,
  className = ''
}) => {
  return (
    <div className={`empty-state ${className}`}>
      {Icon && (
        <div className="empty-state__icon">
          <Icon />
        </div>
      )}
      <h3 className="empty-state__title">{title}</h3>
      {description && (
        <p className="empty-state__description">{description}</p>
      )}
    </div>
  );
};

EmptyState.propTypes = {
  icon: PropTypes.elementType,
  title: PropTypes.string.isRequired,
  description: PropTypes.string,
  className: PropTypes.string
};

export default EmptyState;
