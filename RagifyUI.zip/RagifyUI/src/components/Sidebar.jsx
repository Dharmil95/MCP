import React from 'react';
import { FaChartBar, FaDatabase, FaSearch, FaSignOutAlt, FaComments, FaChevronRight } from 'react-icons/fa';

const Sidebar = ({ activeTab, setActiveTab, handleLogout, currentAgentSession }) => {
  return (
    <div 
      data-sidebar="root"
      style={{
        width: '220px',
        height: '100vh',
        backgroundColor: '#ffffff',
        borderRight: '1px solid #e5e7eb',
        display: 'flex',
        flexDirection: 'column',
        position: 'fixed',
        left: 0,
        top: 0,
        zIndex: 100
      }}
    >
      {/* Header */}
      <div 
        data-sidebar="header"
        style={{
          padding: '20px 16px',
          borderBottom: '1px solid #e5e7eb',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}
      >
        <h2 style={{
          margin: 0,
          fontSize: '1.25rem',
          fontWeight: '700',
          color: '#1f2937',
          letterSpacing: '0.025em'
        }}>
          RAGify
        </h2>
      </div>

      {/* Navigation */}
      <nav 
        data-sidebar="navigation"
        style={{
          flex: 1,
          padding: '12px 8px',
          overflowY: 'auto'
        }}
      >
        <div 
          data-sidebar="group-content" 
          style={{
            width: '100%',
            fontSize: '0.875rem'
          }}
        >
          <ul 
            data-sidebar="menu" 
            style={{
              display: 'flex',
              width: '100%',
              minWidth: 0,
              flexDirection: 'column',
              gap: '4px',
              listStyle: 'none',
              padding: 0,
              margin: 0
            }}
          >
            {/* Dashboard */}
            <li 
              data-sidebar="menu-item" 
              className="group/menu-item relative"
              style={{
                position: 'relative'
              }}
            >
              <a 
                data-sidebar="menu-button"
                data-size="default"
                data-active={activeTab === 'dashboard' ? 'true' : 'false'}
                onClick={() => setActiveTab('dashboard')}
                style={{
                  display: 'flex',
                  width: '100%',
                  alignItems: 'center',
                  gap: '8px',
                  overflow: 'hidden',
                  borderRadius: '6px',
                  padding: '8px',
                  textAlign: 'left',
                  outline: 'none',
                  transition: 'all 0.2s ease',
                  cursor: 'pointer',
                  backgroundColor: activeTab === 'dashboard' ? '#f3f4f6' : 'transparent',
                  color: activeTab === 'dashboard' ? '#1f2937' : '#6b7280',
                  fontWeight: activeTab === 'dashboard' ? '500' : '400',
                  fontSize: '0.875rem',
                  height: '32px',
                  textDecoration: 'none'
                }}
                onMouseEnter={(e) => {
                  if (activeTab !== 'dashboard') {
                    e.target.style.backgroundColor = '#f9fafb';
                    e.target.style.color = '#374151';
                  }
                }}
                onMouseLeave={(e) => {
                  if (activeTab !== 'dashboard') {
                    e.target.style.backgroundColor = 'transparent';
                    e.target.style.color = '#6b7280';
                  }
                }}
              >
                <FaChartBar style={{
                  width: '16px',
                  height: '16px',
                  flexShrink: 0,
                  color: 'currentColor'
                }} />
                <span style={{
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis'
                }}>
                  Dashboard
                </span>
              </a>
            </li>

            {/* Datasets */}
            <li 
              data-sidebar="menu-item" 
              className="group/menu-item relative"
              style={{
                position: 'relative'
              }}
            >
              <a 
                data-sidebar="menu-button"
                data-size="default"
                data-active={activeTab === 'datasets' ? 'true' : 'false'}
                onClick={() => setActiveTab('datasets')}
                style={{
                  display: 'flex',
                  width: '100%',
                  alignItems: 'center',
                  gap: '8px',
                  overflow: 'hidden',
                  borderRadius: '6px',
                  padding: '8px',
                  textAlign: 'left',
                  outline: 'none',
                  transition: 'all 0.2s ease',
                  cursor: 'pointer',
                  backgroundColor: activeTab === 'datasets' ? '#f3f4f6' : 'transparent',
                  color: activeTab === 'datasets' ? '#1f2937' : '#6b7280',
                  fontWeight: activeTab === 'datasets' ? '500' : '400',
                  fontSize: '0.875rem',
                  height: '32px',
                  textDecoration: 'none'
                }}
                onMouseEnter={(e) => {
                  if (activeTab !== 'datasets') {
                    e.target.style.backgroundColor = '#f9fafb';
                    e.target.style.color = '#374151';
                  }
                }}
                onMouseLeave={(e) => {
                  if (activeTab !== 'datasets') {
                    e.target.style.backgroundColor = 'transparent';
                    e.target.style.color = '#6b7280';
                  }
                }}
              >
                <FaDatabase style={{
                  width: '16px',
                  height: '16px',
                  flexShrink: 0,
                  color: 'currentColor'
                }} />
                <span style={{
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis'
                }}>
                  Datasets
                </span>
              </a>
            </li>

            {/* Search */}
            <li 
              data-sidebar="menu-item" 
              className="group/menu-item relative"
              style={{
                position: 'relative'
              }}
            >
              <a 
                data-sidebar="menu-button"
                data-size="default"
                data-active={activeTab === 'search' ? 'true' : 'false'}
                onClick={() => setActiveTab('search')}
                style={{
                  display: 'flex',
                  width: '100%',
                  alignItems: 'center',
                  gap: '8px',
                  overflow: 'hidden',
                  borderRadius: '6px',
                  padding: '8px',
                  textAlign: 'left',
                  outline: 'none',
                  transition: 'all 0.2s ease',
                  cursor: 'pointer',
                  backgroundColor: activeTab === 'search' ? '#f3f4f6' : 'transparent',
                  color: activeTab === 'search' ? '#1f2937' : '#6b7280',
                  fontWeight: activeTab === 'search' ? '500' : '400',
                  fontSize: '0.875rem',
                  height: '32px',
                  textDecoration: 'none'
                }}
                onMouseEnter={(e) => {
                  if (activeTab !== 'search') {
                    e.target.style.backgroundColor = '#f9fafb';
                    e.target.style.color = '#374151';
                  }
                }}
                onMouseLeave={(e) => {
                  if (activeTab !== 'search') {
                    e.target.style.backgroundColor = 'transparent';
                    e.target.style.color = '#6b7280';
                  }
                }}
              >
                <FaSearch style={{
                  width: '16px',
                  height: '16px',
                  flexShrink: 0,
                  color: 'currentColor'
                }} />
                <span style={{
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis'
                }}>
                  Search
                </span>
              </a>
            </li>

            {/* Agent Chat */}
            <li 
              data-sidebar="menu-item" 
              className="group/menu-item relative"
              style={{
                position: 'relative'
              }}
            >
              <a 
                data-sidebar="menu-button"
                data-size="default"
                data-active={activeTab === 'agent-chat' ? 'true' : 'false'}
                onClick={() => setActiveTab('agent-chat')}
                style={{
                  display: 'flex',
                  width: '100%',
                  alignItems: 'center',
                  gap: '8px',
                  overflow: 'hidden',
                  borderRadius: '6px',
                  padding: '8px',
                  textAlign: 'left',
                  outline: 'none',
                  transition: 'all 0.2s ease',
                  cursor: 'pointer',
                  backgroundColor: activeTab === 'agent-chat' ? '#f3f4f6' : 'transparent',
                  color: activeTab === 'agent-chat' ? '#1f2937' : '#6b7280',
                  fontWeight: activeTab === 'agent-chat' ? '500' : '400',
                  fontSize: '0.875rem',
                  height: '32px',
                  textDecoration: 'none'
                }}
                onMouseEnter={(e) => {
                  if (activeTab !== 'agent-chat') {
                    e.target.style.backgroundColor = '#f9fafb';
                    e.target.style.color = '#374151';
                  }
                }}
                onMouseLeave={(e) => {
                  if (activeTab !== 'agent-chat') {
                    e.target.style.backgroundColor = 'transparent';
                    e.target.style.color = '#6b7280';
                  }
                }}
              >
                <FaComments style={{
                  width: '16px',
                  height: '16px',
                  flexShrink: 0,
                  color: 'currentColor'
                }} />
                <span style={{
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis'
                }}>
                  Agent Chat
                </span>
              </a>
            </li>
          </ul>
        </div>
      </nav>

      {/* Active Chat Preview */}
      {currentAgentSession && (
        <div 
          data-sidebar="chat-preview"
          style={{
            margin: '12px 8px',
            backgroundColor: '#f9fafb',
            borderRadius: '6px',
            border: '1px solid #e5e7eb',
            overflow: 'hidden'
          }}
        >
          <div 
            onClick={() => setActiveTab('agent-chat')}
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '8px 12px',
              backgroundColor: '#f3f4f6',
              cursor: 'pointer',
              transition: 'background-color 0.2s ease'
            }}
            onMouseEnter={(e) => {
              e.target.style.backgroundColor = '#e5e7eb';
            }}
            onMouseLeave={(e) => {
              e.target.style.backgroundColor = '#f3f4f6';
            }}
          >
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              fontSize: '0.875rem',
              fontWeight: '500',
              color: '#1f2937'
            }}>
              <FaComments style={{ color: '#6b7280', fontSize: '14px' }} />
              <span style={{
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis'
              }}>
                {currentAgentSession.agent?.name || currentAgentSession.agent?.id}
              </span>
            </div>
            <FaChevronRight style={{ color: '#9ca3af', fontSize: '12px' }} />
          </div>
        </div>
      )}

      {/* Footer */}
      <div 
        data-sidebar="footer"
        style={{
          padding: '12px 8px',
          borderTop: '1px solid #e5e7eb',
          marginTop: 'auto'
        }}
      >
        <button 
          onClick={handleLogout}
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '100%',
            padding: '8px 12px',
            backgroundColor: '#fef2f2',
            border: '1px solid #fecaca',
            borderRadius: '6px',
            color: '#dc2626',
            cursor: 'pointer',
            fontWeight: '500',
            fontSize: '0.875rem',
            transition: 'all 0.2s ease',
            height: '32px'
          }}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#fee2e2';
            e.target.style.transform = 'translateY(-1px)';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fef2f2';
            e.target.style.transform = 'translateY(0)';
          }}
        >
          <FaSignOutAlt style={{
            color: '#dc2626',
            fontSize: '14px',
            marginRight: '8px'
          }} />
          Logout
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
