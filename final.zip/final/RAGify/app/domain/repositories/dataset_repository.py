"""Dataset repository interface."""

from abc import ABC, abstractmethod
from typing import List, Optional
from uuid import UUID

from ..models.dataset import Dataset


class DatasetRepository(ABC):
    """Abstract repository interface for Dataset entities."""

    @abstractmethod
    async def get_by_id(self, dataset_id: UUID) -> Optional[Dataset]:
        """Get dataset by ID."""
        pass

    @abstractmethod
    async def get_by_owner_id(
        self, owner_id: UUID, skip: int = 0, limit: int = 100
    ) -> List[Dataset]:
        """Get datasets by owner ID with pagination."""
        pass

    @abstractmethod
    async def create(self, dataset: Dataset) -> Dataset:
        """Create a new dataset."""
        pass

    @abstractmethod
    async def update(self, dataset: Dataset) -> Dataset:
        """Update an existing dataset."""
        pass

    @abstractmethod
    async def delete(self, dataset_id: UUID) -> bool:
        """Delete a dataset by ID."""
        pass

    @abstractmethod
    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Dataset]:
        """Get all datasets with pagination."""
        pass

    @abstractmethod
    async def get_by_status(
        self, status: str, skip: int = 0, limit: int = 100
    ) -> List[Dataset]:
        """Get datasets by status with pagination."""
        pass

    @abstractmethod
    async def exists_by_name_and_owner(self, name: str, owner_id: UUID) -> bool:
        """Check if dataset exists by name and owner."""
        pass
