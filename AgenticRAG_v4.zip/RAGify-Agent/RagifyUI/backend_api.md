# 🧠 RAG‑as‑a‑Service API

## Authentication

### `POST /api/v1/auth/register`

**Summary**: Register a new user account
**Request Body (JSON)**:

```json
{
  "email": "user@example.com",
  "password": "securePassword"
}
```

**Responses**:

* `201 Created`: Returns `UserRead` schema with user ID, email, timestamps.
* `422 Validation Error`: Returns validation errors.

---

### `POST /api/v1/auth/jwt/login`

**Summary**: Obtain access & refresh tokens
**Request Body (form-urlencoded)**:

```
grant_type=password&username=user@example.com&password=securePassword
```

**Responses**:

* `200 OK`: `TokenResponse` includes `access_token`, `expires_in`, `refresh_token`.
* `422 Validation Error`

---

### `POST /api/v1/auth/jwt/refresh`

**Summary**: Refresh access token
**Request Body (JSON)**:

```json
{ "refresh_token": "..." }
```

**Responses**:

* `200 OK`: New `TokenResponse`
* `422 Validation Error`

---

### `POST /api/v1/auth/logout`

**Summary**: Logout and invalidate session
**Security**: **Bearer**
**Responses**:

* `204 No Content`

---

## Users

### `GET /api/v1/users/me`

**Summary**: Get current user profile
**Security**: **Bearer**
**Responses**:

* `200 OK`: Returns `UserRead`
* `401 Unauthorized`: Invalid or missing token

---

## Datasets

### `POST /api/v1/datasets`

**Summary**: Create a dataset
**Security**: **Bearer**
**Request Body (JSON)**:

```json
{
  "name": "My Dataset",
  "description": "Details...",
  "embedding_model": "text-embedding-ada-002",
  "chunking_strategy": "sliding",
  "chunking_parameters": { "chunk_size": 512, "chunk_overlap": 50 },
  "allowed_file_types": [".pdf", ".txt"],
  "aws_s3_folder_path": "s3://my-bucket/docs/",
  "aws_access_key_id": "...",
  "aws_secret_access_key": "..."
}
```

**Responses**:

* `201 Created`: Returns `DatasetRead`
* `422 Validation Error`

---

### `GET /api/v1/datasets`

**Summary**: List user’s datasets
**Security**: **Bearer**
**Query Parameters**:

* `skip` (int, default `0`)
* `limit` (int, default `100`)
  **Responses**:
* `200 OK`: Array of `DatasetRead`
* `422 Validation Error`

---

### `GET /api/v1/datasets/{dataset_id}`

**Summary**: Get a specific dataset
**Security**: **Bearer**
**Parameters**: `dataset_id` (UUID)
**Responses**:

* `200 OK`: `DatasetRead`
* `422 Validation Error`

---

### `PUT /api/v1/datasets/{dataset_id}`

**Summary**: Update a dataset
**Security**: **Bearer**
**Parameters**: `dataset_id` (UUID)
**Request Body (JSON)**: Partial fields of `DatasetUpdate`
**Responses**:

* `200 OK`: `DatasetRead`
* `422 Validation Error`

---

### `DELETE /api/v1/datasets/{dataset_id}`

**Summary**: Delete a dataset
**Security**: **Bearer**
**Parameters**: `dataset_id` (UUID)
**Responses**:

* `204 No Content`
* `422 Validation Error`

---

### `GET /api/v1/datasets/{dataset_id}/status`

**Summary**: Check dataset processing status
**Security**: **Bearer**
**Parameters**: `dataset_id` (UUID)
**Responses**:

* `200 OK`: `DatasetStatus` (includes counters & status)
* `422 Validation Error`

---

## Dataset Objects

### `GET /api/v1/dataset_objects/{dataset_id}`

**Summary**: List files in a dataset
**Security**: **Bearer**
**Parameters**: `dataset_id` (UUID)
**Responses**:

* `200 OK`: Array of `DatasetObjectRead`
* `422 Validation Error`

---

### `GET /api/v1/dataset_objects/object/{dataset_object_id}`

**Summary**: Retrieve a specific file/object
**Security**: **Bearer**
**Parameters**: `dataset_object_id` (UUID)
**Responses**:

* `200 OK`: `DatasetObjectRead`
* `422 Validation Error`

---

## AWS

### `POST /api/v1/aws/validate-credentials`

**Summary**: Validate user-provided AWS credentials
**Security**: **Bearer**
**Request Body (JSON)**:

```json
{
  "aws_access_key_id": "...",
  "aws_secret_access_key": "...",
  "aws_s3_bucket_name": "...",
  "aws_s3_folder_path": "folder/path/"
}
```

**Responses**:

* `200 OK`: `AWSValidationResponse` (`status`: "success" or "failure", `message`)
* `422 Validation Error`

---

## Chat

### `POST /api/v1/chat/all`

**Summary**: Chat using all user datasets
**Security**: **Bearer**
**Request Body (JSON)**:

```json
{ "query": "Explain E=mc^2", "top_k": 5 }
```

**Responses**:

* `200 OK`: `ChatResponse`
* `422 Validation Error`

---

### `POST /api/v1/chat/{dataset_id}`

**Summary**: Chat within a specific dataset
**Security**: **Bearer**
**Parameters**: `dataset_id` (UUID)
**Request Body (JSON)**: Same as above
**Responses**:

* `200 OK`: `ChatResponse`
* `422 Validation Error`

---

## Health Check

### `GET /health`

**Summary**: Server status endpoint
**Responses**:

* `200 OK`: Returns `{ "status": "healthy", "timestamp": "..." }`

---

### 🔧 Usage Tips

* All authenticated routes use **Bearer JWT** via OAuth2 password flow.
* **DatasetRead**, **DatasetObjectRead**, **DatasetStatus**, **ChatResponse**, and other schemas are defined under `components/schemas`.
* FastAPI exposes interactive Swagger at `/docs` and ReDoc at `/redoc` for self-service exploration.

---
