import { useState, useEffect, useCallback, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import datasetService from '../services/datasetService';
import LoadingScreen from '../components/LoadingScreen';
import '../styles/buttons.css';
import '../styles/dataset-files.css';

const DatasetFilesPage = () => {
  const { datasetId } = useParams();
  const navigate = useNavigate();
  const [files, setFiles] = useState([]);
  const [dataset, setDataset] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [pollingInterval, setPollingInterval] = useState(null);

  // Check if any files are still processing or pending
  const hasProcessingFiles = useMemo(() => {
    return files.some(file => file.status === 'processing' || file.status === 'pending');
  }, [files]);

  useEffect(() => {
    fetchDatasetData();
  }, [datasetId]);

  // Set up polling for status updates when there are processing files
  useEffect(() => {
    if (hasProcessingFiles && !pollingInterval) {
      const interval = setInterval(() => {
        fetchDatasetData();
      }, 3000); // Poll every 3 seconds
      setPollingInterval(interval);
    } else if (!hasProcessingFiles && pollingInterval) {
      clearInterval(pollingInterval);
      setPollingInterval(null);
    }

    return () => {
      if (pollingInterval) {
        clearInterval(pollingInterval);
      }
    };
  }, [hasProcessingFiles, pollingInterval]);

  const fetchDatasetData = async () => {
    try {
      setError(null);

      // Fetch both dataset info and files
      const [datasetData, filesData] = await Promise.all([
        datasetService.getDatasetById(datasetId),
        datasetService.getDatasetFilesWithStatus(datasetId)
      ]);

      setDataset(datasetData);
      setFiles(filesData);
    } catch (err) {
      setError('Failed to load dataset data');
      console.error('Error fetching dataset data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    try {
      setUploading(true);
      await datasetService.uploadFileToDataset(datasetId, file);
      
      // Refresh data after upload
      await fetchDatasetData();
      
      // Clear the file input
      event.target.value = '';
    } catch (err) {
      setError('Failed to upload file');
      console.error('Error uploading file:', err);
    } finally {
      setUploading(false);
    }
  };

  const handleFileDelete = async (fileId) => {
    if (!window.confirm('Are you sure you want to delete this file?')) return;

    try {
      await datasetService.deleteFile(fileId);
      
      // Refresh data after deletion
      await fetchDatasetData();
    } catch (err) {
      setError('Failed to delete file');
      console.error('Error deleting file:', err);
    }
  };

  const formatDateTime = (dateString) => {
    if (!dateString || dateString === '1970-01-01T00:00:00Z') {
      return 'Pending...';
    }
    return new Date(dateString).toLocaleString();
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="status-icon status-icon--completed">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
            <path d="m9 11 3 3L22 4"></path>
          </svg>
        );
      case 'processing':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="status-icon status-icon--processing">
            <circle cx="12" cy="12" r="10"></circle>
            <polyline points="12 6 12 12 7.5 12"></polyline>
          </svg>
        );
      case 'failed':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="status-icon status-icon--failed">
            <circle cx="12" cy="12" r="10"></circle>
            <path d="m15 9-6 6"></path>
            <path d="m9 9 6 6"></path>
          </svg>
        );
      case 'pending':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="status-icon status-icon--pending">
            <circle cx="12" cy="12" r="10"></circle>
            <path d="M12 6v6l4 2"></path>
          </svg>
        );
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <LoadingScreen 
        message="Loading Dataset Files"
        subtitle="Fetching your dataset information and file status"
      />
    );
  }

    return (
    <div className="dataset-files-standalone">
      <div className="dataset-files-container">
        <div className="dataset-files-header">
          <button 
            className="btn btn--secondary"
            onClick={() => navigate('/dashboard?tab=datasets')}
          >
            ← Back to Datasets
          </button>
          <h1>Dataset Files</h1>
          <p>Dataset ID: {datasetId}</p>
          
          <div className="upload-button-top">
            <label htmlFor="file-upload" className="btn btn--primary">
              {uploading ? 'Uploading...' : 'Upload File'}
            </label>
            <input
              id="file-upload"
              type="file"
              onChange={handleFileUpload}
              disabled={uploading}
              style={{ display: 'none' }}
            />
          </div>
        </div>

        {error && (
          <div className="alert alert--error">
            {error}
            <button onClick={() => setError(null)}>×</button>
          </div>
        )}

        {/* Polling indicator */}
        {pollingInterval && (
          <div className="polling-indicator">
            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: '6px', animation: 'spin 1s linear infinite' }}>
              <circle cx="12" cy="12" r="10"></circle>
              <polyline points="12 6 12 12 7.5 12"></polyline>
            </svg>
            Updating status...
          </div>
        )}

        {dataset && (
          <div className="dataset-info-section">
            <div className="dataset-info-header">
              <div className="header-top">
                <h2>{dataset.name}</h2>
                <div className={`dataset-status dataset-status--${dataset.status}`}>
                  {getStatusIcon(dataset.status)}
                  <span>{dataset.status}</span>
                </div>
              </div>
              
              <div className="header-stats">
                <div className="stat-card stat-card--files">
                  <div className="stat-icon-container">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="stat-icon stat-icon--files">
                      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                      <polyline points="14 2 14 8 20 8"></polyline>
                      <line x1="16" x2="8" y1="13" y2="13"></line>
                      <line x1="16" x2="8" y1="17" y2="17"></line>
                      <line x1="10" x2="8" y1="9" y2="9"></line>
                    </svg>
                  </div>
                  <p className="stat-label">Total Files</p>
                  <div className="stat-value">{files.length}</div>
                  <p className="stat-description">All files</p>
                </div>
                
                <div className="stat-card stat-card--completed">
                  <div className="stat-icon-container">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="stat-icon stat-icon--completed">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <path d="m9 11 3 3L22 4"></path>
                    </svg>
                  </div>
                  <p className="stat-label">Completed</p>
                  <div className="stat-value">
                    {files.filter(f => f.status === 'completed').length}
                  </div>
                  <p className="stat-description">Processed</p>
                </div>
                
                <div className="stat-card stat-card--processing">
                  <div className="stat-icon-container">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="stat-icon stat-icon--processing">
                      <circle cx="12" cy="12" r="10"></circle>
                      <polyline points="12 6 12 12 7.5 12"></polyline>
                    </svg>
                  </div>
                  <p className="stat-label">Processing</p>
                  <div className="stat-value">
                    {files.filter(f => f.status === 'processing').length}
                  </div>
                  <p className="stat-description">In progress</p>
                </div>
                
                <div className="stat-card stat-card--failed">
                  <div className="stat-icon-container">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="stat-icon stat-icon--failed">
                      <circle cx="12" cy="12" r="10"></circle>
                      <path d="m15 9-6 6"></path>
                      <path d="m9 9 6 6"></path>
                    </svg>
                  </div>
                  <p className="stat-label">Failed</p>
                  <div className="stat-value">
                    {files.filter(f => f.status === 'failed').length}
                  </div>
                  <p className="stat-description">Errors</p>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="main-content-layout">
          <div className="left-column">
            {dataset && (
              <>
                <h3 style={{
                  margin: '0 0 16px 0',
                  fontSize: '18px',
                  fontWeight: '700',
                  color: '#1e293b',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px'
                }}>
                  <span style={{
                    width: '4px',
                    height: '20px',
                    background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                    borderRadius: '2px'
                  }}></span>
                  Configuration
                </h3>
                <div className="dataset-info-cards">
                  <div className="info-card">
                    <label>Description</label>
                    <span>{dataset.description}</span>
                  </div>
                  
                  <div className="info-card">
                    <label>Embedding Model</label>
                    <span className="code-text">{dataset.embedding_model}</span>
                  </div>
                  
                  <div className="info-card">
                    <label>Chunking Strategy</label>
                    <span className="code-text">{dataset.chunking_strategy}</span>
                  </div>
                  
                  <div className="info-card">
                    <label>Chunk Size</label>
                    <span>{dataset.chunking_parameters.chunk_size}</span>
                  </div>
                  
                  <div className="info-card">
                    <label>Chunk Overlap</label>
                    <span>{dataset.chunking_parameters.chunk_overlap}</span>
                  </div>
                  
                  <div className="info-card">
                    <label>Allowed File Types</label>
                    <span>{dataset.allowed_file_types.join(', ')}</span>
                  </div>
                  
                  <div className="info-card">
                    <label>S3 Path</label>
                    <span className="code-text">{dataset.aws_s3_folder_path}</span>
                  </div>
                  
                  <div className="info-card">
                    <label>Created</label>
                    <span>{formatDateTime(dataset.created_at)}</span>
                  </div>
                  
                  <div className="info-card">
                    <label>Last Updated</label>
                    <span>{formatDateTime(dataset.updated_at)}</span>
                  </div>
                </div>
              </>
            )}
          </div>

          <div className="right-column">
            <div className="data-table-container">
              <div className="table-container">
                <table className="data-table">
                  <thead className="table-header">
                    <tr>
                      <th>File Name</th>
                      <th>Status</th>
                      <th>Created</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody className="table-body">
                    {files.length === 0 ? (
                      <tr>
                        <td colSpan="4" className="empty-state">
                          No files uploaded yet.
                        </td>
                      </tr>
                    ) : (
                      files.map((file) => (
                        <tr key={file.id} className="table-row">
                          <td className="file-name-cell">
                            <div className="file-info">
                              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="file-icon">
                                <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                                <polyline points="14 2 14 8 20 8"></polyline>
                                <line x1="16" x2="8" y1="13" y2="13"></line>
                                <line x1="16" x2="8" y1="17" y2="17"></line>
                                <line x1="10" x2="8" y1="9" y2="9"></line>
                              </svg>
                              <span className="file-name">{file.file_name}</span>
                            </div>
                          </td>
                          <td className="status-cell">
                            <div className={`status-badge status-badge--${file.status}`} title={file.status}>
                              {getStatusIcon(file.status)}
                              <span className="status-text">{file.status}</span>
                            </div>
                          </td>
                          <td className="date-cell">
                            <span className="date-text">{formatDateTime(file.created_at)}</span>
                          </td>
                          <td className="actions-cell">
                            <button 
                              className="delete-btn"
                              onClick={() => handleFileDelete(file.id)}
                            >
                              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="delete-icon">
                                <polyline points="3,6 5,6 21,6"></polyline>
                                <path d="M19,6v14a2,2 0 0,1 -2,2H7a2,2 0 0,1 -2,-2V6m3,0V4a2,2 0 0,1 2,-2h4a2,2 0 0,1 2,2v2"></path>
                                <line x1="10" x2="10" y1="11" y2="17"></line>
                                <line x1="14" x2="14" y1="11" y2="17"></line>
                              </svg>
                              Delete
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DatasetFilesPage;
