import { FaUserTie, FaLightbulb, FaChartLine, FaSearch, FaCode, FaUsers, FaBrain, FaRocket } from 'react-icons/fa';
import { AGENT_CATEGORIES } from './constants';

/**
 * Get the appropriate icon for an agent based on its name
 * @param {string} agentName - The name of the agent
 * @returns {React.Element} The icon component
 */
export const getAgentIcon = (agentName) => {
  const name = agentName.toLowerCase();
  
  if (name.includes('rag')) return <FaSearch />;
  if (name.includes('echo')) return <FaUserTie />;
  if (name.includes('research') || name.includes('search')) return <FaSearch />;
  if (name.includes('data') || name.includes('analytics')) return <FaChartLine />;
  if (name.includes('code') || name.includes('developer')) return <FaCode />;
  if (name.includes('creative') || name.includes('content')) return <FaLightbulb />;
  if (name.includes('social') || name.includes('community')) return <FaUsers />;
  if (name.includes('ai') || name.includes('intelligence')) return <FaBrain />;
  if (name.includes('assistant') || name.includes('helper')) return <FaUserTie />;
  
  return <FaRocket />;
};

/**
 * Get the category for an agent based on its name
 * @param {Object} agent - The agent object
 * @returns {string} The category identifier
 */
export const getAgentCategory = (agent) => {
  const name = agent.name?.toLowerCase() || agent.id?.toLowerCase() || '';
  
  if (name.includes('rag') || name.includes('search')) return AGENT_CATEGORIES.SEARCH;
  if (name.includes('data') || name.includes('analytics')) return AGENT_CATEGORIES.ANALYTICS;
  if (name.includes('code') || name.includes('developer')) return AGENT_CATEGORIES.DEVELOPMENT;
  if (name.includes('creative') || name.includes('content')) return AGENT_CATEGORIES.CREATIVE;
  if (name.includes('social') || name.includes('community')) return AGENT_CATEGORIES.SOCIAL;
  
  return AGENT_CATEGORIES.GENERAL;
};

/**
 * Get a description for an agent if one is not provided
 * @param {Object} agent - The agent object
 * @returns {string} The agent description
 */
export const getAgentDescription = (agent) => {
  if (agent.description) return agent.description;
  
  const name = agent.name?.toLowerCase() || agent.id?.toLowerCase() || '';
  
  if (name.includes('rag')) {
    return 'RAG workflow: dataset discovery, query decomposition, querying, and synthesis with Langfuse tracing';
  }
  if (name.includes('echo')) {
    return 'Echo agent that returns the provided input and session id';
  }
  if (name.includes('research')) {
    return 'Research and analyze information from multiple sources';
  }
  if (name.includes('data')) {
    return 'Analyze data and generate insights';
  }
  if (name.includes('code')) {
    return 'Help with coding tasks and development';
  }
  if (name.includes('creative')) {
    return 'Generate creative content and ideas';
  }
  if (name.includes('social')) {
    return 'Manage social media and community interactions';
  }
  if (name.includes('ai')) {
    return 'Advanced AI-powered assistance';
  }
  if (name.includes('assistant')) {
    return 'General purpose AI assistant';
  }
  
  return 'Specialized AI agent for your needs';
};

/**
 * Filter agents by category
 * @param {Array} agents - Array of agent objects
 * @param {string} category - Category to filter by
 * @returns {Array} Filtered agents
 */
export const filterAgentsByCategory = (agents, category) => {
  if (category === AGENT_CATEGORIES.ALL) {
    return agents;
  }
  
  return agents.filter(agent => getAgentCategory(agent) === category);
};

/**
 * Get category statistics for agents
 * @param {Array} agents - Array of agent objects
 * @returns {Object} Category counts
 */
export const getCategoryStats = (agents) => {
  const stats = {
    [AGENT_CATEGORIES.ALL]: agents.length,
    [AGENT_CATEGORIES.SEARCH]: 0,
    [AGENT_CATEGORIES.ANALYTICS]: 0,
    [AGENT_CATEGORIES.DEVELOPMENT]: 0,
    [AGENT_CATEGORIES.CREATIVE]: 0,
    [AGENT_CATEGORIES.SOCIAL]: 0,
    [AGENT_CATEGORIES.GENERAL]: 0
  };
  
  agents.forEach(agent => {
    const category = getAgentCategory(agent);
    stats[category]++;
  });
  
  return stats;
};

/**
 * Sort agents by name
 * @param {Array} agents - Array of agent objects
 * @returns {Array} Sorted agents
 */
export const sortAgentsByName = (agents) => {
  return [...agents].sort((a, b) => {
    const nameA = (a.name || a.id || '').toLowerCase();
    const nameB = (b.name || b.id || '').toLowerCase();
    return nameA.localeCompare(nameB);
  });
};

/**
 * Search agents by name or description
 * @param {Array} agents - Array of agent objects
 * @param {string} searchTerm - Search term
 * @returns {Array} Filtered agents
 */
export const searchAgents = (agents, searchTerm) => {
  if (!searchTerm.trim()) return agents;
  
  const term = searchTerm.toLowerCase();
  
  return agents.filter(agent => {
    const name = (agent.name || agent.id || '').toLowerCase();
    const description = (agent.description || '').toLowerCase();
    
    return name.includes(term) || description.includes(term);
  });
};
