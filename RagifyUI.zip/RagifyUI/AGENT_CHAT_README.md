# Agent Chat Implementation

## Overview

The Agent Chat feature provides a conversational interface for interacting with AI agents. It's integrated into the existing Search & Chat tab with a toggle between document search and agent chat modes.

## Features

### 🎯 **Agent Selection**
- Choose from available agents (Echo, RAG System)
- Each agent has distinct capabilities and descriptions
- Visual agent cards with hover effects

### 💬 **Conversational Interface**
- Natural chat-like experience
- Real-time message exchange
- Message timestamps and avatars
- Markdown support for agent responses

### ⚡ **Real-time Interactions**
- Background task processing
- "Agent is thinking..." indicators
- Task cancellation support
- Automatic polling for results

### 📱 **Responsive Design**
- Mobile-friendly interface
- Adaptive layouts for different screen sizes
- Touch-optimized controls

### 🔄 **Session Management**
- Persistent conversation history
- Session state tracking
- Automatic session creation
- Session recovery capabilities

## Implementation Details

### Components

1. **AgentChat.jsx** - Main chat interface component
2. **useAgent.js** - Custom hook for agent state management
3. **agentService.js** - API service layer for agent interactions

### Key Features

#### Agent Service Layer
```javascript
// Get available agents
const agents = await agentService.getAgents();

// Start a session
const session = await agentService.startSession(agentId);

// Send message to agent
const result = await agentService.interactWithAgent(agentId, message, sessionId);

// Poll for task completion
const status = await agentService.pollTaskStatus(taskId);
```

#### State Management
```javascript
const {
  agents,           // Available agents
  selectedAgent,    // Currently selected agent
  currentSession,   // Active session
  isThinking,       // Agent processing state
  sendMessage,      // Send message function
  startSession,     // Start new session
  clearSession      // Clear current session
} = useAgent();
```

### UI Flow

1. **Agent Selection Screen**
   - Display available agents as cards
   - Show agent capabilities and descriptions
   - Click to start conversation

2. **Chat Interface**
   - Header with agent info and "New Chat" button
   - Message history with user/agent avatars
   - Input field with send button
   - Thinking indicator during processing

3. **Message Display**
   - User messages (right-aligned, blue background)
   - Agent messages (left-aligned, white background)
   - Timestamps for each message
   - Markdown rendering for agent responses

## API Integration

### Backend Endpoints Used

- `GET /api/v1/agents` - List available agents
- `POST /api/v1/agents/register` - Refresh agent registry
- `POST /api/v1/agents/{agent_id}/interact` - Start agent interaction
- `GET /api/v1/agents/tasks/{task_id}` - Check task status
- `DELETE /api/v1/agents/tasks/{task_id}` - Cancel task
- `POST /api/v1/sessions/start` - Create new session
- `GET /api/v1/sessions/{session_id}` - Get session state
- `POST /api/v1/sessions/{session_id}` - Update session

### Error Handling

- Network error recovery
- Task timeout handling
- Graceful fallback for failed requests
- User-friendly error messages

## Styling

### Design System
- Uses existing CSS variables for consistency
- Monochrome theme with indigo accent
- Responsive breakpoints for mobile/tablet
- Smooth animations and transitions

### Key CSS Classes
- `.agent-chat` - Main container
- `.agent-selection` - Agent selection screen
- `.agent-card` - Individual agent cards
- `.message` - Chat messages
- `.thinking-indicator` - Loading state
- `.chat-input-container` - Input area

## Usage

### Basic Usage
1. Navigate to Search & Chat tab
2. Click "Talk with Agent" toggle
3. Select an agent from the available options
4. Start typing messages in the chat interface
5. View agent responses in real-time

### Advanced Features
- **New Chat**: Click "New Chat" to start fresh conversation
- **Cancel Task**: Click the X button during agent thinking
- **Session Persistence**: Conversations are automatically saved
- **Fullscreen Mode**: Use the fullscreen toggle for immersive chat

## Development

### Adding New Agents
1. Register agent in backend
2. Agent will appear automatically in frontend
3. Add agent-specific styling if needed

### Customizing Agent Responses
- Modify backend agent logic
- Frontend automatically handles display
- Markdown formatting supported

### Testing
- Use `AgentDemo.jsx` for testing with mock data
- Real API integration available when backend is running

## Future Enhancements

- [ ] Voice input support
- [ ] File upload to agents
- [ ] Agent-specific UI themes
- [ ] Conversation export
- [ ] Agent performance metrics
- [ ] Multi-agent conversations
- [ ] Agent memory management
- [ ] Advanced session controls

## Troubleshooting

### Common Issues

1. **Agents not loading**
   - Check backend API connectivity
   - Verify agent registration
   - Check browser console for errors

2. **Messages not sending**
   - Verify authentication token
   - Check network connectivity
   - Ensure agent is available

3. **Session issues**
   - Clear browser storage
   - Restart application
   - Check session API endpoints

### Debug Mode
Enable browser developer tools to see:
- API request/response logs
- State changes in React DevTools
- Network activity in Network tab
