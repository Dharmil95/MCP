import pytest
import asyncio
from typing import Dict, Any
from fastapi.testclient import TestClient
from httpx import AsyncClient
from app.main import app


class TestAuthentication:
    """Test authentication endpoints"""
    
    def test_health_check(self, client: TestClient):
        """Test health check endpoint"""
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json()["status"] == "healthy"
    
    def test_register_user_success(self, client: TestClient):
        """Test successful user registration"""
        user_data = {
            "email": "testuser@example.com",
            "password": "TestPassword123!"
        }
        response = client.post("/api/v1/auth/register", json=user_data)
        assert response.status_code == 201
        
        data = response.json()
        assert "id" in data
        assert data["email"] == "testuser@example.com"
        assert data["is_active"] == True
        assert data["is_verified"] == False
        assert data["is_superuser"] == False
    
    def test_register_user_invalid_email(self, client: TestClient):
        """Test user registration with invalid email"""
        user_data = {
            "email": "invalid-email",
            "password": "TestPassword123!"
        }
        response = client.post("/api/v1/auth/register", json=user_data)
        assert response.status_code == 422
    
    def test_register_user_weak_password(self, client: TestClient):
        """Test user registration with weak password"""
        user_data = {
            "email": "test2@example.com",
            "password": "weak"
        }
        response = client.post("/api/v1/auth/register", json=user_data)
        assert response.status_code == 422
    
    def test_register_duplicate_email(self, client: TestClient):
        """Test registration with duplicate email"""
        user_data = {
            "email": "duplicate@example.com",
            "password": "TestPassword123!"
        }
        # First registration should succeed
        response1 = client.post("/api/v1/auth/register", json=user_data)
        assert response1.status_code == 201
        
        # Second registration should fail
        response2 = client.post("/api/v1/auth/register", json=user_data)
        assert response2.status_code == 400
    
    def test_login_success(self, client: TestClient):
        """Test successful login"""
        # First register a user
        user_data = {
            "email": "logintest@example.com",
            "password": "TestPassword123!"
        }
        client.post("/api/v1/auth/register", json=user_data)
        
        # Then login
        login_data = {
            "username": "logintest@example.com",
            "password": "TestPassword123!"
        }
        response = client.post("/api/v1/auth/jwt/login", data=login_data)
        assert response.status_code == 200
        
        data = response.json()
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["token_type"] == "bearer"
        assert data["expires_in"] == 1800  # 30 minutes
    
    def test_login_invalid_credentials(self, client: TestClient):
        """Test login with invalid credentials"""
        login_data = {
            "username": "nonexistent@example.com",
            "password": "wrongpassword"
        }
        response = client.post("/api/v1/auth/jwt/login", data=login_data)
        assert response.status_code == 401
    
    def test_access_protected_endpoint_without_token(self, client: TestClient):
        """Test accessing protected endpoint without token"""
        response = client.get("/api/v1/users/me")
        assert response.status_code == 401
    
    def test_access_protected_endpoint_with_token(self, client: TestClient):
        """Test accessing protected endpoint with valid token"""
        # Register and login
        user_data = {
            "email": "protected@example.com",
            "password": "TestPassword123!"
        }
        client.post("/api/v1/auth/register", json=user_data)
        
        login_data = {
            "username": "protected@example.com",
            "password": "TestPassword123!"
        }
        login_response = client.post("/api/v1/auth/jwt/login", data=login_data)
        access_token = login_response.json()["access_token"]
        
        # Access protected endpoint
        headers = {"Authorization": f"Bearer {access_token}"}
        response = client.get("/api/v1/users/me", headers=headers)
        assert response.status_code == 200
        
        data = response.json()
        assert data["email"] == "protected@example.com"
    
    def test_refresh_token(self, client: TestClient):
        """Test token refresh"""
        # Register and login
        user_data = {
            "email": "refresh@example.com",
            "password": "TestPassword123!"
        }
        client.post("/api/v1/auth/register", json=user_data)
        
        login_data = {
            "username": "refresh@example.com",
            "password": "TestPassword123!"
        }
        login_response = client.post("/api/v1/auth/jwt/login", data=login_data)
        refresh_token = login_response.json()["refresh_token"]
        
        # Refresh token
        refresh_data = {"refresh_token": refresh_token}
        response = client.post("/api/v1/auth/jwt/refresh", json=refresh_data)
        assert response.status_code == 200
        
        data = response.json()
        assert "access_token" in data
        assert data["token_type"] == "bearer"
