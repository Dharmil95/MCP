                                                                    #!/bin/bash

echo "🚀 Starting RAGify with Elasticsearch + Grafana Logging Stack"
echo "=========================================================="

# Stop any existing containers
echo "📦 Stopping existing containers..."
docker compose down

# Remove old volumes (optional - uncomment if you want to start fresh)
# echo "🗑️  Removing old volumes..."
# docker volume rm ragify_loki_data 2>/dev/null || true

# Start the new stack
echo "🔄 Starting new logging stack..."
docker compose up -d

echo ""
echo "⏳ Waiting for services to be ready..."
echo "   - Elasticsearch: http://localhost:9200"
echo "   - Kibana: http://localhost:5601"
echo "   - Grafana: http://localhost:3000 (admin/admin)"
echo ""

# Wait for Elasticsearch to be ready
echo "🔍 Waiting for Elasticsearch..."
until curl -s http://localhost:9200/_cluster/health > /dev/null; do
    echo "   Waiting for Elasticsearch..."                         
    sleep 5
done
echo "✅ Elasticsearch is ready!"

# Wait for Kibana to be ready
echo "🔍 Waiting for Kibana..."
until curl -s http://localhost:5601/api/status > /dev/null; do
    echo "   Waiting for Kibana..."
    sleep 5
done
echo "✅ Kibana is ready!"

echo ""
echo "🎉 Logging stack is ready!"
echo ""
echo "📊 Access your services:"
echo "   - Grafana: http://localhost:3000 (admin/admin)"
echo "   - Kibana: http://localhost:5601"
echo "   - Elasticsearch: http://localhost:9200"
echo ""
echo "📈 View logs in:"
echo "   - Grafana: Application Logs Overview dashboard"
echo "   - Kibana: Discover tab for raw logs"
echo ""
echo "🔧 To view logs: docker compose logs -f [service_name]" 