import React from 'react';
import AgentChat from './AgentChat';
import '../styles/content-header.css';

const AgentChatTab = ({
  agents,
  selectedAgent,
  currentSession,
  isLoading,
  error,
  isThinking,
  startSession,
  sendMessage,
  cancelTask,
  clearSession,
  setSelectedAgent,
  setCurrentSession
}) => {
  return (
    <div className="agent-chat-tab">
      <AgentChat 
        agents={agents}
        selectedAgent={selectedAgent}
        currentSession={currentSession}
        isLoading={isLoading}
        error={error}
        isThinking={isThinking}
        startSession={startSession}
        sendMessage={sendMessage}
        cancelTask={cancelTask}
        clearSession={clearSession}
        setSelectedAgent={setSelectedAgent}
        setCurrentSession={setCurrentSession}
      />
    </div>
  );
};

export default AgentChatTab;
