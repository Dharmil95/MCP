import React from 'react';

const DashboardTab = () => (
  <>
    <div className="welcome-card">
      <h2>Getting Started with RAGify</h2>
      <p>RAGify helps you build powerful Retrieval Augmented Generation applications.</p>
      <div className="steps">
        <div className="step">
          <div className="step-number">1</div>
          <div className="step-content">
            <h3>Upload Your Data</h3>
            <p>Start by uploading documents to create a dataset.</p>
          </div>
        </div>
        <div className="step">
          <div className="step-number">2</div>
          <div className="step-content">
            <h3>Configure Your RAG Model</h3>
            <p>Choose embedding and retrieval settings.</p>
          </div>
        </div>
        <div className="step">
          <div className="step-number">3</div>
          <div className="step-content">
            <h3>Query Your Knowledge</h3>
            <p>Ask questions and get AI-powered answers based on your data.</p>
          </div>
        </div>
      </div>
    </div>
    <div className="recent-activity">
      <h2>Recent Activity</h2>
      <p className="empty-state">No recent activity to display.</p>
    </div>
  </>
);

export default DashboardTab;
