import React, { useState, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import { FaPaperPlane } from 'react-icons/fa';
import Input from '../common/Input';
import Button from '../common/Button';
import './ChatInput.css';

const ChatInput = ({
  onSendMessage,
  placeholder = "Type your message...",
  disabled = false,
  isLoading = false,
  className = '',
  autoFocus = true
}) => {
  const [message, setMessage] = useState('');
  const inputRef = useRef(null);

  useEffect(() => {
    if (autoFocus && inputRef.current) {
      inputRef.current.focus();
    }
  }, [autoFocus]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!message.trim() || disabled || isLoading) return;

    onSendMessage(message.trim());
    setMessage('');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const canSend = message.trim() && !disabled && !isLoading;

  return (
    <form className={`chat-input ${className}`} onSubmit={handleSubmit}>
      <div className="chat-input__container">
        <Input
          ref={inputRef}
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          disabled={disabled || isLoading}
          fullWidth
          className="chat-input__field"
        />
        <Button
          type="submit"
          variant="primary"
          size="medium"
          disabled={!canSend}
          icon={FaPaperPlane}
          className="chat-input__send-btn"
        />
      </div>
    </form>
  );
};

ChatInput.propTypes = {
  onSendMessage: PropTypes.func.isRequired,
  placeholder: PropTypes.string,
  disabled: PropTypes.bool,
  isLoading: PropTypes.bool,
  className: PropTypes.string,
  autoFocus: PropTypes.bool
};

export default ChatInput;
