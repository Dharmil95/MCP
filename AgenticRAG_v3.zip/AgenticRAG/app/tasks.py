import asyncio
import logging
from typing import Dict, Any, List
from uuid import UUID
import tempfile
import os
import psutil
import gc
from pathlib import Path
from datetime import datetime

from celery import current_task
from celery import Celery
from celery.signals import worker_process_init, worker_process_shutdown
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

from app.core.celery_app import celery_app
from app.services.document_processor import DocumentProcessor, EmbeddingService
from app.db.database import get_async_session
from app.models import Dataset
from app.core.config import settings
from sqlalchemy import select, update

logger = logging.getLogger(__name__)


def log_memory_usage(stage: str):
    """Log current memory usage"""
    try:
        import psutil
        process = psutil.Process()
        memory_info = process.memory_info()
        logger.info(f"Memory usage at {stage}: {memory_info.rss / 1024 / 1024:.1f} MB")
    except ImportError:
        logger.info(f"Memory logging at {stage}: psutil not available")
    except Exception as e:
        logger.info(f"Memory logging at {stage}: error {str(e)}")


@celery_app.task(bind=True, name="app.tasks.process_dataset")
def process_dataset(self, dataset_id: str, aws_credentials: Dict[str, str]):
    """
    Main task to process a dataset
    """
    try:
        # Update task state
        self.update_state(
            state='PROGRESS',
            meta={'current': 0, 'total': 100, 'status': 'Starting dataset processing...'}
        )
        
        # Run async processing
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        try:
            result = loop.run_until_complete(
                _process_dataset_async(dataset_id, aws_credentials, self)
            )
            return result
        finally:
            loop.close()        
    except Exception as e:
        logger.error(f"Error in process_dataset task: {str(e)}")
        self.update_state(
            state='FAILURE',
            meta={
                'error': str(e),
                'exc_type': type(e).__name__,  # Required by Celery
            }
        )
        raise  # Still raise the exception so Celery marks the task as failed



async def _process_dataset_async(dataset_id: str, aws_credentials: Dict[str, str], task):
    """Async implementation of dataset processing"""
    
    # Create a new async session for the task
    from app.db.database import AsyncSessionLocal
    
    async with AsyncSessionLocal() as db:
        try:
            # Get dataset details
            dataset_uuid = UUID(dataset_id)
            dataset = await db.get(Dataset, dataset_uuid)
            
            if not dataset:
                raise ValueError("Dataset not found")
            
            # Update dataset status
            await _update_dataset_status(db, dataset_uuid, "processing")
            
            # Initialize processor
            processor = DocumentProcessor(dataset_uuid, aws_credentials)
            
            # Step 1: List files in S3
            task.update_state(
                state='PROGRESS',
                meta={'current': 10, 'total': 100, 'status': 'Listing S3 files...'}
            )
            
            files = await processor.list_s3_files(
                dataset.aws_s3_folder_path,
                dataset.allowed_file_types
            )
            
            if not files:
                await _update_dataset_status(db, dataset_uuid, "completed")
                return {"status": "completed", "message": "No files found to process"}
            
            # Get all processed objects for this dataset
            from app.models.database import DatasetObject
            processed_query = select(DatasetObject).where(DatasetObject.dataset_id == dataset_uuid)
            processed_result = await db.execute(processed_query)
            # Use correct field name for S3 key
            # Include failed objects for reprocessing
            processed_keys = {obj.original_s3_path for obj in processed_result.scalars().all() if obj.status == "completed"}
            failed_keys = {obj.original_s3_path for obj in processed_result.scalars().all() if obj.status == "failed"}
            # Step 2: Process files not present in DatasetObject (pending) and those with status failed
            task.update_state(
                state='PROGRESS',
                meta={'current': 20, 'total': 100, 'status': f'Processing {len(files)} files...'}
            )
            processed_files = []
            failed_files = []
            for i, file_info in enumerate(files):
                # Process if not completed (pending or failed)
                if file_info['key'] in processed_keys:
                    logger.info(f"Skipping already processed file: {file_info['key']}")
                    continue
                # If failed, allow reprocessing
                try:
                    # Create dataset object record
                    dataset_object = await processor.create_dataset_object(db, file_info)
                    if not dataset_object:
                        logger.error(f"Failed to create DatasetObject for file: {file_info['key']}")
                        failed_files.append({
                            'file': file_info['key'],
                            'status': 'failed',
                            'error': 'DatasetObject creation failed'
                        })
                        continue
                    else:
                        logger.info(f"Created DatasetObject: {dataset_object.id} for file: {file_info['key']}")
                    
                    # Process file
                    result = await _process_file_async(
                        dataset_object.id, 
                        file_info, 
                        processor, 
                        dataset,
                        db
                    )
                    
                    if result['status'] == 'success':
                        processed_files.append(result)
                    else:
                        failed_files.append(result)
                    
                    # Update progress
                    progress = 20 + (70 * (i + 1) // len(files))
                    task.update_state(
                        state='PROGRESS',
                        meta={
                            'current': progress, 
                            'total': 100, 
                            'status': f'Processed {i+1}/{len(files)} files...'
                        }
                    )
                    
                except Exception as e:
                    logger.error(f"Error processing file {file_info['key']}: {str(e)}")
                    failed_files.append({
                        'file': file_info['key'],
                        'status': 'failed',
                        'error': str(e)
                    })
            
            # Step 3: Final status update
            task.update_state(
                state='PROGRESS',
                meta={'current': 90, 'total': 100, 'status': 'Finalizing...'}
            )
            
            final_status = "completed" if len(failed_files) == 0 else "partially_completed"
            await _update_dataset_status(db, dataset_uuid, final_status)
            
            result = {
                "status": final_status,
                "total_files": len(files),
                "processed_files": len(processed_files),
                "failed_files": len(failed_files),
                "total_chunks": sum(f.get('chunks_count', 0) for f in processed_files)
            }
            
            logger.info(f"Dataset {dataset_id} processing completed: {result}")
            return result
            
        except Exception as e:
            logger.error(f"Error processing dataset {dataset_id}: {str(e)}")
            await _update_dataset_status(db, dataset_uuid, "failed")
            # Also update all dataset_objects for this dataset to failed with error message
            from app.models.database import DatasetObject
            from sqlalchemy import update
            stmt = update(DatasetObject).where(DatasetObject.dataset_id == dataset_uuid).values(status="failed", error_message=str(e))
            await db.execute(stmt)
            await db.commit()
            raise


async def _process_file_async(object_id: UUID, file_info: Dict[str, Any], 
                            processor: DocumentProcessor, dataset: Dataset, db):
    """Process a single file"""
    
    text = ""  # Always initialize text
    text_length = 0  # Track text length for reporting
    chunks = []  # Always initialize chunks
    embeddings = []  # Always initialize embeddings
    try:
        # Update status to processing
        await processor.update_object_status(db, object_id, "processing")
        log_memory_usage("start_file_processing")
        
        # Download file to temporary location
        with tempfile.TemporaryDirectory() as temp_dir:
            local_path = os.path.join(temp_dir, Path(file_info['key']).name)
            
            success = await processor.download_file(
                file_info['bucket'],
                file_info['key'],
                local_path
            )
            
            if not success:
                await processor.update_object_status(
                    db, object_id, "failed", 
                    error_message="Failed to download file"
                )
                return {'status': 'failed', 'error': 'Download failed'}
            
            # Extract text
            log_memory_usage("before_text_extraction")
            text = processor.extract_text(local_path, file_info['extension'])
            text_length = len(text) if text is not None else 0
            log_memory_usage("after_text_extraction")
            
            if not text:
                await processor.update_object_status(
                    db, object_id, "failed", 
                    error_message="No text extracted from file"
                )
                return {'status': 'failed', 'error': 'No text extracted'}
            
            # Chunk text with memory management
            logger.info(f"Starting text chunking. Text length: {len(text)} characters")
            
            try:
                chunks = processor.chunk_text(
                    text,
                    dataset.chunking_parameters.get('chunk_size', 512),  # Smaller chunks
                    dataset.chunking_parameters.get('chunk_overlap', 50)
                )
                
                logger.info(f"Text chunking completed. Generated {len(chunks)} chunks")
                
                # Clear text from memory immediately
                del text
                import gc
                gc.collect()
                
            except Exception as e:
                logger.error(f"Error during text chunking: {str(e)}")
                await processor.update_object_status(
                    db, object_id, "failed", 
                    error_message=f"Chunking failed: {str(e)}"
                )
                return {'status': 'failed', 'error': f'Chunking failed: {str(e)}'}
            
            if not chunks:
                await processor.update_object_status(
                    db, object_id, "failed", 
                    error_message="No chunks generated"
                )
                return {'status': 'failed', 'error': 'No chunks generated'}
            
            # Generate embeddings
            if settings.openai_api_key:
                try:
                    embedding_service = EmbeddingService(settings.openai_api_key)
                    embeddings = await embedding_service.generate_embeddings(chunks)
                    await embedding_service.store_embeddings(db, object_id, chunks, embeddings)
                    logger.info(f"Generated and stored {len(embeddings)} embeddings")
                except Exception as e:
                    logger.error(f"Error generating embeddings: {str(e)}")
                    await processor.update_object_status(
                        db, object_id, "failed",
                        error_message=f"Embedding generation failed: {str(e)}"
                    )
                    return {'status': 'failed', 'error': f'Embedding generation failed: {str(e)}'}
            else:
                logger.warning("OpenAI API key not provided, skipping embedding generation")
                await processor.update_object_status(
                    db, object_id, "failed",
                    error_message="OpenAI API key not provided, embedding skipped"
                )
                return {'status': 'failed', 'error': 'OpenAI API key not provided, embedding skipped'}
            
            # Update status to completed only if embeddings were stored
            await processor.update_object_status(
                db, object_id, "completed"
            )
            
            return {
                'status': 'success',
                'file': file_info['key'],
                'chunks_count': len(chunks),
                'text_length': text_length
            }
            
    except Exception as e:
        logger.error(f"Error processing file {file_info['key']}: {str(e)}")
        await processor.update_object_status(
            db, object_id, "failed",
            error_message=str(e)
        )
        return {'status': 'failed', 'error': str(e)}


async def _update_dataset_status(db, dataset_id: UUID, status: str):
    """Update dataset status in database"""
    stmt = update(Dataset).where(Dataset.id == dataset_id).values(
        status=status,
        updated_at=datetime.utcnow()
    )
    await db.execute(stmt)
    await db.commit()


@celery_app.task(bind=True, name="app.tasks.check_dataset_status")
def check_dataset_status(self, dataset_id: str):
    """Check the status of a dataset processing task"""
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        try:
            return loop.run_until_complete(_check_dataset_status_async(dataset_id))
        finally:
            loop.close()
            
    except Exception as e:
        logger.error(f"Error checking dataset status: {str(e)}")
        return {"status": "error", "error": str(e)}


async def _check_dataset_status_async(dataset_id: str):
    """Async implementation of status check"""
    from app.db.database import AsyncSessionLocal
    
    async with AsyncSessionLocal() as db:
        dataset_uuid = UUID(dataset_id)
        dataset = await db.get(Dataset, dataset_uuid)
        
        if not dataset:
            return {"status": "not_found"}
        
        return {
            "status": dataset.status,
            "updated_at": dataset.updated_at.isoformat() if dataset.updated_at else None
        }


engine = None
AsyncSessionLocal = None

@worker_process_init.connect
def init_worker(**kwargs):
    global engine, AsyncSessionLocal
    engine = create_async_engine(
        settings.database_url,
        echo=settings.debug,
        future=True,
    )
    AsyncSessionLocal = sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False
    )

@worker_process_shutdown.connect
def shutdown_worker(**kwargs):
    global engine
    if engine:
        engine.sync_engine.dispose()
