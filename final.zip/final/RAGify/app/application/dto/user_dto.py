"""User DTOs for the application layer."""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional
from uuid import UUID


@dataclass
class CreateUserDTO:
    """DTO for creating a user."""

    email: str
    password: str
    is_active: bool = True
    is_verified: bool = False
    is_superuser: bool = False


@dataclass
class UpdateUserDTO:
    """DTO for updating a user."""

    email: Optional[str] = None
    is_active: Optional[bool] = None
    is_verified: Optional[bool] = None
    is_superuser: Optional[bool] = None


@dataclass
class UserDTO:
    """DTO for user representation."""

    id: UUID
    email: str
    is_active: bool
    is_verified: bool
    is_superuser: bool
    created_at: datetime
    updated_at: datetime


@dataclass
class AuthTokenDTO:
    """DTO for authentication tokens."""

    access_token: str
    refresh_token: str
    token_type: str = "bearer"


@dataclass
class LoginDTO:
    """DTO for user login."""

    email: str
    password: str
