import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { FaTrash } from 'react-icons/fa';
import datasetService from '../services/datasetService';
import '../styles/dataset.css';
import '../styles/files-table.css';
import ConfirmModal from '../components/ConfirmModal';
import Toast from '../components/Toast';
import '../styles/toast.css';

const DatasetFilesPage = () => {
  const { datasetId } = useParams();
  const navigate = useNavigate();
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [datasetName, setDatasetName] = useState('');
  const [uploading, setUploading] = useState(false);
  const [toastMsg, setToastMsg] = useState('');
  const [toastType, setToastType] = useState('success');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [fileToDelete, setFileToDelete] = useState(null);

  useEffect(() => {
    const fetchFiles = async () => {
      setLoading(true);
      setError('');
      try {
        const dataset = await datasetService.getDatasetById(datasetId);
        setDatasetName(dataset.name);
        const filesData = await datasetService.getDatasetFilesWithStatus(datasetId);
        setFiles(filesData);
      } catch (err) {
        setError('Failed to fetch files or dataset info.');
      } finally {
        setLoading(false);
      }
    };
    fetchFiles();
    // Auto-refresh files every 10 seconds
    const intervalId = setInterval(() => {
      datasetService.getDatasetFilesWithStatus(datasetId)
        .then(setFiles)
        .catch(() => {});
    }, 10000);
    return () => clearInterval(intervalId);
  }, [datasetId]);

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
      const result = await datasetService.uploadFileToDataset(datasetId, file);
      setToastMsg(result.message || `File '${file.name}' uploaded successfully to '${file.name}'`);
      setToastType('success');
      // Refresh files list
      const filesData = await datasetService.getDatasetFilesWithStatus(datasetId);
      setFiles(filesData);
    } catch (err) {
      setToastMsg('Upload failed.');
      setToastType('error');
    } finally {
      setUploading(false);
    }
  };

  const handleDeleteFileClick = (fileId) => {
    console.log('handleDeleteFileClick called, fileId:', fileId); // Debug log
    setFileToDelete(fileId);
    setShowDeleteModal(true);
  };

  const handleConfirmDeleteFile = async (fileId) => {
    console.log('handleConfirmDeleteFile called, fileId:', fileId);
    if (!fileId) return;
    try {
      const apiResult = await datasetService.deleteFile(fileId);
      console.log('Delete API result:', apiResult);
      setToastMsg('File deleted successfully!');
      setToastType('success');
      const filesData = await datasetService.getDatasetFilesWithStatus(datasetId);
      console.log('Files after delete:', filesData);
      setFiles(filesData);
    } catch (err) {
      console.error('Delete file error:', err);
      setToastMsg('Failed to delete file: ' + (err?.response?.data?.detail || err.message || 'Unknown error'));
      setToastType('error');
    } finally {
      setShowDeleteModal(false);
      setFileToDelete(null);
    }
  };

  const handleCancelDeleteFile = () => {
    setShowDeleteModal(false);
    setFileToDelete(null);
  };

  const handleCopyId = (id) => {
    navigator.clipboard.writeText(id);
    setToastMsg('Copied dataset_object_id to clipboard!');
    setToastType('info');
  };

  const handleProcessFile = async (datasetId) => {
    if (!datasetId) return;
    try {
      const response = await datasetService.processDataset(datasetId);
      setToastMsg('Processing started!');
      setToastType('info');
      // Optionally refresh files list
      const filesData = await datasetService.getDatasetFilesWithStatus(datasetId);
      setFiles(filesData);
    } catch (err) {
      setToastMsg('Failed to start processing: ' + (err?.response?.data?.detail || err.message || 'Unknown error'));
      setToastType('error');
    }
  };

  return (
    <div className="dataset-files-page">
      <div className="top-bar" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.2rem' }}>
        <button className="secondary-btn" onClick={() => navigate(-1)}>
          &larr; Back to Datasets
        </button>
        <h2 className="page-heading">Files in {datasetName}</h2>
        <div className="upload-area" style={{ display: 'flex', alignItems: 'center', gap: '1em' }}>
          <label htmlFor="file-upload" className="upload-btn" style={{ cursor: uploading ? 'not-allowed' : 'pointer' }}>
            {uploading && <span className="upload-spinner"></span>}
            {!uploading && <span>Upload File</span>}
          </label>
          <input
            id="file-upload"
            type="file"
            style={{ display: 'none' }}
            disabled={uploading}
            onChange={handleFileUpload}
          />
          <label htmlFor="process-all" className="upload-btn" style={{ cursor: 'pointer', marginLeft: '0' }} onClick={() => handleProcessFile(datasetId)}>
            <span>Process All</span>
          </label>
        </div>
      </div>
      <div className="card">
        <div className="table-container">
          {loading ? (
            <p>Loading files...</p>
          ) : error ? (
            <p className="error-message">{error}</p>
          ) : files.length === 0 ? (
            <p>No files found in this dataset.</p>
          ) : (
            <table className="files-table">
              <thead>
                <tr>
                  <th style={{ width: '22%' }}>File Name</th>
                  <th style={{ width: '15%' }}>Status</th>
                  <th style={{ width: '15%' }}>Created</th>
                  <th style={{ width: '28%' }}>Object ID</th>
                  <th style={{ width: '10%' }}>Delete</th>
                </tr>
              </thead>
              <tbody>
                {files.map((file, idx) => {
                  // console.log('Rendering file row:', file); // Debug log
                  let statusClass = 'status-badge ';
                  if (file.status === 'completed') statusClass += 'status-completed';
                  else if (file.status === 'processing') statusClass += 'status-processing';
                  else statusClass += 'status-failed';
                  const truncate = (str, len = 28) => str && str.length > len ? str.slice(0, len) + '...' : str;
                  const formatDate = (dateStr) => {
                    if (!dateStr) return 'N/A';
                    const d = new Date(dateStr);
                    return d.toLocaleString('en-US', { month: 'short', day: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true });
                  };
                  return (
                    <tr key={file.dataset_object_id ? file.dataset_object_id : idx}>
                      <td><span className="filename" title={file.file_name}>{truncate(file.file_name)}</span></td>
                      <td><span className={statusClass}>{file.status}</span></td>
                      <td>{formatDate(file.created_at)}</td>
                      <td>
                        <button
                          className="object-id-btn"
                          style={{ background: 'none', border: 'none', color: '#2563eb', cursor: 'pointer', fontSize: '0.95em', textDecoration: 'underline' }}
                          title="Copy Object ID"
                          onClick={() => handleCopyId(file.dataset_object_id)}
                        >
                          {file.dataset_object_id}
                        </button>
                      </td>
                      <td>
                        <button
                          className="icon-btn"
                          title="Delete File"
                          style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#e74c3c', fontSize: '1.1em' }}
                          onClick={() => handleDeleteFileClick(file.dataset_object_id)}
                        >
                          <FaTrash />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>
      <ConfirmModal
        isOpen={showDeleteModal}
        title="Delete File"
        message="Are you sure you want to delete this file? This action cannot be undone."
        fileId={fileToDelete}
        onConfirm={handleConfirmDeleteFile}
        onCancel={handleCancelDeleteFile}
      />
      {/* Toast notification */}
      <Toast
        message={toastMsg}
        type={toastType}
        duration={3200}
        onClose={() => setToastMsg('')}
      />
    </div>
  );
};

export default DatasetFilesPage;
