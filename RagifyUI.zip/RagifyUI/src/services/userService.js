import api from './api';

const userService = {
  /**
   * Get current user information
   * @returns {Promise} User data
   */
  getCurrentUser: async () => {
    try {
      console.log('Attempting to fetch current user data from:', '/users/me');
      const response = await api.get('/users/me');
      return response.data;
    } catch (error) {
      console.error('Error fetching user data:', error);
      if (error.response) {
        // The request was made and the server responded with an error status code
        console.error('Error status:', error.response.status);
        console.error('Error data:', error.response.data);
      } else if (error.request) {
        // The request was made but no response was received
        console.error('No response received from server');
      }
      throw error;
    }
  },

  /**
   * Update user profile
   * @param {Object} userData - User data to update
   * @returns {Promise} Updated user data
   */
  updateProfile: async (userData) => {
    try {
      const response = await api.patch('/users/me', userData);
      return response.data;
    } catch (error) {
      console.error('Error updating profile:', error);
      throw error;
    }
  },

  /**
   * Change user password
   * @param {string} currentPassword 
   * @param {string} newPassword 
   * @returns {Promise} Response with status
   */
  changePassword: async (currentPassword, newPassword) => {
    const response = await api.post('/users/change-password', {
      current_password: currentPassword,
      new_password: newPassword,
    });
    return response.data;
  },

  /**
   * Get user datasets
   * @returns {Promise} List of datasets
   */
  getDatasets: async () => {
    const response = await api.get('/datasets');
    return response.data;
  },

  /**
   * Create new dataset
   * @param {Object} datasetInfo - Dataset information
   * @returns {Promise} Created dataset
   */
  createDataset: async (datasetInfo) => {
    const response = await api.post('/datasets', datasetInfo);
    return response.data;
  },

  /**
   * Search documents using RAG
   * @param {string} query - User query
   * @param {string} datasetId - Dataset ID to search in
   * @returns {Promise} Search results
   */
  search: async (query, datasetId) => {
    const response = await api.post('/search', {
      query,
      dataset_id: datasetId,
    });
    return response.data;
  },
};

export default userService;
