// Removes code fences from markdown so tables render as HTML tables
export function stripFence(md) {
  return md.replace(/^```[a-z]*\n?/i, '').replace(/```$/, '');
}
