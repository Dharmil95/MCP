from __future__ import annotations

import functools
import logging
import os
from typing import Any, Callable, Optional

# Ensure environment variables are loaded
from dotenv import load_dotenv
load_dotenv()

from app.core.config import settings

logger = logging.getLogger(__name__)

_client: Any = None
_initialized = False


def _env(key: str) -> Optional[str]:
    val = os.getenv(key)
    return val if val else None


def is_langfuse_enabled() -> bool:
    """Return True if required env/config for Langfuse is present."""
    # Check both settings and env vars
    has_public = bool(settings.langfuse_public_key or _env("LANGFUSE_PUBLIC_KEY"))
    has_secret = bool(settings.langfuse_secret_key or _env("LANGFUSE_SECRET_KEY"))
    return has_public and has_secret


def get_langfuse_client():
    """Return the singleton Langfuse client if configured; else None."""
    global _client
    global _initialized
    
    # Only initialize once
    if _initialized:
        return _client
    
    _initialized = True
    
    # Check if Langfuse is enabled
    if not is_langfuse_enabled():
        logger.debug("Langfuse not configured - public_key and secret_key required")
        return None
    
    try:
        from langfuse import get_client
        _client = get_client()
        logger.info("Langfuse client initialized successfully")
        return _client
    except Exception as e:  # pragma: no cover - best effort
        logger.debug(f"Langfuse client initialization failed: {e}")
        return None
    
    return None


def observe_fn(name: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator to wrap a function with Langfuse observe() if available.

    Falls back to a no-op if Langfuse is not installed/configured.
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        # Always return a wrapper, but only use Langfuse if enabled
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            return func(*args, **kwargs)
        
        # Only try to use Langfuse observe if enabled
        if is_langfuse_enabled():
            try:
                from langfuse.decorators import observe
                return observe(name=name)(func)  # type: ignore
            except Exception:  # pragma: no cover
                logger.debug("Langfuse observe decorator failed; using passthrough")
        
        return wrapper

    return decorator


