import React from 'react';
import PropTypes from 'prop-types';
import { FaRobot } from 'react-icons/fa';
import Button from '../common/Button';
import './ThinkingIndicator.css';

const ThinkingIndicator = ({
  agentName,
  onCancel,
  className = ''
}) => {
  return (
    <div className={`thinking-indicator ${className}`}>
      <div className="thinking-indicator__content">
        <div className="thinking-indicator__icon">
          <FaRobot />
        </div>
        <div className="thinking-indicator__info">
          <div className="thinking-indicator__status">
            <div className="thinking-indicator__dots">
              <div className="thinking-indicator__dot thinking-indicator__dot--1"></div>
              <div className="thinking-indicator__dot thinking-indicator__dot--2"></div>
              <div className="thinking-indicator__dot thinking-indicator__dot--3"></div>
            </div>
            <span className="thinking-indicator__text">
              {agentName || 'Agent'} is thinking...
            </span>
          </div>
          {onCancel && (
            <Button
              variant="ghost"
              size="small"
              onClick={onCancel}
              className="thinking-indicator__cancel-btn"
            >
              Cancel
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

ThinkingIndicator.propTypes = {
  agentName: PropTypes.string,
  onCancel: PropTypes.func,
  className: PropTypes.string
};

export default ThinkingIndicator;
