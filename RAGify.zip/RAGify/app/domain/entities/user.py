"""User domain entity."""

from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional
from uuid import UUID


@dataclass
class User:
    """User domain entity representing a user in the system."""

    id: UUID
    email: str
    is_active: bool
    is_verified: bool
    is_superuser: bool
    created_at: datetime
    updated_at: datetime

    def __post_init__(self):
        """Validate user data after initialization."""
        if not self.email or "@" not in self.email:
            raise ValueError("Invalid email address")

    def is_owner_of_dataset(self, dataset_owner_id: UUID) -> bool:
        """Check if user owns a dataset."""
        return self.id == dataset_owner_id

    def can_access_dataset(self, dataset_owner_id: UUID) -> bool:
        """Check if user can access a dataset."""
        return self.is_superuser or self.is_owner_of_dataset(dataset_owner_id)
