import openai
from sqlalchemy import text

from app.core.config import settings


class EmbeddingService:
    def __init__(self, api_key: str = None):
        self.api_key = api_key or settings.openai_api_key
        self.model = "text-embedding-ada-002"
        self.openai_client = openai.AsyncOpenAI(api_key=self.api_key)

    async def generate_embeddings(self, texts):
        response = await self.openai_client.embeddings.create(
            input=texts, model=self.model
        )
        return [item.embedding for item in response.data]

    async def search_chunks(
        self,
        db,
        query: str,
        top_k: int = 5,
        dataset_id: str = None,
        owner_id: str = None,
    ):
        # Generate embedding for the query
        query_embedding = await self.generate_embeddings([query])
        query_embedding = query_embedding[0]
        # Build SQL for searching chunks
        sql_lines = [
            "SELECT ev.dataset_object_id, dobj.file_name, ev.chunk_text, (ev.embedding <-> cast(:query_embedding AS vector)) AS similarity_score",
            "FROM embedding_vectors ev",
            "JOIN dataset_objects dobj ON ev.dataset_object_id = dobj.id",
        ]
        vec_str = "[" + ",".join(map(str, query_embedding)) + "]"
        params = {"query_embedding": vec_str, "top_k": top_k}
        if owner_id:
            sql_lines.append("JOIN datasets ds ON dobj.dataset_id = ds.id")
            sql_lines.append("WHERE ds.owner_id = :owner_id")
            params["owner_id"] = str(owner_id)
        elif dataset_id:
            sql_lines.append("WHERE dobj.dataset_id = :dataset_id")
            params["dataset_id"] = str(dataset_id)
        sql_lines.append("ORDER BY similarity_score ASC LIMIT :top_k")
        base_sql = "\n".join(sql_lines)
        result = await db.execute(text(base_sql), params)
        rows = result.fetchall()
        return [
            {
                "dataset_object_id": str(row.dataset_object_id),
                "file_name": row.file_name,
                "chunk_text": row.chunk_text,
                "similarity_score": float(row.similarity_score),
            }
            for row in rows
        ]
