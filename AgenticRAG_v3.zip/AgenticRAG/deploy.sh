#!/bin/bash

# Production deployment script

echo "Deploying RAG-as-a-Service backend..."

# Build Docker image
docker build -t rag-service-backend .

# Create production environment
docker run -d \
  --name rag-service-backend \
  -p 8000:8000 \
  --env-file .env.production \
  rag-service-backend

echo "Deployment complete!"
echo "API is available at http://localhost:8000"
echo "Documentation at http://localhost:8000/docs"
