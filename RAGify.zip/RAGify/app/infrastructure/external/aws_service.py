import logging
import os
from typing import Any, Dict
from uuid import UUID  # Added import for UUID

import boto3
from botocore.exceptions import ClientError, NoCredentialsError
from sqlalchemy.ext.asyncio import AsyncSession

from app.schemas import AWSValidationResponse

logger = logging.getLogger(__name__)


class AWSService:
    """Service for AWS S3 operations and credential validation"""

    @staticmethod
    async def validate_credentials(
        aws_access_key_id: str,
        aws_secret_access_key: str,
        bucket_name: str,
        folder_path: str,
    ) -> AWSValidationResponse:
        """
        Validate AWS credentials and S3 access permissions

        Args:
            aws_access_key_id: AWS Access Key ID
            aws_secret_access_key: AWS Secret Access Key
            bucket_name: S3 bucket name
            folder_path: S3 folder path

        Returns:
            AWSValidationResponse with validation status
        """
        try:
            # Check for missing or invalid credentials
            if not aws_access_key_id or not aws_secret_access_key:
                logger.warning(
                    "Missing or invalid AWS credentials during validation. Possibly legacy or decryption error."
                )
                return AWSValidationResponse(
                    status="failure",
                    message="Missing or invalid AWS credentials. Please update your dataset credentials.",
                )
            # Create S3 client with provided credentials
            s3_client = boto3.client(
                "s3",
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
            )

            # Test bucket access
            s3_client.head_bucket(Bucket=bucket_name)

            # Test folder access by listing objects
            response = s3_client.list_objects_v2(
                Bucket=bucket_name, Prefix=folder_path.lstrip("/"), MaxKeys=1
            )

            logger.info(
                f"Successfully validated AWS credentials for bucket: {bucket_name}"
            )

            return AWSValidationResponse(
                status="success",
                message="AWS credentials are valid and have access to the specified S3 location",
            )

        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            error_message = e.response["Error"]["Message"]

            logger.error(f"AWS ClientError: {error_code} - {error_message}")

            if error_code == "NoSuchBucket":
                return AWSValidationResponse(
                    status="failure",
                    message=f"Bucket '{bucket_name}' does not exist or is not accessible",
                )
            elif error_code == "AccessDenied":
                return AWSValidationResponse(
                    status="failure",
                    message="Access denied. Check your AWS credentials and permissions",
                )
            else:
                return AWSValidationResponse(
                    status="failure", message=f"AWS Error: {error_message}"
                )

        except NoCredentialsError:
            logger.error("No AWS credentials provided")
            return AWSValidationResponse(
                status="failure", message="AWS credentials are invalid or missing"
            )

        except Exception as e:
            logger.error(f"Unexpected error validating AWS credentials: {str(e)}")
            return AWSValidationResponse(
                status="failure", message=f"Unexpected error: {str(e)}"
            )

    @staticmethod
    def extract_bucket_and_path(s3_url: str) -> tuple[str, str]:
        """
        Extract bucket name and path from S3 URL

        Args:
            s3_url: S3 URL in format s3://bucket-name/path/to/folder

        Returns:
            Tuple of (bucket_name, folder_path)
        """
        if not s3_url.startswith("s3://"):
            raise ValueError("S3 URL must start with 's3://'")

        # Remove s3:// prefix
        path = s3_url[5:]

        # Split bucket and path
        parts = path.split("/", 1)
        bucket_name = parts[0]
        folder_path = parts[1] if len(parts) > 1 else ""

        # Remove any trailing slashes from folder_path
        folder_path = folder_path.rstrip("/")

        return bucket_name, folder_path

    @staticmethod
    def upload_file(
        aws_access_key_id: str,
        aws_secret_access_key: str,
        bucket_name: str,
        file_obj,
        file_name: str,
        folder_path: str = "",
    ) -> Dict[str, Any]:
        """
        Upload a file to S3

        Args:
            aws_access_key_id: AWS Access Key ID
            aws_secret_access_key: AWS Secret Access Key
            bucket_name: S3 bucket name
            file_obj: File-like object to upload
            file_name: Name to use for the file in S3
            folder_path: S3 folder path (optional)

        Returns:
            Dict with upload status and message
        """
        try:
            s3_client = boto3.client(
                "s3",
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
            )
            key = f"{folder_path.rstrip('/')}/{file_name}" if folder_path else file_name
            s3_client.upload_fileobj(file_obj, bucket_name, key)
            logger.info(
                f"File '{file_name}' uploaded to bucket '{bucket_name}' at '{key}'"
            )
            return {
                "status": "success",
                "message": f"File '{file_name}' uploaded successfully to '{key}'",
            }
        except Exception as e:
            logger.error(f"Error uploading file to S3: {str(e)}")
            return {"status": "failure", "message": str(e)}

    @staticmethod
    async def upload_file_by_dataset_id(
        db: AsyncSession, dataset_id: UUID, owner_id: UUID, file_obj, file_name: str
    ) -> Dict[str, Any]:
        """
        Upload a file to S3 using dataset_id and owner_id to fetch credentials

        Args:
            db: Database session
            dataset_id: Dataset ID
            owner_id: ID of the requesting user
            file_obj: File-like object to upload
            file_name: Name to use for the file in S3

        Returns:
            Dict with upload status and message
        """
        from app.services.dataset_service import DatasetService

        creds = await DatasetService.get_aws_credentials(db, dataset_id, owner_id)
        if not creds:
            return {
                "status": "failure",
                "message": "Dataset not found or not owned by user",
            }
        # Robustly handle legacy or decryption error cases
        access_key = creds.get("aws_access_key_id")
        secret_key = creds.get("aws_secret_access_key")
        bucket_name, folder_path = AWSService.extract_bucket_and_path(
            creds["aws_s3_folder_path"]
        )
        logger.debug(
            f"Extracted bucket_name: {bucket_name}, folder_path: '{folder_path}' from aws_s3_folder_path: '{creds['aws_s3_folder_path']}'"
        )
        # Ensure folder_path is normalized (no leading/trailing slashes)
        folder_path = folder_path.strip("/")
        logger.debug(f"Normalized folder_path: '{folder_path}'")
        key = os.path.join(folder_path, file_name) if folder_path else file_name
        logger.debug(f"Uploading to S3 key: {key} (bucket: {bucket_name})")
        if not access_key or not secret_key:
            logger.warning(
                f"Missing or invalid AWS credentials for dataset {dataset_id}. Possibly legacy or decryption error."
            )
            return {
                "status": "failure",
                "message": "Missing or invalid AWS credentials. Please update your dataset credentials.",
            }
        try:
            s3_client = boto3.client(
                "s3", aws_access_key_id=access_key, aws_secret_access_key=secret_key
            )
            s3_client.upload_fileobj(file_obj, bucket_name, key)
            logger.info(
                f"File '{file_name}' uploaded to bucket '{bucket_name}' for dataset {dataset_id} at '{key}'"
            )
            return {
                "status": "success",
                "message": f"File '{file_name}' uploaded successfully to '{key}'",
            }
        except Exception as e:
            logger.error(f"Error uploading file to S3: {str(e)}")
            return {"status": "failure", "message": str(e)}

    @staticmethod
    async def reencrypt_legacy_credentials(
        db: AsyncSession, dataset_id: UUID
    ) -> Dict[str, Any]:
        """
        Re-encrypt legacy (plaintext) AWS credentials for a dataset.

        Args:
            db: Database session
            dataset_id: Dataset ID
        Returns:
            Dict with status and message
        """
        from sqlalchemy import select, update

        from app.infrastructure.database.models import Dataset
        from app.utils.crypto import encrypt_value, is_encrypted

        try:
            result = await db.execute(select(Dataset).where(Dataset.id == dataset_id))
            dataset = result.scalar_one_or_none()
            if not dataset:
                return {"status": "failure", "message": "Dataset not found"}
            updated = False
            if dataset.aws_access_key_id and not is_encrypted(
                dataset.aws_access_key_id
            ):
                dataset.aws_access_key_id = encrypt_value(dataset.aws_access_key_id)
                updated = True
            if dataset.aws_secret_access_key and not is_encrypted(
                dataset.aws_secret_access_key
            ):
                dataset.aws_secret_access_key = encrypt_value(
                    dataset.aws_secret_access_key
                )
                updated = True
            if updated:
                await db.execute(
                    update(Dataset)
                    .where(Dataset.id == dataset_id)
                    .values(
                        aws_access_key_id=dataset.aws_access_key_id,
                        aws_secret_access_key=dataset.aws_secret_access_key,
                    )
                )
                await db.commit()
                logger.info(f"Re-encrypted legacy credentials for dataset {dataset_id}")
                return {"status": "success", "message": "Credentials re-encrypted"}
            else:
                return {
                    "status": "noop",
                    "message": "Credentials already encrypted or missing",
                }
        except Exception as e:
            logger.error(f"Error re-encrypting credentials: {str(e)}")
            return {"status": "failure", "message": str(e)}

    @staticmethod
    async def download_file_by_dataset_object_id(
        db: AsyncSession, dataset_id: UUID, owner_id: UUID, dataset_object_id: UUID
    ) -> Dict[str, Any]:
        """
        Download a file from S3 using dataset_id and dataset_object_id.

        Args:
            db: Database session
            dataset_id: Dataset ID
            owner_id: ID of the requesting user
            dataset_object_id: ID of the dataset object (file)
        Returns:
            Dict with download status, filename, and file bytes (or error message)
        """
        from app.services.dataset_service import DatasetService

        # You may need to implement get_dataset_object_info to fetch filename/key
        creds = await DatasetService.get_aws_credentials(db, dataset_id, owner_id)
        if not creds:
            return {
                "status": "failure",
                "message": "Dataset not found or not owned by user",
            }
        # Fetch file info (filename) from your dataset object table
        dataset_object = await DatasetService.get_dataset_object_info(
            db, dataset_object_id, dataset_id, owner_id
        )
        if not dataset_object:
            return {"status": "failure", "message": "Dataset object not found"}
        file_name = dataset_object["file_name"]  # Adjust this key as needed
        bucket_name, folder_path = AWSService.extract_bucket_and_path(
            creds["aws_s3_folder_path"]
        )
        folder_path = folder_path.strip("/")
        key = os.path.join(folder_path, file_name) if folder_path else file_name
        try:
            s3_client = boto3.client(
                "s3",
                aws_access_key_id=creds["aws_access_key_id"],
                aws_secret_access_key=creds["aws_secret_access_key"],
            )
            file_obj = s3_client.get_object(Bucket=bucket_name, Key=key)
            file_bytes = file_obj["Body"].read()
            logger.info(
                f"File '{file_name}' downloaded from bucket '{bucket_name}' at '{key}'"
            )
            return {
                "status": "success",
                "file_name": file_name,
                "file_bytes": file_bytes,
            }
        except Exception as e:
            logger.error(f"Error downloading file from S3: {str(e)}")
            return {"status": "failure", "message": str(e)}
