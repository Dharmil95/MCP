import { useEffect } from 'react';
import { FaTimes, FaDatabase, FaCog, FaFileAlt, FaCloud } from 'react-icons/fa';
import '../styles/modal.css';

const DatasetModal = ({ 
  isOpen, 
  onClose, 
  formData, 
  onChange, 
  onSubmit, 
  isLoading, 
  error 
}) => {
  // Prevent body scrolling when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-container dataset-modal">
        <div className="modal-header">
          <div className="modal-title">
            <FaDatabase className="modal-icon" />
            <h2>Create New Dataset</h2>
          </div>
          <button className="modal-close-btn" onClick={onClose}>
            <FaTimes />
          </button>
        </div>
        
        <form onSubmit={onSubmit} className="modal-form">
          {error && (
            <div className="error-message">
              <strong>Error:</strong> {error}
            </div>
          )}
          
          {/* Basic Information Section */}
          <div className="form-section">
            <div className="section-header">
              <FaFileAlt className="section-icon" />
              <h3>Basic Information</h3>
            </div>
            <div className="form-group">
              <label htmlFor="name">Dataset Name *</label>
              <input 
                type="text" 
                id="name" 
                name="name" 
                value={formData.name} 
                onChange={onChange} 
                placeholder="Enter dataset name"
                required 
              />
            </div>
            <div className="form-group">
              <label htmlFor="description">Description *</label>
              <textarea 
                id="description" 
                name="description" 
                value={formData.description} 
                onChange={onChange} 
                rows="3" 
                placeholder="Describe what this dataset contains"
                required
              ></textarea>
            </div>
          </div>

          {/* AWS Configuration Section */}
          <div className="form-section">
            <div className="section-header">
              <FaCloud className="section-icon" />
              <h3>AWS Configuration</h3>
            </div>
            <div className="form-group">
              <label htmlFor="aws_s3_folder_path">S3 Folder Path *</label>
              <input 
                type="text" 
                id="aws_s3_folder_path" 
                name="aws_s3_folder_path" 
                value={formData.aws_s3_folder_path} 
                onChange={onChange} 
                placeholder="s3://bucket-name/folder-path"
                required 
              />
              <span className="form-hint">Format: s3://bucket-name/folder-path</span>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="aws_access_key_id">Access Key ID *</label>
                <input 
                  type="text" 
                  id="aws_access_key_id" 
                  name="aws_access_key_id" 
                  value={formData.aws_access_key_id} 
                  onChange={onChange} 
                  placeholder="AKIA..."
                  required 
                />
              </div>
              <div className="form-group">
                <label htmlFor="aws_secret_access_key">Secret Access Key *</label>
                <input 
                  type="password" 
                  id="aws_secret_access_key" 
                  name="aws_secret_access_key" 
                  value={formData.aws_secret_access_key} 
                  onChange={onChange} 
                  placeholder="••••••••••••••••"
                  required 
                />
              </div>
            </div>
          </div>

          {/* Processing Configuration Section */}
          <div className="form-section">
            <div className="section-header">
              <FaCog className="section-icon" />
              <h3>Processing Configuration</h3>
            </div>
            <div className="form-group">
              <label htmlFor="embedding_model">Embedding Model *</label>
              <select id="embedding_model" name="embedding_model" value={formData.embedding_model} onChange={onChange} required>
                <option value="">Select an embedding model</option>
                <option value="text-embedding-ada-002">OpenAI Ada 002 (Recommended)</option>
                <option value="bge-m3">BGE-M3</option>
                <option value="bge-large-en-v1.5">BGE Large v1.5</option>
                <option value="e5-large-v2">E5 Large v2</option>
              </select>
            </div>
            <div className="form-group">
              <label htmlFor="chunking_strategy">Chunking Strategy *</label>
              <select id="chunking_strategy" name="chunking_strategy" value={formData.chunking_strategy} onChange={onChange} required>
                <option value="">Select chunking strategy</option>
                <option value="recursive_character">Recursive Character (Recommended)</option>
                <option value="sliding">Sliding Window</option>
              </select>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="chunk_size">Chunk Size *</label>
                <input 
                  type="number" 
                  id="chunk_size" 
                  name="chunk_size" 
                  value={formData.chunking_parameters?.chunk_size || ''} 
                  onChange={onChange} 
                  min="64" 
                  max="8192" 
                  placeholder="512"
                  required 
                />
                <span className="form-hint">Recommended: 512-1024</span>
              </div>
              <div className="form-group">
                <label htmlFor="chunk_overlap">Chunk Overlap *</label>
                <input 
                  type="number" 
                  id="chunk_overlap" 
                  name="chunk_overlap" 
                  value={formData.chunking_parameters?.chunk_overlap || ''} 
                  onChange={onChange} 
                  min="0" 
                  max="1024" 
                  placeholder="20"
                  required 
                />
                <span className="form-hint">Recommended: 10-20% of chunk size</span>
              </div>
            </div>
          </div>

          {/* File Types Section */}
          <div className="form-section">
            <div className="section-header">
              <FaFileAlt className="section-icon" />
              <h3>Supported File Types</h3>
            </div>
            <div className="form-group">
              <label>Allowed File Types *</label>
              <div className="file-types-grid">
                {[
                  { value: '.pdf', label: 'PDF', description: 'Portable Document Format' },
                  { value: '.txt', label: 'Text', description: 'Plain text files' },
                  { value: '.docx', label: 'Word', description: 'Microsoft Word documents' },
                  { value: '.md', label: 'Markdown', description: 'Markdown files' }
                ].map(type => (
                  <div key={type.value} className="file-type-option">
                    <label className="file-type-checkbox">
                      <input
                        type="checkbox"
                        name="allowed_file_types"
                        value={type.value}
                        checked={formData.allowed_file_types?.includes(type.value) || false}
                        onChange={onChange}
                      />
                      <div className="file-type-info">
                        <span className="file-type-label">{type.label}</span>
                        <span className="file-type-desc">{type.description}</span>
                      </div>
                    </label>
                  </div>
                ))}
              </div>
              <span className="form-hint">Select at least one file type to support</span>
            </div>
          </div>

          <div className="modal-footer">
            <button type="button" className="secondary-btn" onClick={onClose} disabled={isLoading}>
              Cancel
            </button>
            <button type="submit" className="primary-btn" disabled={isLoading}>
              {isLoading ? (
                <>
                  <div className="loading-spinner"></div>
                  Creating Dataset...
                </>
              ) : (
                'Create Dataset'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DatasetModal;
