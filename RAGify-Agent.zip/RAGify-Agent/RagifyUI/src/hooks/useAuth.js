import { useState, useEffect, useCallback } from 'react';
import userService from '../services/userService';
import authService from '../services/authService';

export default function useAuth(navigate) {
  const [username, setUsername] = useState('Loading...');
  const [authDebug, setAuthDebug] = useState({});
  const [userInfo, setUserInfo] = useState({});

  useEffect(() => {
    const accessToken = localStorage.getItem('access_token');
    const refreshToken = localStorage.getItem('refresh_token');
    setAuthDebug({
      hasAccessToken: !!accessToken,
      hasRefreshToken: !!refreshToken,
      accessTokenPreview: accessToken ? `${accessToken.substring(0, 15)}...` : 'No token',
      isAuthenticated: authService.isAuthenticated(),
      timestamp: new Date().toISOString()
    });
    
    // Only fetch user info if we have an access token
    if (accessToken) {
      const fetchUserInfo = async () => {
        try {
          const user = await userService.getCurrentUser();
          setUsername(user.username || user.email || 'User');
          setUserInfo(user);
        } catch (error) {
          setUserInfo({ error: error.message });
          // Redirect to login on network error or unauthorized
          if (error.response?.status === 401 || error.message === 'Network Error') {
            handleLogout();
          }
        }
      };
      fetchUserInfo();
    } else {
      // No token, redirect to login
      navigate('/login');
    }

    // Listen for forced logout events (e.g., token expired/refresh failed)
    const onForcedLogout = () => {
      handleLogout();
    };
    window.addEventListener('auth:logout', onForcedLogout);
    return () => window.removeEventListener('auth:logout', onForcedLogout);
  }, [navigate]);

  const handleLogout = useCallback(() => {
    const confirmed = window.confirm('Are you sure you want to logout?');
    if (confirmed) {
      authService.logout();
      navigate('/login');
    }
  }, [navigate]);

  const handleTestApi = async () => {
    try {
      const user = await userService.getCurrentUser();
      setUserInfo(user);
      alert('User data refreshed successfully!');
    } catch (err) {
      alert(`Error: ${err.message}`);
    }
  };

  const handleForceRefresh = async () => {
    try {
      await authService.refreshToken();
      const accessToken = localStorage.getItem('access_token');
      setAuthDebug({
        ...authDebug,
        hasAccessToken: !!accessToken,
        accessTokenPreview: accessToken ? `${accessToken.substring(0, 15)}...` : 'No token',
        timestamp: new Date().toISOString()
      });
      alert('Token refreshed successfully!');
    } catch (err) {
      alert(`Refresh failed: ${err.message}`);
    }
  };

  return {
    username,
    authDebug,
    userInfo,
    handleLogout,
    handleTestApi,
    handleForceRefresh
  };
}
