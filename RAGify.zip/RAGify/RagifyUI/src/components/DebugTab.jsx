import React from 'react';

const DebugTab = ({ authDebug, userInfo, handleTestApi, handleForceRefresh }) => (
  <div className="settings-content">
    <h2>Debug Information</h2>
    <div className="debug-section">
      <h3>Authentication Status</h3>
      <pre>{JSON.stringify(authDebug, null, 2)}</pre>
      <h3>User Information</h3>
      <pre>{JSON.stringify(userInfo, null, 2)}</pre>
      <h3>API Configuration</h3>
      <p>Base URL: {import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1'}</p>
      <h3>Actions</h3>
      <button className="primary-btn" onClick={handleTestApi} style={{ marginRight: '10px' }}>
        Test API Connection
      </button>
      <button className="primary-btn" onClick={handleForceRefresh}>
        Force Token Refresh
      </button>
    </div>
  </div>
);

export default DebugTab;
