"""Application-level exceptions."""

from typing import Optional


class ApplicationException(Exception):
    """Base application exception."""

    def __init__(self, message: str, code: Optional[str] = None):
        self.message = message
        self.code = code
        super().__init__(message)


class ValidationError(ApplicationException):
    """Validation error exception."""

    def __init__(self, message: str):
        super().__init__(message, "VALIDATION_ERROR")


class NotFoundError(ApplicationException):
    """Entity not found exception."""

    def __init__(self, entity: str, identifier: str):
        message = f"{entity} with identifier '{identifier}' not found"
        super().__init__(message, "NOT_FOUND")


class UnauthorizedError(ApplicationException):
    """Unauthorized access exception."""

    def __init__(self, message: str = "Unauthorized access"):
        super().__init__(message, "UNAUTHORIZED")


class ForbiddenError(ApplicationException):
    """Forbidden access exception."""

    def __init__(self, message: str = "Access forbidden"):
        super().__init__(message, "FORBIDDEN")


class ProcessingError(ApplicationException):
    """Processing error exception."""

    def __init__(self, message: str):
        super().__init__(message, "PROCESSING_ERROR")


class ConfigurationError(ApplicationException):
    """Configuration error exception."""

    def __init__(self, message: str):
        super().__init__(message, "CONFIGURATION_ERROR")


# User-specific exceptions
class UserNotFoundError(NotFoundError):
    """User not found exception."""

    def __init__(self, identifier: str):
        super().__init__("User", identifier)


class InvalidCredentialsError(UnauthorizedError):
    """Invalid credentials exception."""

    def __init__(self):
        super().__init__("Invalid email or password")


class UserInactiveError(ForbiddenError):
    """User inactive exception."""

    def __init__(self):
        super().__init__("User account is inactive")


# Dataset-specific exceptions
class DatasetNotFoundError(NotFoundError):
    """Dataset not found exception."""

    def __init__(self, identifier: str):
        super().__init__("Dataset", identifier)


class DatasetProcessingError(ProcessingError):
    """Dataset processing error exception."""

    def __init__(self, message: str):
        super().__init__(f"Dataset processing failed: {message}")


class DatasetValidationError(ValidationError):
    """Dataset validation error exception."""

    def __init__(self, message: str):
        super().__init__(f"Dataset validation failed: {message}")


# AWS-specific exceptions
class AWSError(ApplicationException):
    """AWS operation error exception."""

    def __init__(self, message: str):
        super().__init__(f"AWS operation failed: {message}", "AWS_ERROR")


class S3Error(AWSError):
    """S3 operation error exception."""

    def __init__(self, message: str):
        super().__init__(f"S3 operation failed: {message}")
