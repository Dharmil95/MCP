import React, { useState } from 'react';
import LoadingScreen from './LoadingScreen';
import useLoadingScreen from '../hooks/useLoadingScreen';

/**
 * Example component showing different ways to use LoadingScreen
 * This is for demonstration purposes - you can use these patterns in your actual components
 */
const LoadingScreenExample = () => {
  const [showBasicLoading, setShowBasicLoading] = useState(false);
  const [showProgressLoading, setShowProgressLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  
  // Using the custom hook
  const { 
    isLoading: hookLoading, 
    progress: hookProgress, 
    startLoading, 
    stopLoading, 
    updateProgress 
  } = useLoadingScreen('upload');

  // Basic loading example
  const handleBasicLoading = () => {
    setShowBasicLoading(true);
    setTimeout(() => setShowBasicLoading(false), 3000);
  };

  // Progress loading example
  const handleProgressLoading = () => {
    setShowProgressLoading(true);
    setProgress(0);
    
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setShowProgressLoading(false);
          return 0;
        }
        return prev + 10;
      });
    }, 200);
  };

  // Hook-based loading example
  const handleHookLoading = () => {
    startLoading(true);
    
    const interval = setInterval(() => {
      updateProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          stopLoading();
          return 0;
        }
        return prev + 15;
      });
    }, 150);
  };

  if (showBasicLoading) {
    return (
      <LoadingScreen 
        message="Loading Example"
        subtitle="This is a basic loading screen"
      />
    );
  }

  if (showProgressLoading) {
    return (
      <LoadingScreen 
        message="Uploading Files"
        subtitle="Processing your documents"
        showProgress={true}
        progress={progress}
      />
    );
  }

  if (hookLoading) {
    return (
      <LoadingScreen 
        message="Uploading Files"
        subtitle="Processing your documents"
        showProgress={true}
        progress={hookProgress}
      />
    );
  }

  return (
    <div style={{ padding: '2rem', maxWidth: '600px', margin: '0 auto' }}>
      <h1>LoadingScreen Usage Examples</h1>
      
      <div style={{ marginBottom: '2rem' }}>
        <h2>Basic Loading</h2>
        <p>Simple loading screen without progress bar</p>
        <button onClick={handleBasicLoading} style={{ padding: '10px 20px', marginRight: '10px' }}>
          Show Basic Loading
        </button>
      </div>

      <div style={{ marginBottom: '2rem' }}>
        <h2>Progress Loading</h2>
        <p>Loading screen with progress bar</p>
        <button onClick={handleProgressLoading} style={{ padding: '10px 20px', marginRight: '10px' }}>
          Show Progress Loading
        </button>
      </div>

      <div style={{ marginBottom: '2rem' }}>
        <h2>Hook-based Loading</h2>
        <p>Using the custom useLoadingScreen hook</p>
        <button onClick={handleHookLoading} style={{ padding: '10px 20px', marginRight: '10px' }}>
          Show Hook Loading
        </button>
      </div>

      <div style={{ marginBottom: '2rem' }}>
        <h2>Usage in Components</h2>
        <p>Here's how to use it in your actual components:</p>
        <pre style={{ 
          background: '#f5f5f5', 
          padding: '1rem', 
          borderRadius: '4px',
          overflow: 'auto'
        }}>
{`// Basic usage
if (isLoading) {
  return (
    <LoadingScreen 
      message="Loading..."
      subtitle="Please wait"
    />
  );
}

// With progress
if (isLoading) {
  return (
    <LoadingScreen 
      message="Uploading Files"
      subtitle="Processing your documents"
      showProgress={true}
      progress={uploadProgress}
    />
  );
}

// Using the hook
const { isLoading, startLoading, stopLoading } = useLoadingScreen('upload');

if (isLoading) {
  return <LoadingScreen {...LoadingComponent()} />;
}`}
        </pre>
      </div>
    </div>
  );
};

export default LoadingScreenExample;
