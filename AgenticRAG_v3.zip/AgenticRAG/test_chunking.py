"""
Test script for verifying text chunking with LangChain.
"""
import os
import logging
from app.services.document_processor import DocumentProcessor
from uuid import uuid4

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_chunk_text():
    """Test the chunking functionality with a sample text"""
    # Create a sample text
    sample_text = """
    This is the first paragraph of the text. It contains some sentences.
    This is the second sentence of the first paragraph.
    
    This is the second paragraph. It also has multiple sentences.
    The sentences in this paragraph are of varying lengths.
    
    This third paragraph demonstrates how the recursive splitter works
    with different types of content. It should try to keep paragraphs
    together when possible, but split at logical boundaries like
    sentences and words when needed.
    
    """
    # Multiply the text to make it larger for testing
    sample_text = sample_text * 5
    
    # Create DocumentProcessor instance with dummy values
    processor = DocumentProcessor(
        dataset_id=uuid4(),
        aws_credentials={"aws_access_key_id": "dummy", "aws_secret_access_key": "dummy"}
    )
    
    # Test with different chunk sizes and overlaps
    test_cases = [
        (100, 0),    # Small chunks, no overlap
        (200, 20),   # Medium chunks, small overlap
        (500, 50),   # Larger chunks, medium overlap
    ]
    
    for chunk_size, chunk_overlap in test_cases:
        logger.info(f"Testing with chunk_size={chunk_size}, chunk_overlap={chunk_overlap}")
        chunks = processor.chunk_text(sample_text, chunk_size, chunk_overlap)
        
        # Log the results
        logger.info(f"Input text size: {len(sample_text)} characters")
        logger.info(f"Generated {len(chunks)} chunks")
        
        # Log some sample chunks to see the splitting
        for i, chunk in enumerate(chunks[:3]):  # Show first 3 chunks
            logger.info(f"Chunk {i} ({len(chunk)} chars): {chunk[:50]}...")
            
        # Verify chunks are roughly the expected size
        for i, chunk in enumerate(chunks):
            # Some chunks might be smaller than chunk_size if they're at natural break points
            assert len(chunk) <= chunk_size, f"Chunk {i} too large: {len(chunk)} > {chunk_size}"
        
        # Check total content preservation (allowing for some whitespace differences)
        reconstructed = " ".join(chunk.strip() for chunk in chunks)
        original_normalized = " ".join(sample_text.split())
        
        # Check if core content is preserved (allowing for some overlap)
        assert len(reconstructed) >= len(original_normalized), \
            "Content may have been lost during chunking"
        
        logger.info(f"Test passed for chunk_size={chunk_size}, chunk_overlap={chunk_overlap}")
        logger.info("-" * 50)
    
    logger.info("All chunking tests passed!")

if __name__ == "__main__":
    test_chunk_text()
