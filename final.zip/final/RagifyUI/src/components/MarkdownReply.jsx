import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

export default function MarkdownReply({ text }) {
  return (
    <ReactMarkdown
      remarkPlugins={[remarkGfm]}
      components={{
        table: ({node, ...props}) => (
          <table className="markdown-message" {...props} />
        ),
        th: ({node, ...props}) => (
          <th className="markdown-message" {...props} />
        ),
        td: ({node, ...props}) => (
          <td className="markdown-message" {...props} />
        ),
      }}
    >
      {text}
    </ReactMarkdown>
  );
}
