"""Application exceptions package."""

from app.application.exceptions.app_exceptions import (
    ApplicationException,
    AWSError,
    ConfigurationError,
    DatasetNotFoundError,
    DatasetProcessingError,
    DatasetValidationError,
    ForbiddenError,
    InvalidCredentialsError,
    NotFoundError,
    ProcessingError,
    S3Error,
    UnauthorizedError,
    UserInactiveError,
    UserNotFoundError,
    ValidationError,
)

__all__ = [
    "ApplicationException",
    "ValidationError",
    "NotFoundError",
    "UnauthorizedError",
    "ForbiddenError",
    "ProcessingError",
    "ConfigurationError",
    "UserNotFoundError",
    "InvalidCredentialsError",
    "UserInactiveError",
    "DatasetNotFoundError",
    "DatasetProcessingError",
    "DatasetValidationError",
    "AWSError",
    "S3Error",
]
