import uuid
from typing import List, Optional

from fastapi_permissions import Allow, Authenticated, Everyone
from fastapi_users.db import SQLAlchemyBaseUserTableUUID
from passlib.context import CryptContext
from pgvector.sqlalchemy import Vector
from sqlalchemy import (
    JSON,
    UUID,
    Boolean,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.future import select
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

Base = declarative_base()

# Password context for hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


class User(SQLAlchemyBaseUserTableUUID, Base):
    """User model extending fastapi-users base user table"""

    __tablename__ = "users"

    # Additional fields beyond fastapi-users base
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    datasets = relationship(
        "Dataset", back_populates="owner", cascade="all, delete-orphan"
    )

    def __acl__(self):
        """Access Control List for user permissions"""
        return [
            (Allow, Everyone, "view"),
            (Allow, f"user:{self.id}", "edit"),
            (Allow, f"user:{self.id}", "delete"),
        ]

    @classmethod
    async def get_by_email(cls, db: AsyncSession, email: str) -> Optional["User"]:
        """Get user by email"""
        query = select(cls).where(cls.email == email)
        result = await db.execute(query)
        return result.scalar_one_or_none()

    @classmethod
    async def get_by_id(cls, db: AsyncSession, user_id: str) -> Optional["User"]:
        """Get user by ID"""
        query = select(cls).where(cls.id == user_id)
        result = await db.execute(query)
        return result.scalar_one_or_none()

    @classmethod
    async def create(cls, db: AsyncSession, user_data) -> "User":
        """Create a new user"""
        hashed_password = pwd_context.hash(user_data.password)
        user = cls(
            email=user_data.email,
            hashed_password=hashed_password,
            is_active=True,
            is_verified=False,
            is_superuser=False,
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)
        return user

    @classmethod
    async def authenticate(
        cls, db: AsyncSession, email: str, password: str
    ) -> Optional["User"]:
        """Authenticate user with email and password"""
        user = await cls.get_by_email(db, email)
        if not user:
            return None
        if not pwd_context.verify(password, user.hashed_password):
            return None
        return user


class Dataset(Base):
    """Dataset model representing a collection of files for RAG processing"""

    __tablename__ = "datasets"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    owner_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    embedding_model = Column(String(100), nullable=False)
    chunking_strategy = Column(String(50), nullable=False)
    chunking_parameters = Column(JSON, nullable=False)
    allowed_file_types = Column(JSON, nullable=False)  # List of file extensions
    aws_s3_folder_path = Column(Text, nullable=False)
    aws_access_key_id = Column(
        Text, nullable=True
    )  # Changed to Text for encrypted value
    aws_secret_access_key = Column(
        Text, nullable=True
    )  # Changed to Text for encrypted value
    status = Column(String(50), nullable=False, default="created")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    owner = relationship("User", back_populates="datasets")
    dataset_objects = relationship(
        "DatasetObject", back_populates="dataset", cascade="all, delete-orphan"
    )

    def __acl__(self):
        """Access Control List for dataset permissions"""
        return [
            (Allow, f"user:{self.owner_id}", "view"),
            (Allow, f"user:{self.owner_id}", "edit"),
            (Allow, f"user:{self.owner_id}", "delete"),
        ]


class DatasetObject(Base):
    """DatasetObject model representing individual files within a dataset"""

    __tablename__ = "dataset_objects"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    dataset_id = Column(UUID(as_uuid=True), ForeignKey("datasets.id"), nullable=False)
    file_name = Column(String(255), nullable=False)
    original_s3_path = Column(Text, nullable=False)
    processed_s3_path = Column(Text, nullable=True)
    pgvector_collection_name = Column(String(255), nullable=False)
    status = Column(String(50), nullable=False, default="pending")
    last_processed_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    error_message = Column(
        Text, nullable=True
    )  # Stores error details if processing fails

    # Relationships
    dataset = relationship("Dataset", back_populates="dataset_objects")

    def __acl__(self):
        """Access Control List for dataset object permissions"""
        return [
            (Allow, f"user:{self.dataset.owner_id}", "view"),
            (Allow, f"user:{self.dataset.owner_id}", "edit"),
            (Allow, f"user:{self.dataset.owner_id}", "delete"),
        ]


class EmbeddingVector(Base):
    """Model for storing vector embeddings with PGVector"""

    __tablename__ = "embedding_vectors"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    dataset_object_id = Column(
        UUID(as_uuid=True), ForeignKey("dataset_objects.id"), nullable=False
    )
    chunk_text = Column(Text, nullable=False)
    chunk_index = Column(Integer, nullable=False)  # Position within the document
    embedding = Column(Vector(1536), nullable=False)  # Updated to PGVector type
    file_metadata = Column(
        JSON, nullable=True
    )  # Additional metadata for the chunk (renamed from 'metadata')
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    dataset_object = relationship("DatasetObject")

    def __acl__(self):
        """Access Control List for embedding vector permissions"""
        return [
            (Allow, f"user:{self.dataset_object.dataset.owner_id}", "view"),
        ]
