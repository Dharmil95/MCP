import api from './api';
import axios from 'axios';

// We'll use the main API instance since our Vite proxy is now properly configured to route
// requests to the appropriate services based on the path

const datasetService = {
  /**
   * Create a new dataset with the given data
   * @param {Object} datasetData - Dataset information
   * @returns {Promise} - Response from the API
   */
  createDataset: async (datasetData) => {
    try {
      const response = await api.post('/datasets', datasetData);
      return response.data;
    } catch (error) {
      console.error('Error creating dataset:', error);
      throw error;
    }
  },

  /**
   * Get all datasets for the current user
   * @returns {Promise} - Response from the API containing datasets
   */
  getDatasets: async (skip = 0, limit = 100) => {
    try {
      const response = await api.get('/datasets', {
        params: { skip, limit }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching datasets:', error);
      throw error;
    }
  },

  /**
   * Get a specific dataset by ID
   * @param {string} datasetId - ID of the dataset to fetch
   * @returns {Promise} - Response from the API containing dataset details
   */
  getDatasetById: async (datasetId) => {
    try {
      const response = await api.get(`/datasets/${datasetId}`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching dataset ${datasetId}:`, error);
      throw error;
    }
  },

  /**
   * Update an existing dataset
   * @param {string} datasetId - ID of the dataset to update
   * @param {Object} datasetData - Updated dataset information
   * @returns {Promise} - Response from the API
   */
  updateDataset: async (datasetId, datasetData) => {
    try {
      const response = await api.put(`/datasets/${datasetId}`, datasetData);
      return response.data;
    } catch (error) {
      console.error(`Error updating dataset ${datasetId}:`, error);
      throw error;
    }
  },

  /**
   * Delete a dataset
   * @param {string} datasetId - ID of the dataset to delete
   * @returns {Promise} - Response from the API
   */
  deleteDataset: async (datasetId) => {
    try {
      const response = await api.delete(`/datasets/${datasetId}`);
      return response.data;
    } catch (error) {
      console.error(`Error deleting dataset ${datasetId}:`, error);
      throw error;
    }
  },

  /**
   * Get all files/objects in a dataset
   * @param {string} datasetId - ID of the dataset
   * @returns {Promise} - Array of files in the dataset
   */
  getDatasetFiles: async (datasetId) => {
    try {
      const response = await api.get(`/dataset_objects/${datasetId}`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching files for dataset ${datasetId}:`, error);
      throw error;
    }
  },

  /**
   * Get all files/objects in a dataset with status
   * @param {string} datasetId - ID of the dataset
   * @returns {Promise} - Array of files with status
   */
  getDatasetFilesWithStatus: async (datasetId) => {
    try {
      const response = await api.get(`/dataset_objects/objects_with_status/${datasetId}`);
      return response.data;
    } catch (error) {
      console.error(`Error fetching files with status for dataset ${datasetId}:`, error);
      throw error;
    }
  },

  /**
   * Upload a file to a dataset
   * @param {string} datasetId - ID of the dataset
   * @param {File} file - File to upload
   * @returns {Promise} - Upload response
   */
  uploadFileToDataset: async (datasetId, file) => {
    const formData = new FormData();
    formData.append('file', file);
    try {
      const response = await api.post(`/aws/upload-file?dataset_id=${datasetId}`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      return response.data;
    } catch (error) {
      console.error(`Error uploading file to dataset ${datasetId}:`, error);
      throw error;
    }
  },

  /**
   * Delete a file from a dataset
   * @param {string} fileId - ID of the file to delete
   * @returns {Promise} - Response from the API
   */
  deleteFile: async (fileId) => {
    try {
      const response = await api.delete(`/dataset_objects/object/${fileId}`);
      return response.data;
    } catch (error) {
      console.error(`Error deleting file ${fileId}:`, error);
      throw error;
    }
  },

  /**
   * Process a dataset (start processing all files)
   * @param {string} datasetId - ID of the dataset to process
   * @returns {Promise} - Response from the API
   */
  processDataset: async (datasetId) => {
    try {
      const response = await api.post(`/datasets/${datasetId}/process`, {});
      return response.data;
    } catch (error) {
      console.error(`Error processing dataset ${datasetId}:`, error);
      throw error;
    }
  },
};

export default datasetService;
