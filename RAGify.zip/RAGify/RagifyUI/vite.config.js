import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      // Proxy API requests to the OAuth service (default API endpoint)
      '/api/v1/auth': {
        target: 'http://localhost:8000',
        changeOrigin: true,
        secure: false
      },
      '/api/v1/users': {
        target: 'http://localhost:8000',
        changeOrigin: true,
        secure: false
      },
      // Proxy dataset API requests to the catalog service
      '/api/v1/datasets': {
        target: 'http://localhost:8000',
        changeOrigin: true,
        secure: false
      },
      '/api/v1/dataset_objects': {
        target: 'http://localhost:8000',
        changeOrigin: true,
        secure: false
      },
      // Proxy chat API requests to the backend
      '/api/v1/chat': {
        target: 'http://localhost:8000',
        changeOrigin: true,
        secure: false
      }
    }
  }
})
