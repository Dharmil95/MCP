import React, { useMemo } from 'react';
import { FaSearch } from 'react-icons/fa';
import ChatHeader from './chat/ChatHeader';
import ChatInput from './chat/ChatInput';
import CitationGroup from './chat/CitationGroup';
import { useFullscreen } from '../hooks/useFullscreen';
import '../styles/chat-markdown.css';
import '../styles/search-fullscreen.css';
import '../styles/search.css'
import '../styles/search-header.css';
import '../styles/search-citations.css';
import MarkdownReply from './MarkdownReply';

const SearchTab = ({
  messages,
  query,
  setQuery,
  isSearching,
  handleSearch,
  chatContainerRef,
  selectedCitation,
  handleCitationClick,
  closeCitationModal
}) => {
  const { isFullscreen, toggleFullscreen, getFullscreenStyles } = useFullscreen();

  const containerStyles = useMemo(() => ({
    height: isFullscreen ? '100vh' : 'calc(100vh - 200px)',
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
    ...getFullscreenStyles()
  }), [isFullscreen, getFullscreenStyles]);

  const handleSendMessage = (message) => {
    setQuery(message);
    handleSearch(message);
  };

  return (
    <div className={`search-content ${isFullscreen ? 'fullscreen' : ''}`} style={containerStyles}>
      <ChatHeader
        title="Search Documents"
        icon={FaSearch}
        status={isSearching ? 'thinking' : 'online'}
        isThinking={isSearching}
        onToggleFullscreen={toggleFullscreen}
        isFullscreen={isFullscreen}
        showNewChatButton={false}
      />

      {/* Messages Container */}
      <div className="chat-container" ref={chatContainerRef}>
        {messages.map((message, index) => (
          <div 
            key={index}
            className={`chat-message ${message.role === 'user' ? 'user' : 'ai'}-message`}
          >
            <div className="message-content">
              {message.role === 'user' ? (
                <p>{message.content}</p>
              ) : (
                <div className="markdown-message">
                  <MarkdownReply text={message.content} />
                  <CitationGroup
                    citations={message.citations}
                    selectedCitation={selectedCitation}
                    onCitationClick={handleCitationClick}
                  />
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <ChatInput
        onSendMessage={handleSendMessage}
        placeholder="Search your documents..."
        disabled={isSearching}
        isLoading={isSearching}
      />
    </div>
  );
};

export default SearchTab;
