import logging
import uuid
from typing import Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, status

from app.schemas import SuccessResponse
from app.utils.auth import get_current_user
from app.utils.session_store import SessionStore

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/sessions", tags=["sessions"]) 


@router.post("/start")
async def start_session(_: dict = Depends(get_current_user)):
    session_id = str(uuid.uuid4())
    SessionStore.create_session(session_id)
    return {"session_id": session_id}


@router.get("/{session_id}")
async def get_session(session_id: str, _: dict = Depends(get_current_user)):
    state = SessionStore.get_session(session_id)
    if state is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Session not found")
    return {"session_id": session_id, "state": state}


@router.post("/{session_id}")
async def update_session(session_id: str, payload: Dict, _: dict = Depends(get_current_user)):
    if SessionStore.get_session(session_id) is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Session not found")
    SessionStore.update_session(session_id, payload)
    return SuccessResponse(message="Session updated", data={"session_id": session_id})


