"""User repository implementation."""

from typing import List, Optional
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from ....domain.entities.user import User as UserEntity
from ....domain.repositories.user_repository import UserRepository
from ..models import User as UserModel


class UserRepositoryImpl(UserRepository):
    """SQLAlchemy implementation of UserRepository."""

    def __init__(self, db_session: AsyncSession):
        self.db_session = db_session

    def _model_to_entity(self, user_model: UserModel) -> UserEntity:
        """Convert database model to domain entity."""
        return UserEntity(
            id=user_model.id,
            email=user_model.email,
            is_active=user_model.is_active,
            is_verified=user_model.is_verified,
            is_superuser=user_model.is_superuser,
            created_at=user_model.created_at,
            updated_at=user_model.updated_at,
        )

    def _entity_to_model(self, user_entity: UserEntity) -> UserModel:
        """Convert domain entity to database model."""
        return UserModel(
            id=user_entity.id,
            email=user_entity.email,
            is_active=user_entity.is_active,
            is_verified=user_entity.is_verified,
            is_superuser=user_entity.is_superuser,
            created_at=user_entity.created_at,
            updated_at=user_entity.updated_at,
        )

    async def get_by_id(self, user_id: UUID) -> Optional[UserEntity]:
        """Get user by ID."""
        query = select(UserModel).where(UserModel.id == user_id)
        result = await self.db_session.execute(query)
        user_model = result.scalar_one_or_none()

        if user_model is None:
            return None

        return self._model_to_entity(user_model)

    async def get_by_email(self, email: str) -> Optional[UserEntity]:
        """Get user by email."""
        query = select(UserModel).where(UserModel.email == email)
        result = await self.db_session.execute(query)
        user_model = result.scalar_one_or_none()

        if user_model is None:
            return None

        return self._model_to_entity(user_model)

    async def create(self, user: UserEntity) -> UserEntity:
        """Create a new user."""
        user_model = self._entity_to_model(user)
        self.db_session.add(user_model)
        await self.db_session.commit()
        await self.db_session.refresh(user_model)

        return self._model_to_entity(user_model)

    async def update(self, user: UserEntity) -> UserEntity:
        """Update an existing user."""
        query = select(UserModel).where(UserModel.id == user.id)
        result = await self.db_session.execute(query)
        user_model = result.scalar_one_or_none()

        if user_model is None:
            raise ValueError(f"User with ID {user.id} not found")

        # Update model fields from entity
        user_model.email = user.email
        user_model.is_active = user.is_active
        user_model.is_verified = user.is_verified
        user_model.is_superuser = user.is_superuser
        user_model.updated_at = user.updated_at

        await self.db_session.commit()
        await self.db_session.refresh(user_model)

        return self._model_to_entity(user_model)

    async def delete(self, user_id: UUID) -> bool:
        """Delete a user by ID."""
        query = select(UserModel).where(UserModel.id == user_id)
        result = await self.db_session.execute(query)
        user_model = result.scalar_one_or_none()

        if user_model is None:
            return False

        await self.db_session.delete(user_model)
        await self.db_session.commit()
        return True

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[UserEntity]:
        """Get all users with pagination."""
        query = select(UserModel).offset(skip).limit(limit)
        result = await self.db_session.execute(query)
        user_models = result.scalars().all()

        return [self._model_to_entity(user_model) for user_model in user_models]

    async def exists_by_email(self, email: str) -> bool:
        """Check if user exists by email."""
        query = select(UserModel.id).where(UserModel.email == email)
        result = await self.db_session.execute(query)
        return result.scalar_one_or_none() is not None
