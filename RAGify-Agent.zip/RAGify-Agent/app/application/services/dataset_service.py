import logging
from typing import List, Optional
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload

from app.infrastructure.database.models import Dataset, DatasetObject, User
from app.schemas import DatasetCreate, DatasetStatus, DatasetUpdate
from app.utils.crypto import decrypt_string, encrypt_string

logger = logging.getLogger(__name__)


class DatasetService:
    """Service for dataset operations"""

    @staticmethod
    async def create_dataset(
        db: AsyncSession, dataset_data: DatasetCreate, owner_id: UUID
    ) -> Dataset:
        """
        Create a new dataset

        Args:
            db: Database session
            dataset_data: Dataset creation data
            owner_id: ID of the user creating the dataset

        Returns:
            Created dataset
        """
        # Create dataset with AWS credentials if provided
        dataset_dict = dataset_data.dict()
        if dataset_dict.get("aws_access_key_id"):
            dataset_dict["aws_access_key_id"] = encrypt_string(
                dataset_dict["aws_access_key_id"]
            )
        if dataset_dict.get("aws_secret_access_key"):
            dataset_dict["aws_secret_access_key"] = encrypt_string(
                dataset_dict["aws_secret_access_key"]
            )
        dataset_dict["owner_id"] = owner_id
        dataset = Dataset(**dataset_dict)
        db.add(dataset)
        await db.commit()
        await db.refresh(dataset)

        logger.info(f"Created dataset {dataset.id} for user {owner_id}")
        return dataset

    @staticmethod
    async def get_datasets_by_owner(
        db: AsyncSession, owner_id: UUID, skip: int = 0, limit: int = 100
    ) -> List[Dataset]:
        """
        Get datasets owned by a specific user

        Args:
            db: Database session
            owner_id: ID of the dataset owner
            skip: Number of records to skip
            limit: Maximum number of records to return

        Returns:
            List of datasets
        """
        query = (
            select(Dataset)
            .where(Dataset.owner_id == owner_id)
            .offset(skip)
            .limit(limit)
        )
        result = await db.execute(query)
        return result.scalars().all()

    @staticmethod
    async def get_dataset_by_id(
        db: AsyncSession, dataset_id: UUID, owner_id: UUID
    ) -> Optional[Dataset]:
        """
        Get a specific dataset by ID, ensuring ownership

        Args:
            db: Database session
            dataset_id: ID of the dataset
            owner_id: ID of the requesting user

        Returns:
            Dataset if found and owned by user, None otherwise
        """
        query = select(Dataset).where(
            Dataset.id == dataset_id, Dataset.owner_id == owner_id
        )
        result = await db.execute(query)
        return result.scalar_one_or_none()

    @staticmethod
    async def update_dataset(
        db: AsyncSession, dataset_id: UUID, dataset_data: DatasetUpdate, owner_id: UUID
    ) -> Optional[Dataset]:
        """
        Update a dataset

        Args:
            db: Database session
            dataset_id: ID of the dataset to update
            dataset_data: Updated dataset data
            owner_id: ID of the requesting user

        Returns:
            Updated dataset if successful, None otherwise
        """
        dataset = await DatasetService.get_dataset_by_id(db, dataset_id, owner_id)
        if not dataset:
            return None

        # Update only provided fields
        update_data = dataset_data.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(dataset, field, value)

        await db.commit()
        await db.refresh(dataset)

        logger.info(f"Updated dataset {dataset_id}")
        return dataset

    @staticmethod
    async def delete_dataset(
        db: AsyncSession, dataset_id: UUID, owner_id: UUID
    ) -> bool:
        """
        Delete a dataset

        Args:
            db: Database session
            dataset_id: ID of the dataset to delete
            owner_id: ID of the requesting user

        Returns:
            True if successful, False otherwise
        """
        dataset = await DatasetService.get_dataset_by_id(db, dataset_id, owner_id)
        if not dataset:
            return False

        await db.delete(dataset)
        await db.commit()

        logger.info(f"Deleted dataset {dataset_id}")
        return True

    @staticmethod
    async def get_dataset_objects(
        db: AsyncSession, dataset_id: UUID, owner_id: UUID
    ) -> List[DatasetObject]:
        """
        Get all objects in a dataset

        Args:
            db: Database session
            dataset_id: ID of the dataset
            owner_id: ID of the requesting user

        Returns:
            List of dataset objects
        """
        # First verify dataset ownership
        dataset = await DatasetService.get_dataset_by_id(db, dataset_id, owner_id)
        if not dataset:
            return []

        query = select(DatasetObject).where(DatasetObject.dataset_id == dataset_id)
        result = await db.execute(query)
        return result.scalars().all()

    @staticmethod
    async def get_dataset_status(
        db: AsyncSession, dataset_id: UUID, owner_id: UUID
    ) -> Optional[DatasetStatus]:
        """
        Get dataset processing status

        Args:
            db: Database session
            dataset_id: ID of the dataset
            owner_id: ID of the requesting user

        Returns:
            Dataset status if found, None otherwise
        """
        dataset = await DatasetService.get_dataset_by_id(db, dataset_id, owner_id)
        if not dataset:
            return None

        # Get dataset objects to calculate statistics
        objects = await DatasetService.get_dataset_objects(db, dataset_id, owner_id)

        total_files = len(objects)
        processed_files = len([obj for obj in objects if obj.status == "completed"])
        failed_files = len([obj for obj in objects if obj.status == "failed"])

        return DatasetStatus(
            dataset_id=dataset_id,
            status=dataset.status,
            total_files=total_files,
            processed_files=processed_files,
            failed_files=failed_files,
            last_updated=dataset.updated_at,
        )

    @staticmethod
    async def get_aws_credentials(
        db: AsyncSession, dataset_id: UUID, owner_id: UUID
    ) -> Optional[dict]:
        """
        Get AWS credentials for a dataset if owned by the user

        Args:
            db: Database session
            dataset_id: ID of the dataset
            owner_id: ID of the requesting user

        Returns:
            Dict with AWS credentials if found and owned by user, None otherwise
        """
        dataset = await DatasetService.get_dataset_by_id(db, dataset_id, owner_id)
        if not dataset:
            return None
        return {
            "aws_access_key_id": decrypt_string(
                getattr(dataset, "aws_access_key_id", None)
            ),
            "aws_secret_access_key": decrypt_string(
                getattr(dataset, "aws_secret_access_key", None)
            ),
            "aws_s3_folder_path": getattr(dataset, "aws_s3_folder_path", None),
        }

    @staticmethod
    async def delete_dataset_object_by_id(
        db: AsyncSession, dataset_object_id: UUID, owner_id: UUID
    ) -> bool:
        """
        Delete a dataset object (file) by its ID, ensuring ownership

        Args:
            db: Database session
            dataset_object_id: ID of the dataset object
            owner_id: ID of the requesting user

        Returns:
            True if deleted, False otherwise
        """
        # Fetch the object and ensure ownership
        query = select(DatasetObject).where(DatasetObject.id == dataset_object_id)
        result = await db.execute(query)
        obj = result.scalar_one_or_none()
        if not obj:
            return False
        # Check ownership by verifying the parent dataset
        dataset = await DatasetService.get_dataset_by_id(db, obj.dataset_id, owner_id)
        if not dataset:
            return False
        await db.delete(obj)
        await db.commit()
        logger.info(
            f"Deleted dataset object {dataset_object_id} from dataset {obj.dataset_id}"
        )
        return True

    @staticmethod
    async def get_unprocessed_s3_files(
        db: AsyncSession,
        dataset_id: UUID,
        owner_id: UUID,
        aws_credentials: dict,
        allowed_file_types: list = None,
    ) -> list:
        """
        Return S3 files for a dataset that do not have a corresponding DatasetObject record.

        Args:
            db: Database session
            dataset_id: Dataset ID
            owner_id: ID of the requesting user
            aws_credentials: AWS credentials for S3 access
            allowed_file_types: Optional list of allowed file extensions

        Returns:
            List of file_info dicts for unprocessed files
        """
        # Get processed files from DB
        query = select(DatasetObject).where(DatasetObject.dataset_id == dataset_id)
        result = await db.execute(query)
        processed_files = {obj.key for obj in result.scalars().all()}
        # List all files in S3
        from app.application.services.document_processor import DocumentProcessor

        processor = DocumentProcessor(dataset_id, aws_credentials)
        dataset = await DatasetService.get_dataset_by_id(db, dataset_id, owner_id)
        s3_files = await processor.list_s3_files(
            dataset.aws_s3_folder_path, allowed_file_types or dataset.allowed_file_types
        )
        # Filter files not in processed_files
        unprocessed = [f for f in s3_files if f["key"] not in processed_files]
        return unprocessed
