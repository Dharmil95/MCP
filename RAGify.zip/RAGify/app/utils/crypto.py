import logging
import os

from cryptography.fernet import Fernet

logger = logging.getLogger(__name__)


# You should store this key securely (e.g., environment variable, secret manager)
def generate_key():
    return Fernet.generate_key()


# Load your key from a secure place
FERNET_KEY = os.environ.get("FERNET_KEY")
if FERNET_KEY is None:
    # For development only: generate a key if not set
    FERNET_KEY = generate_key()
fernet = Fernet(FERNET_KEY)


def encrypt_string(plain_text: str) -> str:
    if plain_text is None:
        return None
    return fernet.encrypt(plain_text.encode()).decode()


def decrypt_string(encrypted_text: str) -> str:
    if encrypted_text is None:
        return None
    try:
        return fernet.decrypt(encrypted_text.encode()).decode()
    except Exception as e:
        # Handle cases where decryption fails (wrong key, unencrypted data, etc.)
        logger.warning(f"Failed to decrypt string, returning original: {str(e)}")
        # If decryption fails, assume the text was never encrypted and return as-is
        return encrypted_text
