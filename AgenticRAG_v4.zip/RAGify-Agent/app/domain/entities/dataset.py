"""Dataset domain entity."""

from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional
from uuid import UUID


@dataclass
class Dataset:
    """Dataset domain entity representing a collection of files for RAG processing."""

    id: UUID
    owner_id: UUID
    name: str
    description: Optional[str]
    embedding_model: str
    chunking_strategy: str
    chunking_parameters: Dict
    allowed_file_types: List[str]
    aws_s3_folder_path: str
    aws_access_key_id: Optional[str]
    aws_secret_access_key: Optional[str]
    status: str
    created_at: datetime
    updated_at: datetime

    def __post_init__(self):
        """Validate dataset data after initialization."""
        if not self.name.strip():
            raise ValueError("Dataset name cannot be empty")

        if not self.embedding_model.strip():
            raise ValueError("Embedding model must be specified")

        if not self.chunking_strategy.strip():
            raise ValueError("Chunking strategy must be specified")

        if not self.allowed_file_types:
            raise ValueError("At least one file type must be allowed")

        valid_statuses = ["created", "processing", "ready", "failed"]
        if self.status not in valid_statuses:
            raise ValueError(f"Invalid status. Must be one of: {valid_statuses}")

    def is_ready_for_processing(self) -> bool:
        """Check if dataset is ready for processing."""
        return self.status == "created"

    def can_be_queried(self) -> bool:
        """Check if dataset can be queried."""
        return self.status == "ready"

    def supports_file_type(self, file_extension: str) -> bool:
        """Check if dataset supports a specific file type."""
        return file_extension.lower() in [ft.lower() for ft in self.allowed_file_types]
