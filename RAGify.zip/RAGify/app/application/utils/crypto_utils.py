"""Cryptographic utilities for encrypting and decrypting sensitive data."""

import logging
import os

from cryptography.fernet import Fernet

logger = logging.getLogger(__name__)


def generate_key():
    """Generate a new Fernet encryption key."""
    return Fernet.generate_key()


# Load encryption key from environment variable
FERNET_KEY = os.environ.get("FERNET_KEY")
if FERNET_KEY is None:
    # For development only: generate a key if not set
    logger.warning("FERNET_KEY not set, generating a new key for development")
    FERNET_KEY = generate_key()

fernet = Fernet(FERNET_KEY)


def encrypt_string(plain_text: str) -> str:
    """
    Encrypt a string using Fernet encryption.
    
    Args:
        plain_text: The string to encrypt
        
    Returns:
        Encrypted string
    """
    if plain_text is None:
        return None
    return fernet.encrypt(plain_text.encode()).decode()


def decrypt_string(encrypted_text: str) -> str:
    """
    Decrypt a string using Fernet encryption.
    
    Args:
        encrypted_text: The encrypted string to decrypt
        
    Returns:
        Decrypted string
    """
    if encrypted_text is None:
        return None
    try:
        return fernet.decrypt(encrypted_text.encode()).decode()
    except Exception as e:
        # Handle cases where decryption fails (wrong key, unencrypted data, etc.)
        logger.warning(f"Failed to decrypt string, returning original: {str(e)}")
        # If decryption fails, assume the text was never encrypted and return as-is
        return encrypted_text


def is_encrypted(text: str) -> bool:
    """
    Check if a string appears to be encrypted.
    
    Args:
        text: The string to check
        
    Returns:
        True if the string appears to be encrypted, False otherwise
    """
    if not text:
        return False
    
    try:
        # Try to decrypt - if it works, it was encrypted
        fernet.decrypt(text.encode())
        return True
    except Exception:
        # If decryption fails, it's likely not encrypted
        return False
