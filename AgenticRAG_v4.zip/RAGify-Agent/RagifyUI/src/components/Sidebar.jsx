import React from 'react';
import { FaChartBar, FaDatabase, FaSearch, FaSignOutAlt, FaComments, FaChevronRight } from 'react-icons/fa';

const Sidebar = ({ activeTab, setActiveTab, handleLogout, currentAgentSession }) => {
  return (
    <div style={{
      width: '220px',
      height: '100vh',
      backgroundColor: '#ffffff',
      borderRight: '1px solid #e5e7eb',
      display: 'flex',
      flexDirection: 'column',
      position: 'fixed',
      left: 0,
      top: 0,
      zIndex: 100
    }}>
      {/* Header */}
      <div style={{
        padding: '24px 20px',
        borderBottom: '1px solid #e5e7eb',
        textAlign: 'center'
      }}>
        <h2 style={{
          margin: 0,
          fontSize: '1.35rem',
          fontWeight: '700',
          color: '#111827',
          letterSpacing: '0.2px'
        }}>
          RAGify
        </h2>
      </div>

      {/* Navigation */}
      <nav style={{
        flex: 1,
        padding: '16px 0',
        overflowY: 'auto'
      }}>
        <ul style={{
          listStyle: 'none',
          padding: 0,
          margin: 0
        }}>
          {/* Dashboard */}
          <li 
            onClick={() => setActiveTab('dashboard')}
            style={{
              padding: '12px 20px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              borderLeft: activeTab === 'dashboard' ? '3px solid #3b82f6' : '3px solid transparent',
              backgroundColor: activeTab === 'dashboard' ? '#f8fafc' : 'transparent',
              transition: 'all 0.2s ease',
              marginBottom: '4px'
            }}
            onMouseEnter={(e) => {
              if (activeTab !== 'dashboard') {
                e.target.style.backgroundColor = '#f1f5f9';
              }
            }}
            onMouseLeave={(e) => {
              if (activeTab !== 'dashboard') {
                e.target.style.backgroundColor = 'transparent';
              }
            }}
          >
            <FaChartBar style={{
              color: activeTab === 'dashboard' ? '#3b82f6' : '#6b7280',
              fontSize: '18px',
              marginRight: '16px',
              flexShrink: 0
            }} />
            <span style={{
              color: activeTab === 'dashboard' ? '#111827' : '#374151',
              fontWeight: activeTab === 'dashboard' ? '600' : '500',
              fontSize: '14px'
            }}>
              Dashboard
            </span>
          </li>

          {/* Datasets */}
          <li 
            onClick={() => setActiveTab('datasets')}
            style={{
              padding: '12px 20px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              borderLeft: activeTab === 'datasets' ? '3px solid #3b82f6' : '3px solid transparent',
              backgroundColor: activeTab === 'datasets' ? '#f8fafc' : 'transparent',
              transition: 'all 0.2s ease',
              marginBottom: '4px'
            }}
            onMouseEnter={(e) => {
              if (activeTab !== 'datasets') {
                e.target.style.backgroundColor = '#f1f5f9';
              }
            }}
            onMouseLeave={(e) => {
              if (activeTab !== 'datasets') {
                e.target.style.backgroundColor = 'transparent';
              }
            }}
          >
            <FaDatabase style={{
              color: activeTab === 'datasets' ? '#3b82f6' : '#6b7280',
              fontSize: '18px',
              marginRight: '16px',
              flexShrink: 0
            }} />
            <span style={{
              color: activeTab === 'datasets' ? '#111827' : '#374151',
              fontWeight: activeTab === 'datasets' ? '600' : '500',
              fontSize: '14px'
            }}>
              Datasets
            </span>
          </li>

          {/* Search */}
          <li 
            onClick={() => setActiveTab('search')}
            style={{
              padding: '12px 20px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              borderLeft: activeTab === 'search' ? '3px solid #3b82f6' : '3px solid transparent',
              backgroundColor: activeTab === 'search' ? '#f8fafc' : 'transparent',
              transition: 'all 0.2s ease',
              marginBottom: '4px'
            }}
            onMouseEnter={(e) => {
              if (activeTab !== 'search') {
                e.target.style.backgroundColor = '#f1f5f9';
              }
            }}
            onMouseLeave={(e) => {
              if (activeTab !== 'search') {
                e.target.style.backgroundColor = 'transparent';
              }
            }}
          >
            <FaSearch style={{
              color: activeTab === 'search' ? '#3b82f6' : '#6b7280',
              fontSize: '18px',
              marginRight: '16px',
              flexShrink: 0
            }} />
            <span style={{
              color: activeTab === 'search' ? '#111827' : '#374151',
              fontWeight: activeTab === 'search' ? '600' : '500',
              fontSize: '14px'
            }}>
              Search
            </span>
          </li>

          {/* Agent Chat */}
          <li 
            onClick={() => setActiveTab('agent-chat')}
            style={{
              padding: '12px 20px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              borderLeft: activeTab === 'agent-chat' ? '3px solid #3b82f6' : '3px solid transparent',
              backgroundColor: activeTab === 'agent-chat' ? '#f8fafc' : 'transparent',
              transition: 'all 0.2s ease',
              marginBottom: '4px'
            }}
            onMouseEnter={(e) => {
              if (activeTab !== 'agent-chat') {
                e.target.style.backgroundColor = '#f1f5f9';
              }
            }}
            onMouseLeave={(e) => {
              if (activeTab !== 'agent-chat') {
                e.target.style.backgroundColor = 'transparent';
              }
            }}
          >
            <FaComments style={{
              color: activeTab === 'agent-chat' ? '#3b82f6' : '#6b7280',
              fontSize: '18px',
              marginRight: '16px',
              flexShrink: 0
            }} />
            <span style={{
              color: activeTab === 'agent-chat' ? '#111827' : '#374151',
              fontWeight: activeTab === 'agent-chat' ? '600' : '500',
              fontSize: '14px'
            }}>
              Agent Chat
            </span>
          </li>
        </ul>
      </nav>

      {/* Active Chat Preview */}
      {currentAgentSession && (
        <div style={{
          margin: '16px',
          backgroundColor: '#f9fafb',
          borderRadius: '8px',
          border: '1px solid #e5e7eb',
          overflow: 'hidden'
        }}>
          <div 
            onClick={() => setActiveTab('agent-chat')}
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '12px 16px',
              backgroundColor: '#f3f4f6',
              cursor: 'pointer',
              transition: 'background-color 0.2s ease'
            }}
            onMouseEnter={(e) => {
              e.target.style.backgroundColor = '#e5e7eb';
            }}
            onMouseLeave={(e) => {
              e.target.style.backgroundColor = '#f3f4f6';
            }}
          >
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontSize: '14px',
              fontWeight: '600',
              color: '#111827'
            }}>
              <FaComments style={{ color: '#6b7280', fontSize: '16px' }} />
              <span>{currentAgentSession.agent?.name || currentAgentSession.agent?.id}</span>
            </div>
            <FaChevronRight style={{ color: '#9ca3af', fontSize: '12px' }} />
          </div>
        </div>
      )}

      {/* Footer */}
      <div style={{
        padding: '16px 20px',
        borderTop: '1px solid #e5e7eb',
        marginTop: 'auto'
      }}>
        <button 
          onClick={handleLogout}
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '100%',
            padding: '12px 16px',
            backgroundColor: '#fef2f2',
            border: '1px solid #fecaca',
            borderRadius: '8px',
            color: '#dc2626',
            cursor: 'pointer',
            fontWeight: '600',
            fontSize: '14px',
            transition: 'all 0.2s ease'
          }}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = '#fee2e2';
            e.target.style.transform = 'translateY(-1px)';
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = '#fef2f2';
            e.target.style.transform = 'translateY(0)';
          }}
        >
          <FaSignOutAlt style={{
            color: '#dc2626',
            fontSize: '16px',
            marginRight: '12px'
          }} />
          Logout
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
