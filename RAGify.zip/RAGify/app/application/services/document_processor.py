import asyncio
import json
import logging
import os
import tempfile
from datetime import datetime
from io import BytesIO
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from uuid import UUID

import aiofiles
import docx

# Document processing imports
import PyPDF2

# LangChain text splitters
from langchain_text_splitters import (
    CharacterTextSplitter,
    MarkdownHeaderTextSplitter,
    RecursiveCharacterTextSplitter,
)
from sqlalchemy import insert, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.application.facades.aws_facade import AWSS3Facade
from app.application.facades.embedding_facade import EmbeddingFacade
from app.core.config import settings
from app.domain.database import get_async_session
from app.domain.models import Dataset, DatasetObject, EmbeddingVector

logger = logging.getLogger(__name__)


class DocumentProcessor:
    """Service for processing documents and generating embeddings using facades"""

    def __init__(self, dataset_id: UUID, aws_credentials: Dict[str, str]):
        self.dataset_id = dataset_id
        self.aws_credentials = aws_credentials
        # Initialize facades
        self.aws_facade = AWSS3Facade()
        self.embedding_facade = EmbeddingFacade(settings.openai_api_key) if settings.openai_api_key else None

    async def list_s3_files(
        self, s3_path: str, allowed_extensions: List[str]
    ) -> List[Dict[str, Any]]:
        """List files in S3 bucket with filtering using AWS facade"""
        try:
            # Parse S3 path
            if not s3_path.startswith("s3://"):
                raise ValueError("Invalid S3 path format")

            path_parts = s3_path[5:].split("/", 1)
            bucket_name = path_parts[0]
            folder_path = path_parts[1] if len(path_parts) > 1 else ""

            # Use AWS facade to list files
            files = await self.aws_facade.list_bucket_files(
                self.aws_credentials["aws_access_key_id"],
                self.aws_credentials["aws_secret_access_key"],
                bucket_name, 
                folder_path, 
                allowed_extensions
            )

            logger.info(f"Found {len(files)} files in {s3_path}")
            return files

        except Exception as e:
            logger.error(f"Error listing S3 files: {str(e)}")
            raise

    async def download_file(self, bucket: str, key: str, local_path: str) -> bool:
        """Download a single file from S3 using AWS facade"""
        try:
            file_bytes = await self.aws_facade.download_file(
                self.aws_credentials["aws_access_key_id"],
                self.aws_credentials["aws_secret_access_key"],
                bucket, 
                key
            )
            
            # Write bytes to local file
            async with aiofiles.open(local_path, 'wb') as f:
                await f.write(file_bytes)
            
            logger.info(f"Downloaded {key} to {local_path}")
            return True
        except Exception as e:
            logger.error(f"Error downloading {key}: {str(e)}")
            return False

    def extract_text_from_pdf(self, file_path: str) -> str:
        """Extract text from PDF file with aggressive memory optimization"""
        try:
            import gc
            import os

            # Check file size first
            file_size = os.path.getsize(file_path)
            logger.info(f"Processing PDF file size: {file_size} bytes")

            # For very large files, process even smaller chunks
            if file_size > 10 * 1024 * 1024:  # 10MB
                chunk_size = 2  # Process 2 pages at a time for large files
            else:
                chunk_size = 5  # Process 5 pages at a time for smaller files

            text = ""

            with open(file_path, "rb") as file:
                pdf_reader = PyPDF2.PdfReader(file)
                total_pages = len(pdf_reader.pages)
                logger.info(f"PDF has {total_pages} pages")

                # Process in very small chunks to avoid memory issues
                for i in range(0, total_pages, chunk_size):
                    chunk_text = ""
                    end_page = min(i + chunk_size, total_pages)

                    logger.info(f"Processing pages {i} to {end_page-1}")

                    for page_num in range(i, end_page):
                        try:
                            page = pdf_reader.pages[page_num]
                            page_text = page.extract_text()

                            # Only add non-empty text
                            if page_text.strip():
                                chunk_text += page_text + "\n"

                            # Clear page from memory immediately
                            del page

                        except Exception as e:
                            logger.warning(
                                f"Error extracting page {page_num}: {str(e)}"
                            )
                            continue

                    text += chunk_text

                    # Force garbage collection after each chunk
                    del chunk_text
                    gc.collect()

                    # Log memory usage periodically
                    if i % 20 == 0:
                        logger.info(
                            f"Processed {i} pages, current text length: {len(text)}"
                        )

                logger.info(f"Final extracted text length: {len(text)} characters")
                return text.strip()

        except Exception as e:
            logger.error(f"Error extracting text from PDF {file_path}: {str(e)}")
            return ""

    def extract_text_from_docx(self, file_path: str) -> str:
        """Extract text from DOCX file"""
        try:
            doc = docx.Document(file_path)
            text = ""
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"
            return text.strip()
        except Exception as e:
            logger.error(f"Error extracting text from DOCX {file_path}: {str(e)}")
            return ""

    def extract_text_from_txt(self, file_path: str) -> str:
        """Extract text from TXT/MD file"""
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                return file.read().strip()
        except Exception as e:
            logger.error(f"Error extracting text from TXT {file_path}: {str(e)}")
            return ""

    def extract_text(self, file_path: str, file_extension: str) -> str:
        """Extract text based on file type"""
        text = ""  # Ensure text is always initialized
        if file_extension == ".pdf":
            text = self.extract_text_from_pdf(file_path)
        elif file_extension == ".docx":
            text = self.extract_text_from_docx(file_path)
        elif file_extension in [".txt", ".md"]:
            text = self.extract_text_from_txt(file_path)
        else:
            logger.warning(f"Unsupported file type: {file_extension}")
        return text

    def chunk_text(self, text: str, chunk_size: int, chunk_overlap: int) -> List[str]:
        """Split text into chunks with overlap using LangChain's RecursiveCharacterTextSplitter"""
        if not text:
            return []

        # Use RecursiveCharacterTextSplitter for intelligent text splitting
        # This splitter tries to maintain paragraph and sentence structure
        # and falls back to character splitting only if needed
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            length_function=len,
            separators=[
                # Try to split by paragraph first, then sentences, then words
                "\n\n",  # Paragraph breaks
                "\n",  # Line breaks
                ".",  # Sentences
                "!",  # Exclamation
                "?",  # Question
                ";",  # Semicolon
                ":",  # Colon
                ",",  # Comma
                " ",  # Words
                "",  # Characters (fallback)
            ],
        )

        # Process text into chunks
        try:
            logger.info(
                f"Splitting text using RecursiveCharacterTextSplitter: {len(text)} chars into ~{chunk_size} char chunks"
            )
            chunks = text_splitter.split_text(text)
            logger.info(f"Generated {len(chunks)} chunks")
            return chunks
        except Exception as e:
            logger.error(f"Error splitting text: {e}")
            return []

    async def create_dataset_object(
        self, db: AsyncSession, file_info: Dict[str, Any]
    ) -> DatasetObject:
        """Create a dataset object record"""
        dataset_object = DatasetObject(
            dataset_id=self.dataset_id,
            file_name=Path(file_info["key"]).name,
            original_s3_path=file_info["key"],
            pgvector_collection_name=f"dataset_{self.dataset_id}_{Path(file_info['key']).stem}",
            status="pending",
        )

        db.add(dataset_object)
        await db.commit()
        await db.refresh(dataset_object)

        return dataset_object

    async def update_object_status(
        self,
        db: AsyncSession,
        object_id: UUID,
        status: str,
        chunks_count: int = 0,
        error_message: str = None,
    ):
        """Update dataset object status"""
        update_data = {"status": status, "last_processed_at": datetime.utcnow()}

        if error_message is not None:
            update_data["error_message"] = error_message

        stmt = (
            update(DatasetObject)
            .where(DatasetObject.id == object_id)
            .values(**update_data)
        )

        await db.execute(stmt)
        await db.commit()

    async def store_embeddings(
        self,
        db: AsyncSession,
        object_id: UUID,
        chunks: List[str],
        embeddings: List[List[float]],
    ):
        """Store embeddings in the database"""
        try:
            import ast

            embedding_records = []

            for i, (chunk, embedding) in enumerate(zip(chunks, embeddings)):
                # Ensure embedding is a list of floats, not a string
                if isinstance(embedding, str):
                    embedding = ast.literal_eval(embedding)
                embedding_record = EmbeddingVector(
                    dataset_object_id=object_id,
                    chunk_text=chunk,
                    chunk_index=i,
                    embedding=embedding,
                    created_at=datetime.utcnow(),
                )
                embedding_records.append(embedding_record)

            # Batch insert for better performance
            db.add_all(embedding_records)
            await db.commit()

            logger.info(
                f"Stored {len(embedding_records)} embeddings for object {object_id}"
            )

        except Exception as e:
            logger.error(f"Error storing embeddings: {str(e)}")
            raise


class EmbeddingService:
    """Service for generating and managing embeddings"""

    def __init__(self, api_key: str):
        self.api_key = api_key
        self.model = "text-embedding-ada-002"

    async def generate_embeddings(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for a list of texts"""
        try:
            from openai import AsyncOpenAI

            client = AsyncOpenAI(api_key=self.api_key)

            # Process in batches to avoid API limits
            embeddings = []
            batch_size = settings.embedding_batch_size

            for i in range(0, len(texts), batch_size):
                batch = texts[i : i + batch_size]

                response = await client.embeddings.create(model=self.model, input=batch)

                batch_embeddings = [item.embedding for item in response.data]
                embeddings.extend(batch_embeddings)

                # Small delay to respect rate limits
                await asyncio.sleep(0.1)

            return embeddings

        except Exception as e:
            logger.error(f"Error generating embeddings: {str(e)}")
            raise
