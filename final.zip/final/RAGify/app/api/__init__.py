from fastapi import APIRouter


from app.api.routers import (
    auth_router,
    aws_router,
    chat_router,
    dataset_objects_router,
    datasets_router,
    users_router,
    agents_router,
    sessions_router,
)


api_router = APIRouter()


# Include all routers
api_router.include_router(auth_router)
api_router.include_router(users_router)
api_router.include_router(datasets_router)
api_router.include_router(dataset_objects_router)
api_router.include_router(aws_router)
api_router.include_router(chat_router)
api_router.include_router(agents_router)
api_router.include_router(sessions_router)
