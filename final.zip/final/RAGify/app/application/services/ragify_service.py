"""Agent-facing dataset helpers for RAG workflows.

This module provides simple HTTP helpers agents can call to discover and
query datasets exposed by the backend API. It intentionally avoids touching
the application DB-focused `DatasetService` class so that agent code and
internal services remain separated.
"""

from typing import Any, Dict, List, Optional
import requests
import asyncio
import httpx
from app.core.config import settings


def _api_headers(auth_header: Optional[str]) -> Dict[str, str]:
    headers = {"accept": "application/json"}
    if auth_header:
        headers["Authorization"] = auth_header
    return headers


def discover_datasets(
    api_base: str, auth_header: Optional[str]
) -> List[Dict[str, Any]]:
    """Return list of datasets by calling the backend datasets endpoint.

    Returns an empty list on error.
    """
    url = f"{api_base}/datasets?skip=0&limit={settings.ragify_discover_limit}"
    try:
        resp = requests.get(
            url,
            headers=_api_headers(auth_header),
            timeout=settings.ragify_discover_timeout,
        )
        if resp.status_code == 200:
            data = resp.json()
            return data if isinstance(data, list) else []
        return []
    except Exception:
        return []


def query_dataset(
    api_base: str, auth_header: Optional[str], dataset_id: str, query: str
) -> Dict[str, Any]:
    """Query a single dataset's chat endpoint and return the JSON response.

    On failure returns a dict with an "error" key.
    """
    url = f"{api_base}/chat/{dataset_id}"
    payload = {"query": query, "top_k": 3}
    try:
        resp = requests.post(
            url,
            headers={**_api_headers(auth_header), "Content-Type": "application/json"},
            json=payload,
            timeout=30,
        )
        if resp.status_code == 200:
            return resp.json()
        return {"error": f"HTTP {resp.status_code}"}
    except Exception as e:
        return {"error": str(e)}


async def a_discover_datasets(
    api_base: str, auth_header: Optional[str]
) -> List[Dict[str, Any]]:
    """Async version of discover_datasets using httpx.AsyncClient.

    Returns an empty list on error.
    """
    url = f"{api_base}/datasets?skip=0&limit={settings.ragify_discover_limit}"
    try:
        async with httpx.AsyncClient(
            timeout=float(settings.ragify_discover_timeout)
        ) as client:
            resp = await client.get(url, headers=_api_headers(auth_header))
            if resp.status_code == 200:
                data = resp.json()
                return data if isinstance(data, list) else []
            return []
    except Exception:
        return []


async def a_query_dataset(
    api_base: str, auth_header: Optional[str], dataset_id: str, query: str
) -> Dict[str, Any]:
    """Async version of query_dataset using httpx.AsyncClient.

    Returns a dict or an error dict on failure.
    """
    url = f"{api_base}/chat/{dataset_id}"
    payload = {"query": query, "top_k": settings.ragify_top_k}
    headers = {**_api_headers(auth_header), "Content-Type": "application/json"}
    try:
        async with httpx.AsyncClient(
            timeout=float(settings.ragify_query_timeout)
        ) as client:
            resp = await client.post(url, headers=headers, json=payload)
            if resp.status_code == 200:
                return resp.json()
            return {"error": f"HTTP {resp.status_code}"}
    except Exception as e:
        return {"error": str(e)}
