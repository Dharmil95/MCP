"""Utilities for enhanced request logging."""

import json
import logging
from typing import Dict, Any, Optional

from fastapi import Request


def add_log_context(request: Request, **kwargs):
    """
    Add context variables to the request state for logging.
    
    Args:
        request: The FastAPI request object
        **kwargs: Key-value pairs to add to the request state
        
    Example:
        ```python
        @router.get("/datasets/{dataset_id}")
        async def get_dataset(request: Request, dataset_id: str):
            # Add context for logging
            add_log_context(
                request,
                resource_id=dataset_id,
                operation="read"
            )
            
            # Process request...
            return dataset
        ```
    """
    for key, value in kwargs.items():
        setattr(request.state, key, value)


def get_request_metadata(request: Request) -> Dict[str, Any]:
    """
    Extract common metadata from a request object.
    
    Args:
        request: The FastAPI request object
        
    Returns:
        Dict containing common request metadata
    """
    metadata = {
        "path": request.url.path,
        "method": request.method,
        "client_ip": request.client.host if request.client else "unknown",
    }
    
    # Add headers that might be useful (exclude auth headers for security)
    if "user-agent" in request.headers:
        metadata["user_agent"] = request.headers.get("user-agent")
    
    if "x-forwarded-for" in request.headers:
        metadata["forwarded_for"] = request.headers.get("x-forwarded-for")
        
    if "x-correlation-id" in request.headers:
        metadata["correlation_id"] = request.headers.get("x-correlation-id")
        
    # Add request_id if available
    if hasattr(request.state, "request_id"):
        metadata["request_id"] = request.state.request_id
        
    return metadata


async def log_request_body(request: Request, logger: logging.Logger, log_level: int = logging.DEBUG) -> None:
    """
    Log the request body for debugging purposes.
    Only use in development/debugging as it may log sensitive data.
    
    Args:
        request: The FastAPI request object
        logger: The logger instance to use
        log_level: The logging level (default: DEBUG)
    """
    body = await request.body()
    if body:
        try:
            # Try to parse as JSON first
            body_json = json.loads(body)
            logger.log(log_level, "Request body", extra={"request_body": body_json})
        except json.JSONDecodeError:
            # If not JSON, log as plain text
            logger.log(log_level, f"Request body (raw): {body.decode('utf-8', errors='replace')}")
