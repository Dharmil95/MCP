import React from 'react';

const LoadingSpinner = ({ 
  size = 'medium', 
  variant = 'dark', 
  className = '', 
  text = '',
  container = false 
}) => {
  const sizeClasses = {
    small: 'loading-spinner--small',
    medium: 'loading-spinner',
    large: 'loading-spinner--large'
  };

  const variantClasses = {
    light: 'loading-spinner--light',
    dark: 'loading-spinner--dark'
  };

  const spinnerClasses = [
    sizeClasses[size],
    variantClasses[variant],
    className
  ].filter(Boolean).join(' ');

  if (container) {
    return (
      <div className="loading-container">
        <div className={spinnerClasses}></div>
        {text && <p className="loading-text">{text}</p>}
      </div>
    );
  }

  return <div className={spinnerClasses}></div>;
};

export default LoadingSpinner;





