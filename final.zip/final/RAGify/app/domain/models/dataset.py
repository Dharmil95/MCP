"""Dataset and DatasetObject models."""

import uuid
from typing import TYPE_CHECKING

from fastapi_permissions import Allow
from sqlalchemy import (
    JSON,
    UUID,
    Column,
    DateTime,
    ForeignKey,
    String,
    Text,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.domain.database import Base

if TYPE_CHECKING:
    from app.domain.models.user import User


class Dataset(Base):
    """Dataset model representing a collection of files for RAG processing"""

    __tablename__ = "datasets"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    owner_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    embedding_model = Column(String(100), nullable=False)
    chunking_strategy = Column(String(50), nullable=False)
    chunking_parameters = Column(JSON, nullable=False)
    allowed_file_types = Column(JSON, nullable=False)  # List of file extensions
    aws_s3_folder_path = Column(Text, nullable=False)
    aws_access_key_id = Column(
        Text, nullable=True
    )  # Changed to Text for encrypted value
    aws_secret_access_key = Column(
        Text, nullable=True
    )  # Changed to Text for encrypted value
    status = Column(String(50), nullable=False, default="created")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    owner = relationship("User", back_populates="datasets")
    dataset_objects = relationship(
        "DatasetObject", back_populates="dataset", cascade="all, delete-orphan"
    )

    def __acl__(self):
        """Access Control List for dataset permissions"""
        return [
            (Allow, f"user:{self.owner_id}", "view"),
            (Allow, f"user:{self.owner_id}", "edit"),
            (Allow, f"user:{self.owner_id}", "delete"),
        ]


class DatasetObject(Base):
    """DatasetObject model representing individual files within a dataset"""

    __tablename__ = "dataset_objects"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    dataset_id = Column(UUID(as_uuid=True), ForeignKey("datasets.id"), nullable=False)
    file_name = Column(String(255), nullable=False)
    original_s3_path = Column(Text, nullable=False)
    processed_s3_path = Column(Text, nullable=True)
    pgvector_collection_name = Column(String(255), nullable=False)
    status = Column(String(50), nullable=False, default="pending")
    last_processed_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    error_message = Column(
        Text, nullable=True
    )  # Stores error details if processing fails

    # Relationships
    dataset = relationship("Dataset", back_populates="dataset_objects")

    def __acl__(self):
        """Access Control List for dataset object permissions"""
        return [
            (Allow, f"user:{self.dataset.owner_id}", "view"),
            (Allow, f"user:{self.dataset.owner_id}", "edit"),
            (Allow, f"user:{self.dataset.owner_id}", "delete"),
        ]
