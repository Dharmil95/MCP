"""Create initial tables

Revision ID: 001
Revises: 
Create Date: 2025-07-11 06:48:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
from pgvector.sqlalchemy import Vector


# revision identifiers, used by Alembic.
revision = '001'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS vector")
    # Create users table
    op.create_table('users',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('email', sa.String(length=320), nullable=False),
        sa.Column('hashed_password', sa.String(length=1024), nullable=False),
        sa.Column('is_active', sa.Boolean(), nullable=False),
        sa.Column('is_superuser', sa.Boolean(), nullable=False),
        sa.Column('is_verified', sa.Boolean(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('ix_users_email', 'users', ['email'], unique=True)

    # Create datasets table
    op.create_table('datasets',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('owner_id', sa.UUID(), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('embedding_model', sa.String(length=100), nullable=False),
        sa.Column('chunking_strategy', sa.String(length=50), nullable=False),
        sa.Column('chunking_parameters', sa.JSON(), nullable=False),
        sa.Column('allowed_file_types', sa.JSON(), nullable=False),
        sa.Column('aws_s3_folder_path', sa.Text(), nullable=False),
        sa.Column('aws_access_key_id', sa.Text(), nullable=True),  # Changed to Text for encrypted value
        sa.Column('aws_secret_access_key', sa.Text(), nullable=True),  # Changed to Text for encrypted value
        sa.Column('status', sa.String(length=50), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['owner_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )

    # Create dataset_objects table
    op.create_table('dataset_objects',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('dataset_id', sa.UUID(), nullable=False),
        sa.Column('file_name', sa.String(length=255), nullable=False),
        sa.Column('original_s3_path', sa.Text(), nullable=False),
        sa.Column('processed_s3_path', sa.Text(), nullable=True),
        sa.Column('pgvector_collection_name', sa.String(length=255), nullable=False),
        sa.Column('status', sa.String(length=50), nullable=False),
        sa.Column('last_processed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.ForeignKeyConstraint(['dataset_id'], ['datasets.id'], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint('id')
    )

    op.create_table('embedding_vectors',
        sa.Column('id', sa.UUID(), nullable=False),
        sa.Column('dataset_object_id', sa.UUID(), nullable=False),
        sa.Column('chunk_text', sa.Text(), nullable=False),
        sa.Column('chunk_index', sa.Integer(), nullable=False),
        sa.Column('embedding', Vector(1536), nullable=False),  # <-- update here
        sa.Column('chunk_metadata', sa.JSON(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=True),
        sa.ForeignKeyConstraint(['dataset_object_id'], ['dataset_objects.id'], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint('id')
    )


def downgrade() -> None:
    op.drop_table('embedding_vectors')
    op.drop_table('dataset_objects')
    op.drop_table('datasets')
    op.drop_index('ix_users_email', table_name='users')
    op.drop_table('users')
