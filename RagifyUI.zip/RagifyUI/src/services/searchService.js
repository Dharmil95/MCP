import api from './api';

const searchService = {
  /**
   * Query chat endpoint using all datasets
   * @param {string} query - The user query
   * @param {number} top_k - Number of top results
   * @returns {Promise} - ChatResponse from backend
   */
  chatAll: async (query, top_k = 5) => {
    try {
      const response = await api.post('/chat/all', { query, top_k });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  /**
   * Query chat endpoint for a specific dataset
   * @param {string} datasetId - Dataset UUID
   * @param {string} query - The user query
   * @param {number} top_k - Number of top results
   * @returns {Promise} - ChatResponse from backend
   */
  chatDataset: async (datasetId, query, top_k = 5) => {
    try {
      const response = await api.post(`/chat/${datasetId}`, { query, top_k });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  /**
   * Query chat endpoint using all datasets (for chat UI)
   * @param {string} query - The user query
   * @param {number} top_k - Number of top results
   * @returns {Promise} - ChatResponse from backend
   */
  searchQuery: async (query, top_k = 5) => {
    // Uses chatAll for chat functionality
    return await searchService.chatAll(query, top_k);
  }
};

export default searchService;
