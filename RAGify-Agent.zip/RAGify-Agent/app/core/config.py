from functools import lru_cache
from typing import List, Optional

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # App Configuration
    app_name: str = "RAG-as-a-Service"
    app_version: str = "1.0.0"
    debug: bool = True
    allowed_hosts: List[str] = ["*"]

    # Database Configuration
    database_url: str
    test_database_url: str = "sqlite+aiosqlite:///./test.db"

    # Security
    secret_key: str
    refresh_token_secret_key: str
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7

    # Celery Configuration
    celery_broker_url: str = "redis://localhost:6379/0"
    celery_result_backend: str = "redis://localhost:6379/0"

    # OpenAI Configuration
    openai_api_key: str = ""

    # Langfuse Configuration
    langfuse_public_key: Optional[str] = None
    langfuse_secret_key: Optional[str] = None
    langfuse_host: Optional[str] = None

    # LangGraph / Agents
    agents_directory: str = "app/agents"

    # AWS Configuration (for processing)
    aws_region: str = "us-east-1"

    # Processing Configuration
    max_concurrent_files: int = 10
    chunk_batch_size: int = 100
    embedding_batch_size: int = 100

    # Redis Configuration
    redis_url: str = "redis://localhost:6379/0"

    # Email Configuration
    smtp_tls: bool = True
    smtp_port: int = 587
    smtp_host: str = "smtp.gmail.com"
    smtp_user: Optional[str] = None
    smtp_password: Optional[str] = None

    # Supported Models and Strategies
    supported_embedding_models: List[str] = [
        "text-embedding-ada-002",
        "text-embedding-3-small",
        "text-embedding-3-large",
    ]

    supported_chunking_strategies: List[str] = [
        "recursive_character",
        "markdown",
        "semantic",
    ]

    supported_file_types: List[str] = [".pdf", ".txt", ".md", ".docx", ".csv", ".json"]

    # Encryption
    fernet_key: str

    class Config:
        env_file = ".env"
        case_sensitive = False
        extra = "ignore"  # Ignore extra environment variables


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
