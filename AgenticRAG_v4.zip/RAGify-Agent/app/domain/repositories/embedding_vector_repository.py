"""Embedding vector repository interface."""

from abc import ABC, abstractmethod
from typing import List, Optional, Tuple
from uuid import UUID

from ..entities.embedding_vector import EmbeddingVector


class EmbeddingVectorRepository(ABC):
    """Abstract repository interface for EmbeddingVector entities."""

    @abstractmethod
    async def get_by_id(self, vector_id: UUID) -> Optional[EmbeddingVector]:
        """Get embedding vector by ID."""
        pass

    @abstractmethod
    async def get_by_dataset_object_id(
        self, dataset_object_id: UUID, skip: int = 0, limit: int = 100
    ) -> List[EmbeddingVector]:
        """Get embedding vectors by dataset object ID with pagination."""
        pass

    @abstractmethod
    async def create(self, embedding_vector: EmbeddingVector) -> EmbeddingVector:
        """Create a new embedding vector."""
        pass

    @abstractmethod
    async def bulk_create(
        self, embedding_vectors: List[EmbeddingVector]
    ) -> List[EmbeddingVector]:
        """Create multiple embedding vectors."""
        pass

    @abstractmethod
    async def update(self, embedding_vector: EmbeddingVector) -> EmbeddingVector:
        """Update an existing embedding vector."""
        pass

    @abstractmethod
    async def delete(self, vector_id: UUID) -> bool:
        """Delete an embedding vector by ID."""
        pass

    @abstractmethod
    async def delete_by_dataset_object_id(self, dataset_object_id: UUID) -> int:
        """Delete all embedding vectors for a dataset object."""
        pass

    @abstractmethod
    async def similarity_search(
        self,
        query_embedding: List[float],
        dataset_id: UUID,
        limit: int = 10,
        similarity_threshold: float = 0.7,
    ) -> List[Tuple[EmbeddingVector, float]]:
        """Perform similarity search for embeddings within a dataset."""
        pass

    @abstractmethod
    async def get_count_by_dataset_object_id(self, dataset_object_id: UUID) -> int:
        """Get count of embedding vectors for a dataset object."""
        pass
