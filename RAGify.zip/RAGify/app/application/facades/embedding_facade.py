"""
Embedding Facade - Provides a clean interface for embedding operations
"""
import asyncio
import logging
from typing import List, Optional, Dict, Any

from openai import AsyncOpenAI
from openai.types import CreateEmbeddingResponse

logger = logging.getLogger(__name__)


class EmbeddingFacade:
    """Facade for embedding operations, abstracting OpenAI and other providers"""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self._client = None
        
    def _get_client(self) -> AsyncOpenAI:
        """Get or create OpenAI async client"""
        if self._client is None:
            self._client = AsyncOpenAI(api_key=self.api_key)
        return self._client
    
    async def generate_embeddings(
        self,
        texts: List[str],
        model: str = "text-embedding-ada-002",
        batch_size: int = 100
    ) -> List[List[float]]:
        """
        Generate embeddings for a list of texts
        
        Args:
            texts: List of text strings to embed
            model: Embedding model to use
            batch_size: Number of texts to process per batch
            
        Returns:
            List of embedding vectors
        """
        if not texts:
            return []
        
        try:
            client = self._get_client()
            all_embeddings = []
            
            # Process in batches to avoid API limits
            for i in range(0, len(texts), batch_size):
                batch = texts[i:i + batch_size]
                
                logger.info(f"Generating embeddings for batch {i//batch_size + 1} "
                           f"({len(batch)} texts)")
                
                response: CreateEmbeddingResponse = await client.embeddings.create(
                    input=batch,
                    model=model,
                    encoding_format="float"
                )
                
                # Extract embeddings from response
                batch_embeddings = [item.embedding for item in response.data]
                all_embeddings.extend(batch_embeddings)
                
                logger.info(f"Generated {len(batch_embeddings)} embeddings")
            
            logger.info(f"Total embeddings generated: {len(all_embeddings)}")
            return all_embeddings
            
        except Exception as e:
            error_msg = f"Failed to generate embeddings: {str(e)}"
            logger.error(error_msg)
            raise Exception(error_msg)
    
    async def generate_single_embedding(
        self,
        text: str,
        model: str = "text-embedding-ada-002"
    ) -> List[float]:
        """
        Generate embedding for a single text
        
        Args:
            text: Text string to embed
            model: Embedding model to use
            
        Returns:
            Embedding vector
        """
        try:
            embeddings = await self.generate_embeddings([text], model)
            return embeddings[0] if embeddings else []
            
        except Exception as e:
            error_msg = f"Failed to generate single embedding: {str(e)}"
            logger.error(error_msg)
            raise Exception(error_msg)
    
    async def validate_model(self, model: str) -> Dict[str, Any]:
        """
        Validate if the embedding model is available
        
        Args:
            model: Model name to validate
            
        Returns:
            Dictionary with validation status
        """
        try:
            # Test with a simple text
            test_text = "This is a test."
            embedding = await self.generate_single_embedding(test_text, model)
            
            if embedding:
                return {
                    "status": "success",
                    "message": f"Model {model} is available",
                    "dimensions": len(embedding)
                }
            else:
                return {
                    "status": "failure",
                    "message": f"Model {model} returned empty embedding"
                }
                
        except Exception as e:
            return {
                "status": "failure",
                "message": f"Model {model} validation failed: {str(e)}"
            }
    
    async def get_embedding_dimensions(self, model: str) -> int:
        """
        Get the dimension count for a specific model
        
        Args:
            model: Model name
            
        Returns:
            Number of dimensions in the embedding vector
        """
        try:
            # Use a small test text to get dimensions
            test_embedding = await self.generate_single_embedding("test", model)
            return len(test_embedding)
            
        except Exception as e:
            logger.error(f"Failed to get dimensions for model {model}: {str(e)}")
            # Return default dimensions for known models
            model_dimensions = {
                "text-embedding-ada-002": 1536,
                "text-embedding-3-small": 1536,
                "text-embedding-3-large": 3072
            }
            return model_dimensions.get(model, 1536)
    
    def get_supported_models(self) -> List[str]:
        """
        Get list of supported embedding models
        
        Returns:
            List of model names
        """
        return [
            "text-embedding-ada-002",
            "text-embedding-3-small", 
            "text-embedding-3-large"
        ]
    
    async def calculate_similarity(
        self,
        embedding1: List[float],
        embedding2: List[float]
    ) -> float:
        """
        Calculate cosine similarity between two embeddings
        
        Args:
            embedding1: First embedding vector
            embedding2: Second embedding vector
            
        Returns:
            Cosine similarity score (0-1)
        """
        try:
            import numpy as np
            
            # Convert to numpy arrays
            vec1 = np.array(embedding1)
            vec2 = np.array(embedding2)
            
            # Calculate cosine similarity
            dot_product = np.dot(vec1, vec2)
            norm1 = np.linalg.norm(vec1)
            norm2 = np.linalg.norm(vec2)
            
            if norm1 == 0 or norm2 == 0:
                return 0.0
            
            similarity = dot_product / (norm1 * norm2)
            return float(similarity)
            
        except Exception as e:
            logger.error(f"Failed to calculate similarity: {str(e)}")
            return 0.0
    
    async def batch_similarity_search(
        self,
        query_embedding: List[float],
        candidate_embeddings: List[List[float]],
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Find most similar embeddings to a query embedding
        
        Args:
            query_embedding: Query embedding vector
            candidate_embeddings: List of candidate embedding vectors
            top_k: Number of top results to return
            
        Returns:
            List of similarity results with indices and scores
        """
        try:
            similarities = []
            
            for idx, candidate in enumerate(candidate_embeddings):
                similarity = await self.calculate_similarity(query_embedding, candidate)
                similarities.append({
                    "index": idx,
                    "similarity": similarity
                })
            
            # Sort by similarity (descending) and return top_k
            similarities.sort(key=lambda x: x["similarity"], reverse=True)
            return similarities[:top_k]
            
        except Exception as e:
            logger.error(f"Failed to perform similarity search: {str(e)}")
            return []
