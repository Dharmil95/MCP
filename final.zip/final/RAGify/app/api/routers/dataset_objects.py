import logging
from typing import List
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import (
    get_async_session,
    get_current_user,
    get_dataset_service,
)
from app.application.services.dataset_service import DatasetService
from app.domain.models import User
from app.domain.schemas import DatasetObjectRead

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/dataset_objects", tags=["dataset_objects"])


@router.get("/{dataset_id}", response_model=List[DatasetObjectRead])
async def get_dataset_objects(
    dataset_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session),
    dataset_service: DatasetService = Depends(get_dataset_service),
):
    """
    Get all files (objects) within a specific dataset
    """
    try:
        objects = await dataset_service.get_dataset_objects(
            db=db, dataset_id=dataset_id, owner_id=current_user.id
        )

        if not objects:
            # Check if dataset exists
            dataset = await dataset_service.get_dataset_by_id(
                db=db, dataset_id=dataset_id, owner_id=current_user.id
            )
            if not dataset:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND, detail="Dataset not found"
                )

        return [DatasetObjectRead.from_orm(obj) for obj in objects]

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting dataset objects: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get dataset objects",
        )


@router.get("/object/{dataset_object_id}", response_model=DatasetObjectRead)
async def get_dataset_object(
    dataset_object_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session),
    dataset_service: DatasetService = Depends(get_dataset_service),
):
    """
    Get details for a specific dataset object
    """
    try:
        # This would require a service method to get object by ID with ownership check
        # For now, we'll implement a basic version

        # TODO: Implement DatasetService.get_dataset_object_by_id
        # This should verify that the object belongs to a dataset owned by the current user

        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="This endpoint is not yet implemented",
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting dataset object: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get dataset object",
        )


@router.delete("/object/{dataset_object_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_dataset_object(
    dataset_object_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session),
    dataset_service: DatasetService = Depends(get_dataset_service),
):
    """
    Delete a specific dataset object (file) by its ID
    """
    try:
        # Implement DatasetService.delete_dataset_object_by_id
        result = await dataset_service.delete_dataset_object_by_id(
            db=db, dataset_object_id=dataset_object_id, owner_id=current_user.id
        )
        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Dataset object not found or not owned by user",
            )
        return
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting dataset object: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete dataset object",
        )


@router.get("/pending/{dataset_id}")
async def get_pending_dataset_objects(
    dataset_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session),
    dataset_service: DatasetService = Depends(get_dataset_service),
):
    """
    Get S3 files for a dataset that are not yet processed (no DatasetObject record)
    """
    # Get AWS credentials for the dataset
    creds = await dataset_service.get_aws_credentials(db, dataset_id, current_user.id)
    if not creds:
        raise HTTPException(
            status_code=404, detail="Dataset not found or not owned by user"
        )
    # Get unprocessed files
    unprocessed_files = await dataset_service.get_unprocessed_s3_files(
        db=db, dataset_id=dataset_id, owner_id=current_user.id, aws_credentials=creds
    )
    return unprocessed_files


@router.get("/objects_with_status/{dataset_id}")
async def get_dataset_objects_with_status(
    dataset_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session),
    dataset_service: DatasetService = Depends(get_dataset_service),
):
    """
    Get all files for a dataset with their status: processed, failed, or pending
    """
    # Get AWS credentials for the dataset
    creds = await dataset_service.get_aws_credentials(db, dataset_id, current_user.id)
    if not creds:
        raise HTTPException(
            status_code=404, detail="Dataset not found or not owned by user"
        )
    # Get all processed objects
    objects = await dataset_service.get_dataset_objects(db, dataset_id, current_user.id)
    objects_by_key = {obj.original_s3_path: obj for obj in objects}
    # Get all files in S3
    from app.application.services.document_processor import DocumentProcessor

    processor = DocumentProcessor(dataset_id, creds)
    dataset = await dataset_service.get_dataset_by_id(db, dataset_id, current_user.id)
    s3_files = await processor.list_s3_files(
        dataset.aws_s3_folder_path, dataset.allowed_file_types
    )
    # Build result list
    result = []
    s3_keys = set()
    for file_info in s3_files:
        s3_keys.add(file_info["key"])
        obj = objects_by_key.get(file_info["key"])
        if obj:
            status = obj.status if hasattr(obj, "status") else "processed"
            created_at = (
                obj.created_at.isoformat()
                if hasattr(obj, "created_at") and obj.created_at
                else None
            )
            dataset_object_id = str(obj.id) if hasattr(obj, "id") and obj.id else None
            dataset_id_val = (
                str(obj.dataset_id)
                if hasattr(obj, "dataset_id") and obj.dataset_id
                else str(dataset_id)
            )
        else:
            status = "pending"
            created_at = None
            dataset_object_id = None
            dataset_id_val = str(dataset_id)
        result.append(
            {
                "key": file_info["key"],
                "file_name": file_info.get(
                    "file_name", file_info["key"].split("/")[-1]
                ),
                "status": status,
                "created_at": created_at,
                "dataset_object_id": dataset_object_id,
                "dataset_id": dataset_id_val,
            }
        )
    # Add failed/processed objects not present in S3
    for obj in objects:
        if obj.original_s3_path not in s3_keys:
            result.append(
                {
                    "key": obj.original_s3_path,
                    "file_name": obj.original_s3_path.split("/")[-1],
                    "status": obj.status,
                    "created_at": (
                        obj.created_at.isoformat() if obj.created_at else None
                    ),
                    "dataset_object_id": str(obj.id) if obj.id else None,
                    "dataset_id": (
                        str(obj.dataset_id) if obj.dataset_id else str(dataset_id)
                    ),
                }
            )
    return result
