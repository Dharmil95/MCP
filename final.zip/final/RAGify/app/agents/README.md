# Writing Agents for RAGify

This project treats agents as small, import-safe Python modules placed in `app/agents`.

Agent contract (preferred)

- Expose a `register()` function that returns a metadata dict:
  - `id` (str): unique identifier for the agent
  - `description` (str)
  - `invoke` (callable) OR `graph` (langgraph compiled graph)

Example:

```python
# app/agents/my_agent.py

def invoke(payload: dict) -> dict:
    return {"agent": "my_agent", "result": "ok"}


def register():
    return {"id": "my_agent", "description": "Example agent", "invoke": invoke}
```

Discovery

- The application imports all modules under `app.agents` using `pkgutil`.
- The registry prefers a `register()` callable. If missing, it falls back to module attributes
  (`AGENT_ID`/`agent_id`, `DESCRIPTION`/`description`, and `invoke` or `graph`).

Tips

- Keep heavy imports (LLM clients, SDKs) inside `invoke()` so the module imports cleanly
  when the application starts or when the registry scans the package.
- Use `app.application.services` facades for HTTP/database interactions so agents remain focused
  on orchestration and easier to test.

Troubleshooting

- If your agent doesn't appear in the registry, call the `/api/v1/agents/register` endpoint
  (or restart) and inspect `app.agents.import_errors()` for import-time exceptions.
