"""Data Transfer Objects for the application layer."""

from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional
from uuid import UUID


@dataclass
class CreateDatasetDTO:
    """DTO for creating a dataset."""
    name: str
    description: Optional[str]
    aws_s3_folder_path: str
    aws_access_key_id: str
    aws_secret_access_key: str
    embedding_model: str
    chunking_strategy: str
    allowed_file_types: List[str]
    owner_id: UUID


@dataclass
class UpdateDatasetDTO:
    """DTO for updating a dataset."""
    name: Optional[str] = None
    description: Optional[str] = None
    embedding_model: Optional[str] = None
    chunking_strategy: Optional[str] = None
    allowed_file_types: Optional[List[str]] = None


@dataclass
class DatasetDTO:
    """DTO for dataset representation."""
    id: UUID
    name: str
    description: Optional[str]
    aws_s3_folder_path: str
    embedding_model: str
    chunking_strategy: str
    allowed_file_types: List[str]
    owner_id: UUID
    created_at: datetime
    updated_at: datetime


@dataclass
class ProcessDocumentDTO:
    """DTO for document processing request."""
    dataset_id: UUID
    file_key: str
    bucket_name: str
    owner_id: UUID


@dataclass
class DocumentProcessingResultDTO:
    """DTO for document processing result."""
    dataset_object_id: UUID
    file_key: str
    status: str
    chunk_count: int
    error_message: Optional[str] = None


@dataclass
class SearchQueryDTO:
    """DTO for search query."""
    query: str
    dataset_id: UUID
    top_k: int = 5
    similarity_threshold: float = 0.7


@dataclass
class SearchResultDTO:
    """DTO for search result."""
    chunk_id: UUID
    content: str
    metadata: dict
    similarity_score: float
    dataset_object_id: UUID
