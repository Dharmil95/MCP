# llm_example_invoke.py
from dotenv import load_dotenv
import os
from langchain_openai import ChatOpenAI
from langchain.schema import HumanMessage

# 1️⃣ Load API key
load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    raise RuntimeError("Missing OPENAI_API_KEY in .env")

# 2️⃣ Instantiate ChatOpenAI
chat = ChatOpenAI(
    openai_api_key=api_key,
    model_name="gpt-4o-mini",  # or your preferred model
    temperature=0
)

# 3️⃣ Query using invoke()
response = chat.invoke([HumanMessage(content="What is the capital of USA?")])
print(response.content)
