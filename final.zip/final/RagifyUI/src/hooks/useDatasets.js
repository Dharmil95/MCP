import { useState, useEffect, useCallback } from 'react';
import datasetService from '../services/datasetService';

export default function useDatasets() {
  const [datasets, setDatasets] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showDatasetModal, setShowDatasetModal] = useState(false);
  const [datasetFormData, setDatasetFormData] = useState({
    name: '',
    description: '',
    aws_s3_folder_path: '',
    aws_access_key_id: '',
    aws_secret_access_key: '',
    embedding_model: 'text-embedding-ada-002',
    chunking_strategy: 'recursive_character',
    chunking_parameters: { chunk_size: 512, chunk_overlap: 20 },
    allowed_file_types: ['.pdf']
  });
  const [datasetError, setDatasetError] = useState('');
  const [toast, setToast] = useState({ message: '', type: '' });
  const [confirmDelete, setConfirmDelete] = useState({ open: false, datasetId: null });

  const loadDatasets = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await datasetService.getDatasets();
      setDatasets(response);
    } catch (err) {
      setError(err.message || 'Failed to load datasets');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const openDatasetModal = useCallback(() => {
    setDatasetFormData({
      name: '',
      description: '',
      aws_s3_folder_path: '',
      aws_access_key_id: '',
      aws_secret_access_key: '',
      embedding_model: 'text-embedding-ada-002',
      chunking_strategy: 'recursive_character',
      chunking_parameters: { chunk_size: 512, chunk_overlap: 20 },
      allowed_file_types: ['.pdf']
    });
    setDatasetError('');
    setShowDatasetModal(true);
  }, []);

  const closeDatasetModal = useCallback(() => {
    setShowDatasetModal(false);
  }, []);

  const handleDatasetInputChange = useCallback((e) => {
    const { name, value, type, checked } = e.target;
    if (name === 'chunk_size' || name === 'chunk_overlap') {
      setDatasetFormData(prev => ({
        ...prev,
        chunking_parameters: {
          ...prev.chunking_parameters,
          [name]: Number(value)
        }
      }));
      return;
    }
    if (name === 'allowed_file_types') {
      setDatasetFormData(prev => {
        const arr = prev.allowed_file_types || [];
        if (checked) {
          return { ...prev, allowed_file_types: [...arr, value] };
        } else {
          return { ...prev, allowed_file_types: arr.filter((v) => v !== value) };
        }
      });
      return;
    }
    setDatasetFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? Number(value) : value
    }));
  }, []);

  const handleCreateDataset = useCallback(async (e) => {
    e.preventDefault();
    setDatasetError('');
    setIsLoading(true);
    try {
      await datasetService.createDataset(datasetFormData);
      closeDatasetModal();
      loadDatasets();
      setToast({ message: 'Dataset created successfully.', type: 'success' });
    } catch (error) {
      setDatasetError(error.response?.data?.detail || 'Failed to create dataset. Please try again.');
    } finally {
      setIsLoading(false);
      setTimeout(() => setToast({ message: '', type: '' }), 3000);
    }
  }, [datasetFormData, closeDatasetModal, loadDatasets]);

  const requestDeleteDataset = useCallback((datasetId) => {
    setConfirmDelete({ open: true, datasetId });
  }, []);

  const handleConfirmDelete = useCallback(async () => {
    setConfirmDelete({ open: false, datasetId: null });
    setIsLoading(true);
    try {
      await datasetService.deleteDataset(confirmDelete.datasetId);
      setToast({ message: 'Dataset deleted successfully.', type: 'success' });
      loadDatasets();
    } catch (error) {
      setToast({ message: 'Failed to delete dataset. Please try again.', type: 'error' });
    } finally {
      setIsLoading(false);
      setTimeout(() => setToast({ message: '', type: '' }), 3000);
    }
  }, [confirmDelete.datasetId, loadDatasets]);

  const handleCancelDelete = useCallback(() => {
    setConfirmDelete({ open: false, datasetId: null });
  }, []);

  const createDataset = useCallback(async (datasetData) => {
    try {
      const newDataset = await datasetService.createDataset(datasetData);
      setDatasets(prev => [...prev, newDataset]);
      return newDataset;
    } catch (err) {
      throw err;
    }
  }, []);

  const deleteDataset = useCallback(async (datasetId) => {
    try {
      await datasetService.deleteDataset(datasetId);
      setDatasets(prev => prev.filter(dataset => dataset.id !== datasetId));
    } catch (err) {
      throw err;
    }
  }, []);

  useEffect(() => {
    loadDatasets();
  }, [loadDatasets]);

  return {
    datasets,
    isLoading,
    error,
    showDatasetModal,
    openDatasetModal,
    closeDatasetModal,
    datasetFormData,
    handleDatasetInputChange,
    handleCreateDataset,
    requestDeleteDataset,
    handleConfirmDelete,
    handleCancelDelete,
    confirmDelete,
    datasetError,
    toast,
    loadDatasets,
    createDataset,
    deleteDataset
  };
}
