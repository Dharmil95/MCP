# RAG-as-a-Service (AgenticRAG)

A comprehensive Retrieval-Augmented Generation (RAG) platform that enables users to create datasets from AWS S3 documents, process them into searchable embeddings, and interact with them through an intelligent chat interface.

## 🚀 Features

### Core Functionality
- **Document Processing**: Automatic processing of PDF, DOCX, TXT, and Markdown files from AWS S3
- **Intelligent Chunking**: Multiple text chunking strategies with configurable parameters
- **Vector Embeddings**: Generate and store embeddings using OpenAI's text-embedding-ada-002 model
- **Semantic Search**: Fast similarity search across processed documents using pgvector
- **Chat Interface**: AI-powered conversations with your documents using OpenAI GPT models
- **Multi-Dataset Support**: Create and manage multiple document collections

### Backend Features
- **FastAPI REST API**: High-performance async API with automatic documentation
- **PostgreSQL + pgvector**: Scalable vector database for embeddings storage
- **Celery + Redis**: Distributed task processing for document processing pipelines
- **JWT Authentication**: Secure user authentication and authorization
- **AWS S3 Integration**: Direct integration with S3 buckets for document storage
- **Database Migrations**: Alembic-powered schema versioning
- **Docker Support**: Containerized deployment with Docker Compose

### Frontend Features
- **React Dashboard**: Modern, responsive web interface
- **Dataset Management**: Create, view, update, and delete document datasets
- **Real-time Chat**: Interactive chat interface with source citations
- **File Upload**: Direct file upload to S3 through the web interface
- **Processing Status**: Real-time status tracking for document processing
- **User Authentication**: Secure login and registration system

## 🏗️ Architecture

### Backend Structure
```
app/
├── api/                    # FastAPI routes and endpoints
│   └── routers/           # API route handlers
│       ├── auth.py        # Authentication endpoints
│       ├── datasets.py    # Dataset management
│       ├── chat.py        # Chat/RAG endpoints
│       ├── aws.py         # S3 operations
│       └── users.py       # User management
├── application/           # Business logic layer
│   └── services/         # Application services
│       ├── dataset_service.py      # Dataset operations
│       └── document_processor.py   # Document processing
├── core/                  # Core configuration
│   ├── config.py         # Application settings
│   └── celery_app.py     # Celery configuration
├── db/                   # Database configuration
├── domain/               # Domain entities and repositories
├── infrastructure/       # External services and database
├── schemas/              # Pydantic models for API
└── utils/                # Utilities (auth, crypto)
```

### Frontend Structure
```
RagifyUI/
├── src/
│   ├── components/       # React components
│   ├── pages/           # Page components
│   ├── hooks/           # Custom React hooks
│   ├── services/        # API service layer
│   └── styles/          # CSS stylesheets
```

## 🚦 Getting Started

### Prerequisites
- Docker and Docker Compose
- AWS S3 bucket and credentials
- OpenAI API key

### Environment Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd AgenticRAG
   ```

2. **Configure environment variables**
   Create a `.env` file in the root directory:
   ```env
   # Database
   DATABASE_URL=postgresql+asyncpg://postgres:password@db:5432/ragas
   
   # Security
   SECRET_KEY=your-super-secret-key-here
   REFRESH_TOKEN_SECRET_KEY=your-refresh-secret-key-here
   FERNET_KEY=your-fernet-encryption-key
   
   # OpenAI
   OPENAI_API_KEY=your-openai-api-key
   
   # Redis/Celery
   REDIS_URL=redis://redis:6379/0
   CELERY_BROKER_URL=redis://redis:6379/0
   CELERY_RESULT_BACKEND=redis://redis:6379/0
   
   # Application
   DEBUG=true
   BACKEND_PORT=8000
   ```

3. **Start the application**
   ```bash
   docker-compose up -d
   ```

4. **Access the application**
   - API Documentation: http://localhost:8000/docs
   - Frontend Dashboard: http://localhost:5173
   - Celery Flower (monitoring): http://localhost:5555

## 📖 Usage Guide

### 1. User Registration and Authentication
- Register a new account or login to access the dashboard
- JWT tokens are used for secure API authentication

### 2. Dataset Creation
- Create a new dataset by providing:
  - Dataset name and description
  - AWS S3 folder path
  - AWS credentials (Access Key ID and Secret)
  - Allowed file types (PDF, DOCX, TXT, MD)
  - Chunking strategy and parameters

### 3. Document Processing
- Files are automatically discovered from the specified S3 path
- Documents are processed asynchronously using Celery workers
- Text is extracted, chunked, and converted to embeddings
- Processing status can be monitored in real-time

### 4. Chat and Search
- Use the chat interface to ask questions about your documents
- The system performs semantic search across all processed documents
- Responses include source citations with document references
- Chat with specific datasets or across all your datasets

## 🔧 Configuration

### Chunking Strategies
- **RecursiveCharacterTextSplitter**: Smart text splitting (default)
- **CharacterTextSplitter**: Simple character-based splitting
- **MarkdownHeaderTextSplitter**: Markdown-aware splitting

### Embedding Models
- **text-embedding-ada-002**: OpenAI's embedding model (default)
- Configurable batch sizes for API optimization

### Processing Configuration
```python
# In app/core/config.py
max_concurrent_files: int = 10
chunk_batch_size: int = 100
embedding_batch_size: int = 100
```

## 🔐 Security Features

- **JWT Authentication**: Secure token-based authentication
- **Password Hashing**: bcrypt password hashing
- **Encrypted Storage**: AWS credentials encrypted with Fernet
- **User Isolation**: Users can only access their own datasets
- **CORS Protection**: Configurable CORS settings

## 📊 API Endpoints

### Authentication
- `POST /auth/register` - User registration
- `POST /auth/jwt/login` - User login
- `POST /auth/jwt/refresh` - Token refresh

### Datasets
- `GET /datasets` - List user datasets
- `POST /datasets` - Create new dataset
- `GET /datasets/{id}` - Get dataset details
- `PUT /datasets/{id}` - Update dataset
- `DELETE /datasets/{id}` - Delete dataset
- `GET /datasets/{id}/status` - Get processing status

### Chat
- `POST /chat/all` - Chat across all datasets
- `POST /chat/{dataset_id}` - Chat with specific dataset

### AWS Operations
- `POST /aws/validate-credentials` - Validate S3 credentials
- `POST /aws/upload-file` - Upload file to S3
- `GET /aws/download-file` - Download files from S3

## 🛠️ Development

### Running Locally
1. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Set up PostgreSQL with pgvector extension
3. Run database migrations:
   ```bash
   alembic upgrade head
   ```

4. Start the FastAPI server:
   ```bash
   uvicorn app.main:app --reload
   ```

5. Start Celery worker:
   ```bash
   celery -A app.core.celery_app worker --loglevel=info
   ```

### Frontend Development
```bash
cd RagifyUI
npm install
npm run dev
```

### Database Migrations
```bash
# Create a new migration
alembic revision --autogenerate -m "Description"

# Apply migrations
alembic upgrade head
```

## 🐳 Docker Deployment

The application includes a complete Docker Compose setup with:
- **FastAPI Backend**: Main application server
- **PostgreSQL**: Database with pgvector extension
- **Redis**: Message broker for Celery
- **Celery Worker**: Background task processing
- **Celery Flower**: Task monitoring dashboard
- **React Frontend**: Web interface

### Production Deployment
1. Update environment variables for production
2. Configure proper secret keys and encryption keys
3. Set up SSL/TLS certificates
4. Configure proper CORS settings
5. Set up monitoring and logging

## 🧪 Testing

Run the test suite:
```bash
pytest
```

For async tests:
```bash
pytest -v --asyncio-mode=auto
```

## 📝 Technologies Used

### Backend
- **FastAPI**: Modern Python web framework
- **SQLAlchemy**: SQL toolkit and ORM
- **PostgreSQL**: Primary database
- **pgvector**: Vector similarity search
- **Celery**: Distributed task queue
- **Redis**: In-memory data store
- **Alembic**: Database migration tool
- **Pydantic**: Data validation
- **LangChain**: Document processing framework
- **OpenAI**: Embeddings and LLM API

### Frontend
- **React**: Frontend framework
- **Vite**: Build tool
- **Axios**: HTTP client
- **React Router**: Navigation
- **React Markdown**: Markdown rendering

### DevOps
- **Docker**: Containerization
- **Docker Compose**: Multi-container orchestration

## 📜 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🔮 Future Enhancements

- Support for additional document formats
- Advanced chunking strategies
- Multiple embedding model support
- Enhanced chat features with conversation history
- Advanced search filters and facets
- Multi-tenancy support
- Enhanced monitoring and analytics
