import React from 'react';
import { FaUser } from 'react-icons/fa';
import '../styles/content-header.css';

const Header = ({ username, title = "Welcome to Your Dashboard", rightContent }) => (
  <header className="content-header">
    <h1>{title}</h1>
    <div className="header-right">
      {rightContent && (
        <div className="header-actions">
          {rightContent}
        </div>
      )}
      <div className="user-info">
        <span>{username}</span>
        <div className="avatar"><FaUser /></div>
      </div>
    </div>
  </header>
);

export default Header;
