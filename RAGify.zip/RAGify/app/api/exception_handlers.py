"""Global exception handlers for the API."""

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.domain.exceptions.base import DomainException, EntityNotFoundError
from app.domain.exceptions.dataset import DatasetProcessingError, DatasetValidationError
from app.domain.exceptions.user import InvalidCredentialsError, UserInactiveError


def register_exception_handlers(app: FastAPI) -> None:
    """Register global exception handlers."""
    
    @app.exception_handler(EntityNotFoundError)
    async def entity_not_found_handler(request: Request, exc: EntityNotFoundError):
        return JSONResponse(
            status_code=404,
            content={
                "error": "Not Found",
                "message": exc.message,
                "code": exc.code,
            }
        )
    
    @app.exception_handler(InvalidCredentialsError)
    async def invalid_credentials_handler(request: Request, exc: InvalidCredentialsError):
        return JSONResponse(
            status_code=401,
            content={
                "error": "Unauthorized",
                "message": exc.message,
                "code": exc.code,
            }
        )
    
    @app.exception_handler(UserInactiveError)
    async def user_inactive_handler(request: Request, exc: UserInactiveError):
        return JSONResponse(
            status_code=403,
            content={
                "error": "Forbidden",
                "message": exc.message,
                "code": exc.code,
            }
        )
    
    @app.exception_handler(DatasetProcessingError)
    async def dataset_processing_handler(request: Request, exc: DatasetProcessingError):
        return JSONResponse(
            status_code=422,
            content={
                "error": "Processing Error",
                "message": exc.message,
                "code": exc.code,
            }
        )
    
    @app.exception_handler(DatasetValidationError)
    async def dataset_validation_handler(request: Request, exc: DatasetValidationError):
        return JSONResponse(
            status_code=400,
            content={
                "error": "Validation Error",
                "message": exc.message,
                "code": exc.code,
            }
        )
    
    @app.exception_handler(DomainException)
    async def domain_exception_handler(request: Request, exc: DomainException):
        return JSONResponse(
            status_code=400,
            content={
                "error": "Domain Error",
                "message": exc.message,
                "code": exc.code or "DOMAIN_ERROR",
            }
        )
    
    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        return JSONResponse(
            status_code=422,
            content={
                "error": "Validation Error",
                "message": "Request validation failed",
                "details": exc.errors(),
            }
        )
    
    @app.exception_handler(StarletteHTTPException)
    async def http_exception_handler(request: Request, exc: StarletteHTTPException):
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "error": "HTTP Error",
                "message": exc.detail,
            }
        )
