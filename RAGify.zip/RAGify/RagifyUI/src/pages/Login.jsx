import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FaUser, FaLock } from 'react-icons/fa';
import authService from '../services/authService';
import '../styles/auth.css';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!username || !password) {
      setError('Username and password are required');
      return;
    }

    try {
      setIsLoading(true);
      setError('');
      
      // Add debugging info
      console.log('Attempting login with username:', username);
      
      const response = await authService.login(username, password);
      
      console.log('Login successful, response:', response);
      
      if (!response.access_token) {
        console.error('No access token in response:', response);
        setError('Authentication error: No access token received');
        setIsLoading(false);
        return;
      }
      
      // Store tokens in localStorage
      localStorage.setItem('access_token', response.access_token);
      localStorage.setItem('refresh_token', response.refresh_token || '');
      
      // Add a small delay to ensure tokens are stored
      setTimeout(() => {
        navigate('/dashboard');
      }, 100);
      
    } catch (err) {
      console.error('Login error:', err);
      
      // Handle different error cases
      if (err.response) {
        // The request was made and the server responded with an error status
        console.error('Error status:', err.response.status);
        console.error('Error data:', err.response.data);
        
        if (err.response.status === 401) {
          setError('Invalid username or password. Please try again.');
        } else if (err.response.status === 422) {
          setError('Invalid input format. Please check your credentials.');
        } else {
          setError(err.response.data?.detail || 'Login failed. Please check your credentials.');
        }
      } else if (err.request) {
        // The request was made but no response was received
        console.error('No response received from server');
        setError('Connection error. Please check your internet connection and try again.');
      } else {
        // Something happened in setting up the request
        console.error('Error message:', err.message);
        setError(`Error: ${err.message}`);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-left-panel">
        <div className="branding">
          <h1>RAGify</h1>
          <p>Your gateway to AI-powered RAG services</p>
          <button className="cta">Learn More</button>
        </div>
        {/* Decorative circles */}
        <div className="circle circle-1"></div>
        <div className="circle circle-2"></div>
      </div>

      <div className="auth-right-panel">
        <div className="auth-card">
          <h2>Welcome Back!</h2>
          <p className="subtitle">Log in to your RAGify workspace</p>
          
          <form onSubmit={handleSubmit}>
            <div className="input-group">
              <FaUser className="input-icon" />
              <input
                type="text"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                disabled={isLoading}
              />
            </div>
            
            <div className="input-group">
              <FaLock className="input-icon" />
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={isLoading}
              />
            </div>
            
            {error && <div className="error-message">{error}</div>}
            
            <button 
              type="submit" 
              className="auth-button"
              disabled={isLoading}
            >
              {isLoading ? 'Logging in...' : 'Login'}
            </button>
            
            <div className="auth-links">
              <Link to="/forgot-password" className="forgot-password">
                Forgot password?
              </Link>
              <span>·</span>
              <Link to="/signup" className="signup-link">
                Sign Up
              </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
