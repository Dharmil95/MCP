"""Dataset object repository interface."""

from abc import ABC, abstractmethod
from typing import List, Optional
from uuid import UUID

from ..entities.dataset_object import DatasetObject


class DatasetObjectRepository(ABC):
    """Abstract repository interface for DatasetObject entities."""

    @abstractmethod
    async def get_by_id(self, dataset_object_id: UUID) -> Optional[DatasetObject]:
        """Get dataset object by ID."""
        pass

    @abstractmethod
    async def get_by_dataset_id(
        self, dataset_id: UUID, skip: int = 0, limit: int = 100
    ) -> List[DatasetObject]:
        """Get dataset objects by dataset ID with pagination."""
        pass

    @abstractmethod
    async def create(self, dataset_object: DatasetObject) -> DatasetObject:
        """Create a new dataset object."""
        pass

    @abstractmethod
    async def update(self, dataset_object: DatasetObject) -> DatasetObject:
        """Update an existing dataset object."""
        pass

    @abstractmethod
    async def delete(self, dataset_object_id: UUID) -> bool:
        """Delete a dataset object by ID."""
        pass

    @abstractmethod
    async def get_by_status(
        self, status: str, skip: int = 0, limit: int = 100
    ) -> List[DatasetObject]:
        """Get dataset objects by status with pagination."""
        pass

    @abstractmethod
    async def get_pending_for_processing(self, limit: int = 10) -> List[DatasetObject]:
        """Get dataset objects pending for processing."""
        pass

    @abstractmethod
    async def get_by_file_name_and_dataset(
        self, file_name: str, dataset_id: UUID
    ) -> Optional[DatasetObject]:
        """Get dataset object by file name and dataset ID."""
        pass

    @abstractmethod
    async def bulk_update_status(
        self, dataset_object_ids: List[UUID], status: str
    ) -> int:
        """Bulk update status for multiple dataset objects."""
        pass
