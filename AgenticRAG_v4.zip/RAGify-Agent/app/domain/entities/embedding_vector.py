"""Embedding vector domain entity."""

from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional
from uuid import UUID


@dataclass
class EmbeddingVector:
    """Embedding vector domain entity for storing vector embeddings."""

    id: UUID
    dataset_object_id: UUID
    chunk_text: str
    chunk_index: int
    embedding: List[float]
    file_metadata: Optional[Dict]
    created_at: datetime

    def __post_init__(self):
        """Validate embedding vector data after initialization."""
        if not self.chunk_text.strip():
            raise ValueError("Chunk text cannot be empty")

        if self.chunk_index < 0:
            raise ValueError("Chunk index must be non-negative")

        if not self.embedding:
            raise ValueError("Embedding vector cannot be empty")

        if len(self.embedding) != 1536:  # OpenAI embedding dimension
            raise ValueError("Embedding vector must have 1536 dimensions")

    def get_similarity_score(self, other_embedding: List[float]) -> float:
        """Calculate cosine similarity with another embedding vector."""
        if len(other_embedding) != len(self.embedding):
            raise ValueError("Embedding vectors must have the same dimensions")

        # Calculate dot product
        dot_product = sum(a * b for a, b in zip(self.embedding, other_embedding))

        # Calculate magnitudes
        magnitude_a = sum(a * a for a in self.embedding) ** 0.5
        magnitude_b = sum(b * b for b in other_embedding) ** 0.5

        # Calculate cosine similarity
        if magnitude_a == 0 or magnitude_b == 0:
            return 0.0

        return dot_product / (magnitude_a * magnitude_b)

    def is_similar_to(
        self, other_embedding: List[float], threshold: float = 0.8
    ) -> bool:
        """Check if this embedding is similar to another embedding."""
        similarity = self.get_similarity_score(other_embedding)
        return similarity >= threshold
