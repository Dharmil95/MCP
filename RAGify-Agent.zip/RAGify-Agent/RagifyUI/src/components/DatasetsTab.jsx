import React from 'react';
import { useNavigate } from 'react-router-dom';
import DatasetModal from './DatasetModal';
import ConfirmModal from './ConfirmModal';
import LoadingSpinner from './LoadingSpinner';
import { FaPlus, FaTrash, FaDatabase, FaFolderOpen } from 'react-icons/fa';

const DatasetsTab = ({
  datasets,
  isLoading,
  showDatasetModal,
  openDatasetModal,
  closeDatasetModal,
  datasetFormData,
  handleDatasetInputChange,
  handleCreateDataset,
  requestDeleteDataset,
  handleConfirmDelete,
  handleCancelDelete,
  confirmDelete,
  datasetError,
  toast
}) => {
  const navigate = useNavigate();

  const handleViewFiles = (dataset) => {
    navigate(`/datasets/${dataset.id}/files`);
  };

  return (
    <div className="datasets-content">
      {toast && toast.message && (
        <div className={`toast toast-${toast.type}`}>{toast.message}</div>
      )}
      <ConfirmModal
        isOpen={confirmDelete.open}
        title="Delete Dataset"
        message="Are you sure you want to delete this dataset? This action cannot be undone."
        onConfirm={handleConfirmDelete}
        onCancel={handleCancelDelete}
      />
      <div className="datasets-header">
        <h2>Your Datasets</h2>
        {!isLoading && (
          <button className="primary-btn" onClick={openDatasetModal}>
            <FaPlus /> Create Dataset
          </button>
        )}
      </div>
      {isLoading ? (
        <div className="datasets-loading-spinner">
          <LoadingSpinner size="large" variant="light" />
          <p>Loading datasets...</p>
        </div>
      ) : datasets.length === 0 ? (
        <div className="empty-state">
          <FaDatabase size={48} color="#a0aec0" />
          <h3>No datasets found</h3>
          <p>Create your first dataset to get started with RAGify.</p>
        </div>
      ) : (
        <div className="datasets-list">
          {datasets.map(dataset => (
            <div className="dataset-card" key={dataset.id}>
              <div className="dataset-header">
                <h3>{dataset.name}</h3>
                <div className="dataset-actions">
                  <button className="icon-btn" title="View Files" onClick={() => handleViewFiles(dataset)}>
                    <FaFolderOpen />
                  </button>
                  <button className="icon-btn" title="Delete Dataset" onClick={() => requestDeleteDataset(dataset.id)}>
                    <FaTrash />
                  </button>
                </div>
              </div>
              <p className="dataset-description">{dataset.description || 'No description provided.'}</p>
              <div className="dataset-meta">
                <span className="dataset-badge">{dataset.data_classification}</span>
                <span>Created: {new Date(dataset.created_at).toLocaleDateString()}</span>
              </div>
            </div>
          ))}
        </div>
      )}
      <DatasetModal
        isOpen={showDatasetModal}
        onClose={closeDatasetModal}
        formData={datasetFormData}
        onChange={handleDatasetInputChange}
        onSubmit={handleCreateDataset}
        isLoading={isLoading}
        error={datasetError}
      />
    </div>
  );
};

export default DatasetsTab;
