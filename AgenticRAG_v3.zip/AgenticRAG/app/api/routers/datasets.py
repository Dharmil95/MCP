from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
from uuid import UUID
from app.db.database import get_async_session
from app.schemas import (
    DatasetCreate, 
    DatasetRead, 
    DatasetUpdate, 
    DatasetObjectRead,
    DatasetStatus,
    SuccessResponse
)
from app.services import DatasetService
from app.utils.auth import get_current_user
from app.models import User
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/datasets", tags=["datasets"])


@router.post("", response_model=DatasetRead, status_code=status.HTTP_201_CREATED)
async def create_dataset(
    dataset_data: DatasetCreate,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session)
):
    """
    Create a new dataset
    """
    try:
        # Extract AWS credentials (ephemeral use)
        aws_credentials = {
            "aws_access_key_id": dataset_data.aws_access_key_id,
            "aws_secret_access_key": dataset_data.aws_secret_access_key
        }
        
        # Create dataset in database
        dataset = await DatasetService.create_dataset(
            db=db,
            dataset_data=dataset_data,
            owner_id=current_user.id
        )
        
        # Prepare dataset configuration for Airflow
        dataset_config = {
            "dataset_id": str(dataset.id),
            "aws_s3_folder_path": dataset.aws_s3_folder_path,
            "embedding_model": dataset.embedding_model,
            "chunking_strategy": dataset.chunking_strategy,
            "chunking_parameters": dataset.chunking_parameters,
            "allowed_file_types": dataset.allowed_file_types
        }
        
        # Trigger Celery task for processing
        from app.tasks import process_dataset
        
        task = process_dataset.delay(
            dataset_id=str(dataset.id),
            aws_credentials=aws_credentials
        )
        
        # Store task ID for tracking (if task_id column exists)
        # dataset.task_id = task.id
        # await db.commit()
        
        logger.info(f"Dataset {dataset.id} created and processing started (task: {task.id})")
        return DatasetRead.from_orm(dataset)
        
    except Exception as e:
        logger.error(f"Dataset creation error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Dataset creation failed"
        )


@router.get("", response_model=List[DatasetRead])
async def get_datasets(
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session)
):
    """
    Get all datasets owned by the current user
    """
    try:
        datasets = await DatasetService.get_datasets_by_owner(
            db=db,
            owner_id=current_user.id,
            skip=skip,
            limit=limit
        )
        return [DatasetRead.from_orm(dataset) for dataset in datasets]
        
    except Exception as e:
        logger.error(f"Error getting datasets: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get datasets"
        )


@router.get("/{dataset_id}", response_model=DatasetRead)
async def get_dataset(
    dataset_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session)
):
    """
    Get a specific dataset by ID
    """
    try:
        dataset = await DatasetService.get_dataset_by_id(
            db=db,
            dataset_id=dataset_id,
            owner_id=current_user.id
        )
        
        if not dataset:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Dataset not found"
            )
        
        return DatasetRead.from_orm(dataset)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting dataset: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get dataset"
        )


@router.put("/{dataset_id}", response_model=DatasetRead)
async def update_dataset(
    dataset_id: UUID,
    dataset_data: DatasetUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session)
):
    """
    Update an existing dataset
    """
    try:
        dataset = await DatasetService.update_dataset(
            db=db,
            dataset_id=dataset_id,
            dataset_data=dataset_data,
            owner_id=current_user.id
        )
        
        if not dataset:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Dataset not found"
            )
        
        return DatasetRead.from_orm(dataset)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating dataset: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update dataset"
        )


@router.delete("/{dataset_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_dataset(
    dataset_id: UUID,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session)
):
    """
    Delete a dataset and trigger cleanup
    """
    try:
        success = await DatasetService.delete_dataset(
            db=db,
            dataset_id=dataset_id,
            owner_id=current_user.id
        )
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Dataset not found"
            )
        
        logger.info(f"Dataset {dataset_id} deleted")
        return None
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting dataset: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete dataset"
        )


@router.get("/{dataset_id}/status", response_model=DatasetStatus)
async def get_dataset_status(
    dataset_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session)
):
    """
    Get dataset processing status
    """
    try:
        status_info = await DatasetService.get_dataset_status(
            db=db,
            dataset_id=dataset_id,
            owner_id=current_user.id
        )
        
        if not status_info:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Dataset not found"
            )
        
        return status_info
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting dataset status: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get dataset status"
        )


@router.post("/{dataset_id}/process", status_code=202)
async def process_dataset_endpoint(
    dataset_id: UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session)
):
    """Trigger processing (or reprocessing) for a dataset."""
    # Get AWS credentials for the dataset
    creds = await DatasetService.get_aws_credentials(db, dataset_id, current_user.id)
    if not creds:
        raise HTTPException(status_code=404, detail="Dataset not found or not owned by user")
    # Trigger Celery task
    from app.tasks import process_dataset
    task = process_dataset.delay(dataset_id=str(dataset_id), aws_credentials=creds)
    return {"message": "Processing started", "task_id": task.id}
