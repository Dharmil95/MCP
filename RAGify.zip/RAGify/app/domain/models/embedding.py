"""Embedding vector model for storing embeddings with PGVector."""

import uuid
from typing import TYPE_CHECKING

from fastapi_permissions import Allow
from pgvector.sqlalchemy import Vector
from sqlalchemy import (
    JSON,
    UUID,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    Text,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.domain.database import Base

if TYPE_CHECKING:
    from app.domain.models.dataset import DatasetObject


class EmbeddingVector(Base):
    """Model for storing vector embeddings with PGVector"""

    __tablename__ = "embedding_vectors"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    dataset_object_id = Column(
        UUID(as_uuid=True), ForeignKey("dataset_objects.id"), nullable=False
    )
    chunk_text = Column(Text, nullable=False)
    chunk_index = Column(Integer, nullable=False)  # Position within the document
    embedding = Column(Vector(1536), nullable=False)  # Updated to PGVector type
    file_metadata = Column(
        JSON, nullable=True
    )  # Additional metadata for the chunk (renamed from 'metadata')
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    dataset_object = relationship("DatasetObject")

    def __acl__(self):
        """Access Control List for embedding vector permissions"""
        return [
            (Allow, f"user:{self.dataset_object.dataset.owner_id}", "view"),
        ]
