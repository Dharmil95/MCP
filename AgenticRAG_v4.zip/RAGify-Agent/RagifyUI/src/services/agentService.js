import api from './api';

class AgentService {
  // Get all available agents
  async getAgents() {
    try {
      const response = await api.get('/agents');
      return response.data;
    } catch (error) {
      console.error('Error fetching agents:', error);
      throw error;
    }
  }

  // Register/refresh agent registry
  async registerAgents() {
    try {
      const response = await api.post('/agents/register');
      return response.data;
    } catch (error) {
      console.error('Error registering agents:', error);
      throw error;
    }
  }

  // Start agent interaction (background task)
  async interactWithAgent(agentId, message, sessionId = null) {
    try {
      const payload = {
        session_id: sessionId,
        input: message
      };
      
      const response = await api.post(`/agents/${agentId}/interact`, payload);
      return response.data;
    } catch (error) {
      console.error('Error starting agent interaction:', error);
      throw error;
    }
  }

  // Check task status and get results
  async getTaskStatus(taskId) {
    try {
      const response = await api.get(`/agents/tasks/${taskId}`);
      return response.data;
    } catch (error) {
      console.error('Error checking task status:', error);
      throw error;
    }
  }

  // Cancel running task
  async cancelTask(taskId) {
    try {
      const response = await api.delete(`/agents/tasks/${taskId}`);
      return response.data;
    } catch (error) {
      console.error('Error canceling task:', error);
      throw error;
    }
  }

  // Session management
  async startSession(agentId, initialMessage = null) {
    try {
      // API expects empty body for session start
      const response = await api.post('/sessions/start', {});
      return response.data;
    } catch (error) {
      console.error('Error starting session:', error);
      throw error;
    }
  }

  async getSession(sessionId) {
    try {
      const response = await api.get(`/sessions/${sessionId}`);
      return response.data;
    } catch (error) {
      console.error('Error getting session:', error);
      throw error;
    }
  }

  async updateSession(sessionId, state) {
    try {
      const response = await api.post(`/sessions/${sessionId}`, state);
      return response.data;
    } catch (error) {
      console.error('Error updating session:', error);
      throw error;
    }
  }

  // Poll task status with timeout
  async pollTaskStatus(taskId, maxAttempts = 60, interval = 1000) {
    let attempts = 0;
    
    return new Promise((resolve, reject) => {
      const poll = async () => {
        try {
          attempts++;
          const status = await this.getTaskStatus(taskId);
          
          if (status.status === 'completed') {
            resolve(status);
          } else if (status.status === 'failed') {
            reject(new Error(status.error || 'Task failed'));
          } else if (attempts >= maxAttempts) {
            reject(new Error('Task timeout'));
          } else {
            setTimeout(poll, interval);
          }
        } catch (error) {
          reject(error);
        }
      };
      
      poll();
    });
  }
}

export default new AgentService();
