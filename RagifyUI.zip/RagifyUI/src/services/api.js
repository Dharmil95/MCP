import axios from 'axios';

// Create axios instance with base URL
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api/v1',
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  },
  timeout: 10000, // 10 seconds timeout
  withCredentials: false // Disable sending cookies with requests
});

// Add request interceptor to inject Authorization header
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor to handle token refresh
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    
    // If error is 401 Unauthorized and we haven't tried refreshing yet
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      try {
        // Try to refresh the token
        const refreshToken = localStorage.getItem('refresh_token');
        
        if (!refreshToken) {
          // No refresh token available → clear and force logout redirect
          try {
            localStorage.removeItem('access_token');
            localStorage.removeItem('refresh_token');
          } catch {}
          // Emit a logout event for any listeners
          try { window.dispatchEvent(new CustomEvent('auth:logout')); } catch {}
          // Hard redirect to login to guarantee user is logged out
          if (typeof window !== 'undefined' && window.location) {
            window.location.replace('/login');
          }
          return Promise.reject(error);
        }
        
        console.log('Attempting to refresh token in interceptor');
        // Call refresh token endpoint with direct configuration
        const response = await axios({
          method: 'post',
          url: `${api.defaults.baseURL}/auth/jwt/refresh`,
          data: { refresh_token: refreshToken },
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          timeout: 10000
        });
        
        // Store new tokens
        const { access_token, refresh_token } = response.data;
        localStorage.setItem('access_token', access_token);
        localStorage.setItem('refresh_token', refresh_token);
        
        // Update the original request with new token
        originalRequest.headers['Authorization'] = `Bearer ${access_token}`;
        
        // Retry the original request
        return api(originalRequest);
      } catch (refreshError) {
        // If refresh fails, clear tokens and redirect to login
        try {
          localStorage.removeItem('access_token');
          localStorage.removeItem('refresh_token');
        } catch {}
        try { window.dispatchEvent(new CustomEvent('auth:logout')); } catch {}
        if (typeof window !== 'undefined' && window.location) {
          window.location.replace('/login');
        }
        // Return the original error
        return Promise.reject(error);
      }
    }
    
    return Promise.reject(error);
  }
);

export default api;
