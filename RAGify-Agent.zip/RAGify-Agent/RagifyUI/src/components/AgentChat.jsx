import React, { useState, useRef, useEffect, useMemo } from 'react';
import { FaRobot } from 'react-icons/fa';
import MarkdownReply from './MarkdownReply';
import AgentSelection from './AgentSelection';
import ChatHeader from './chat/ChatHeader';
import ChatInput from './chat/ChatInput';
import ThinkingIndicator from './chat/ThinkingIndicator';
import EmptyState from './chat/EmptyState';
import ErrorButton from './common/ErrorButton';
import LoadingSpinner from './LoadingSpinner';
import { useFullscreen } from '../hooks/useFullscreen';
import { formatTimestamp, createUserMessage, addMessageToSession, hasMessages } from '../utils/chatUtils';
import '../styles/search.css';
import '../styles/agent-selection.css';

const AgentChat = ({
  agents,
  selectedAgent,
  currentSession,
  isLoading,
  error,
  isThinking,
  startSession,
  sendMessage,
  cancelTask,
  clearSession,
  setSelectedAgent,
  setCurrentSession
}) => {
  const [showAgentSelection, setShowAgentSelection] = useState(!selectedAgent || !currentSession);
  const messagesEndRef = useRef(null);
  
  const { isFullscreen, toggleFullscreen, getFullscreenStyles } = useFullscreen();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [currentSession?.messages]);

  useEffect(() => {
    setShowAgentSelection(!selectedAgent || !currentSession);
  }, [selectedAgent, currentSession]);

  const handleAgentSelect = async (agent) => {
    try {
      setSelectedAgent(agent);
      setShowAgentSelection(false);
      await startSession(agent.id);
    } catch (err) {
      console.error('Error starting session:', err);
    }
  };

  const handleSendMessage = async (message) => {
    if (!message.trim() || isThinking) return;

    // Immediately add user message to the session
    const userMessage = createUserMessage(message);
    setCurrentSession(prev => addMessageToSession(prev, userMessage));

    try {
      await sendMessage(message);
    } catch (err) {
      console.error('Error sending message:', err);
    }
  };

  const handleNewChat = () => {
    clearSession();
    setShowAgentSelection(true);
  };

  const containerStyles = useMemo(() => ({
    height: isFullscreen ? '100vh' : 'calc(100vh - 200px)',
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
    ...getFullscreenStyles()
  }), [isFullscreen, getFullscreenStyles]);

  // Check if error is authentication-related
  const isAuthError = error && (
    error.includes('Not authenticated') || 
    error.includes('401') || 
    error.includes('Unauthorized')
  );

  if (isLoading) {
    return (
      <div className="agent-chat-loading">
        <LoadingSpinner size="large" variant="light" />
        <p>Loading agents...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="agent-chat-error">
        <div className="error-content">
          <h3>Unable to Load Agents</h3>
          {isAuthError ? (
            <>
              <p>You need to be logged in to access agents.</p>
              <p>Please log in to continue.</p>
              <ErrorButton onClick={() => window.location.href = '/login'}>
                Go to Login
              </ErrorButton>
            </>
          ) : (
            <>
              <p>{error}</p>
              <ErrorButton onClick={() => window.location.reload()}>
                Retry
              </ErrorButton>
            </>
          )}
        </div>
      </div>
    );
  }

  if (showAgentSelection) {
    return (
      <div className="search-content" style={{ 
        height: '100%', 
        display: 'flex', 
        flexDirection: 'column',
        overflow: 'hidden'
      }}>
        <AgentSelection 
          agents={agents}
          onAgentSelect={handleAgentSelect}
          isLoading={isLoading}
        />
      </div>
    );
  }

  return (
    <div className={`search-content ${isFullscreen ? 'fullscreen' : ''}`} style={containerStyles}>
      <ChatHeader
        title={selectedAgent?.name || selectedAgent?.id}
        icon={FaRobot}
        isThinking={isThinking}
        onToggleFullscreen={toggleFullscreen}
        onNewChat={handleNewChat}
        isFullscreen={isFullscreen}
      />

      {/* Messages Container */}
      <div className="chat-container">
        {!hasMessages(currentSession) ? (
          <EmptyState
            icon={FaRobot}
            title="Start a conversation"
            description={`Ask ${selectedAgent?.name || selectedAgent?.id} anything to get started`}
          />
        ) : (
          currentSession?.messages?.map((message, index) => (
            <div 
              key={index}
              className={`chat-message ${message.role === 'user' ? 'user' : 'ai'}-message`}
            >
              <div className="message-content">
                {message.role === 'user' ? (
                  <p>{message.content}</p>
                ) : (
                  <div className="markdown-message">
                    <MarkdownReply text={message.content} />
                  </div>
                )}
              </div>
              <div className="message-time">
                {formatTimestamp(message.timestamp)}
              </div>
            </div>
          ))
        )}

        {isThinking && (
          <ThinkingIndicator
            agentName={selectedAgent?.name || selectedAgent?.id}
            onCancel={cancelTask}
          />
        )}
        
        <div ref={messagesEndRef} />
      </div>

      <ChatInput
        onSendMessage={handleSendMessage}
        placeholder="Ask a question..."
        disabled={isThinking}
        isLoading={isThinking}
      />
    </div>
  );
};

export default AgentChat;
