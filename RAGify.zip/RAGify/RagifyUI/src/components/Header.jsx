import React from 'react';
import { FaUser } from 'react-icons/fa';
import '../styles/content-header.css';

const Header = ({ username }) => (
  <header className="content-header">
    <h1>Welcome to Your Dashboard</h1>
    <div className="user-info">
      <span>{username}</span>
      <div className="avatar"><FaUser /></div>
    </div>
  </header>
);

export default Header;
