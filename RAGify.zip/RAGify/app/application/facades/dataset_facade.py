"""Dataset facade for orchestrating dataset-related operations."""

import logging
from typing import List, Optional
from uuid import UUID
from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession

from app.application.dto.dataset_dto import (
    CreateDatasetDTO,
    DatasetDTO,
    DocumentProcessingResultDTO,
    ProcessDocumentDTO,
    UpdateDatasetDTO,
)
from app.application.services.dataset_service import DatasetService
from app.application.services.document_processor import DocumentProcessor
from app.application.facades.aws_facade import AWSS3Facade
from app.domain.schemas import DatasetCreate, DatasetUpdate
from app.domain.models import Dataset
from app.application.exceptions.app_exceptions import DatasetValidationError

logger = logging.getLogger(__name__)


class DatasetFacade:
    """Facade for dataset operations."""
    
    def __init__(
        self,
        dataset_service: DatasetService,
        document_processor: DocumentProcessor,
        aws_facade: AWSS3Facade,
        db_session: AsyncSession,
    ):
        self.dataset_service = dataset_service
        self.document_processor = document_processor
        self.aws_facade = aws_facade
        self.db_session = db_session
    
    async def create_dataset(self, dto: CreateDatasetDTO) -> DatasetDTO:
        """Create a new dataset."""
        try:
            # Validate the S3 path format first
            logger.info(f"Creating dataset with S3 path: {dto.aws_s3_folder_path}")
            
            # Validate AWS credentials and S3 path
            is_valid = await self.aws_facade.validate_credentials(
                aws_access_key_id=dto.aws_access_key_id,
                aws_secret_access_key=dto.aws_secret_access_key,
                bucket_name=dto.aws_s3_folder_path  # This will extract bucket name
            )
            
            if not is_valid:
                raise DatasetValidationError(f"Invalid AWS credentials or S3 path: {dto.aws_s3_folder_path}")
            
            # Create dataset schema for the service
            dataset_create = DatasetCreate(
                name=dto.name,
                description=dto.description,
                aws_s3_folder_path=dto.aws_s3_folder_path,
                aws_access_key_id=dto.aws_access_key_id,
                aws_secret_access_key=dto.aws_secret_access_key,
                embedding_model=dto.embedding_model,
                chunking_strategy=dto.chunking_strategy,
                chunking_parameters={},  # Default empty dict
                allowed_file_types=dto.allowed_file_types,
            )
            
            # Create the dataset
            dataset = await self.dataset_service.create_dataset(
                db=self.db_session,
                dataset_data=dataset_create,
                owner_id=dto.owner_id
            )
            
            # Convert to DTO
            return self._convert_to_dto(dataset)
            
        except Exception as e:
            logger.error(f"Error creating dataset: {str(e)}")
            raise
    
    async def get_dataset(self, dataset_id: UUID, owner_id: UUID) -> Optional[DatasetDTO]:
        """Get a dataset by ID."""
        try:
            dataset = await self.dataset_service.get_dataset_by_id(
                db=self.db_session,
                dataset_id=dataset_id,
                owner_id=owner_id
            )
            
            if not dataset:
                return None
                
            return self._convert_to_dto(dataset)
            
        except Exception as e:
            logger.error(f"Error getting dataset {dataset_id}: {str(e)}")
            raise
    
    async def list_datasets(
        self, 
        owner_id: UUID, 
        limit: int = 100, 
        offset: int = 0
    ) -> List[DatasetDTO]:
        """List datasets for an owner."""
        try:
            datasets = await self.dataset_service.get_datasets_by_owner(
                db=self.db_session,
                owner_id=owner_id,
                skip=offset,
                limit=limit
            )
            
            return [self._convert_to_dto(dataset) for dataset in datasets]
            
        except Exception as e:
            logger.error(f"Error listing datasets for owner {owner_id}: {str(e)}")
            raise
    
    async def update_dataset(
        self, 
        dataset_id: UUID, 
        owner_id: UUID, 
        dto: UpdateDatasetDTO
    ) -> Optional[DatasetDTO]:
        """Update a dataset."""
        try:
            # Create update schema
            dataset_update = DatasetUpdate(
                name=dto.name,
                description=dto.description,
                embedding_model=dto.embedding_model,
                chunking_strategy=dto.chunking_strategy,
                allowed_file_types=dto.allowed_file_types,
            )
            
            dataset = await self.dataset_service.update_dataset(
                db=self.db_session,
                dataset_id=dataset_id,
                dataset_data=dataset_update,
                owner_id=owner_id
            )
            
            if not dataset:
                return None
                
            return self._convert_to_dto(dataset)
            
        except Exception as e:
            logger.error(f"Error updating dataset {dataset_id}: {str(e)}")
            raise
    
    async def delete_dataset(self, dataset_id: UUID, owner_id: UUID) -> bool:
        """Delete a dataset."""
        try:
            return await self.dataset_service.delete_dataset(
                db=self.db_session,
                dataset_id=dataset_id,
                owner_id=owner_id
            )
            
        except Exception as e:
            logger.error(f"Error deleting dataset {dataset_id}: {str(e)}")
            raise
    
    async def process_document(self, dto: ProcessDocumentDTO) -> DocumentProcessingResultDTO:
        """Process a document asynchronously."""
        return await self.document_processor.process_document(dto)
    
    async def get_processing_status(self, task_id: str) -> dict:
        """Get document processing status."""
        return await self.document_processor.get_processing_status(task_id)
    
    async def list_dataset_files(self, dataset_id: UUID, owner_id: UUID) -> dict:
        """List files in a dataset's S3 folder."""
        try:
            # Use the enhanced method from dataset service
            return await self.dataset_service.list_dataset_files_enhanced(dataset_id, owner_id)
            
        except Exception as e:
            logger.error(f"Error listing dataset files: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    def _convert_to_dto(self, dataset: Dataset) -> DatasetDTO:
        """Convert a Dataset model to DatasetDTO."""
        return DatasetDTO(
            id=dataset.id,
            name=dataset.name,
            description=dataset.description,
            aws_s3_folder_path=dataset.aws_s3_folder_path,
            embedding_model=dataset.embedding_model,
            chunking_strategy=dataset.chunking_strategy,
            allowed_file_types=dataset.allowed_file_types,
            owner_id=dataset.owner_id,
            created_at=dataset.created_at,
            updated_at=dataset.updated_at,
        )
