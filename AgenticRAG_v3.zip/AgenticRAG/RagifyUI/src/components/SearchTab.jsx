import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { FaSearch, FaPaperPlane, FaQuoteRight, FaFileAlt, FaExpand, FaCompress } from 'react-icons/fa';
import '../styles/chat-markdown.css';
import '../styles/search-fullscreen.css';
import '../styles/search.css'
import '../styles/search-header.css';
import '../styles/search-input.css';
import '../styles/search-citations.css';
import MarkdownReply from './MarkdownReply';

const SearchTab = ({
  messages,
  query,
  setQuery,
  isSearching,
  handleSearch,
  chatContainerRef,
  selectedCitation,
  handleCitationClick,
  closeCitationModal
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);

  return (
    <div className={isFullscreen ? 'fullscreen-search' : 'search-content'}>
      <div className="search-header-row">
        <h2>Chat with Your Documents</h2>
        <button
          className="fullscreen-toggle-btn"
          onClick={() => setIsFullscreen(f => !f)}
          aria-label={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
        >
          {isFullscreen ? <FaCompress /> : <FaExpand />} {isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
        </button>
      </div>
      <div className="chat-container" ref={chatContainerRef}>
        {messages.length === 0 ? (
          <div className="empty-chat">
            <FaSearch size={40} color="#a0aec0" />
            <p>Ask questions about your documents to get AI-powered answers</p>
          </div>
        ) : (
          messages.map(message => (
            <div 
              key={message.id}
              className={`chat-message ${message.sender}-message ${message.isLoading ? 'loading-message' : ''} ${message.isError ? 'error-message' : ''}`}
            >
              <div className="message-content">
                {message.isLoading ? (
                  <div className="loading-indicator">
                    <div className="bounce1"></div>
                    <div className="bounce2"></div>
                    <div className="bounce3"></div>
                  </div>
                ) : (
                  <>
                    {message.sender === 'ai' ? (
                      <div className="markdown-message">
                        <MarkdownReply text={message.text} />
                      </div>
                    ) : (
                      <p>{message.text}</p>
                    )}
                    {message.citations && message.citations.length > 0 && (
                      <div className="citations">
                        <div className="citations-header">
                          <FaQuoteRight size={14} />
                          <span>Sources ({message.citations.length})</span>
                        </div>
                        <div className="citation-list">
                          {message.citations.map((citation, index) => (
                            <div 
                              key={index} 
                              className="citation-item"
                              onClick={() => handleCitationClick(citation)}
                            >
                              <FaFileAlt size={14} />
                              <span>{citation.source || `Source ${index + 1}`}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </>
                )}
              </div>
              <div className="message-time">
                {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          ))
        )}
      </div>
      <form className="chat-input-container" onSubmit={handleSearch}>
        <input
          type="text"
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Ask a question..."
          disabled={isSearching}
        />
        <button 
          type="submit" 
          className="send-btn"
          disabled={isSearching || !query.trim()}
        >
          <FaPaperPlane />
        </button>
      </form>
      {selectedCitation && (
        <div className="citation-modal">
          <div className="citation-modal-content">
            <div className="citation-modal-header">
              <h3>Source: {selectedCitation.source || 'Document'}</h3>
              <button className="close-btn" onClick={closeCitationModal}>×</button>
            </div>
            <div className="citation-modal-body">
              {selectedCitation.page && (
                <p className="citation-page">Page {selectedCitation.page}</p>
              )}
              <div className="citation-text">
                <blockquote>
                  {selectedCitation.text || 'No text available for this citation.'}
                </blockquote>
              </div>
            </div>
            <div className="citation-modal-footer">
              <button className="primary-btn small" onClick={closeCitationModal}>Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchTab;
