import React, { useState, useEffect } from 'react';
import { FaUserTie, FaLightbulb, FaChartLine, FaSearch, FaCode, FaUsers, FaBrain, FaRocket, FaArrowRight, FaPlus } from 'react-icons/fa';
import LoadingSpinner from './LoadingSpinner';

const AgentSelection = ({ agents, onAgentSelect, isLoading }) => {
  const [hoveredAgent, setHoveredAgent] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [containerHeight, setContainerHeight] = useState('100vh');
  const [currentPage, setCurrentPage] = useState(1);
  const agentsPerPage = 6; // Show 6 agents per page

  // Calculate available height for the component
  useEffect(() => {
    const calculateHeight = () => {
      const viewportHeight = window.innerHeight;
      const headerHeight = 64; // Dashboard header height
      const margins = 16; // Reduced top/bottom margins since we removed container margins
      const padding = 24; // Reduced component padding
      
      // Ensure minimum height for very small screens
      const availableHeight = Math.max(viewportHeight - headerHeight - margins - padding, 400);
      setContainerHeight(`${availableHeight}px`);
    };

    calculateHeight();
    window.addEventListener('resize', calculateHeight);
    
    return () => window.removeEventListener('resize', calculateHeight);
  }, []);

  // Default agent icons mapping
  const getAgentIcon = (agentName) => {
    const name = agentName.toLowerCase();
    if (name.includes('rag')) return <FaSearch />;
    if (name.includes('echo')) return <FaUserTie />;
    if (name.includes('research') || name.includes('search')) return <FaSearch />;
    if (name.includes('data') || name.includes('analytics')) return <FaChartLine />;
    if (name.includes('code') || name.includes('developer')) return <FaCode />;
    if (name.includes('creative') || name.includes('content')) return <FaLightbulb />;
    if (name.includes('social') || name.includes('community')) return <FaUsers />;
    if (name.includes('ai') || name.includes('intelligence')) return <FaBrain />;
    if (name.includes('assistant') || name.includes('helper')) return <FaUserTie />;
    return <FaRocket />;
  };

  // Default agent descriptions if not provided
  const getAgentDescription = (agent) => {
    if (agent.description) return agent.description;
    
    const name = agent.name?.toLowerCase() || agent.id?.toLowerCase() || '';
    if (name.includes('rag')) return 'RAG workflow: dataset discovery, query decomposition, querying, and synthesis with Langfuse tracing';
    if (name.includes('echo')) return 'Echo agent that returns the provided input and session id';
    if (name.includes('research')) return 'Research and analyze information from multiple sources';
    if (name.includes('data')) return 'Analyze data and generate insights';
    if (name.includes('code')) return 'Help with coding tasks and development';
    if (name.includes('creative')) return 'Generate creative content and ideas';
    if (name.includes('social')) return 'Manage social media and community interactions';
    if (name.includes('ai')) return 'Advanced AI-powered assistance';
    if (name.includes('assistant')) return 'General purpose AI assistant';
    return 'Specialized AI agent for your needs';
  };

  const getAgentCategory = (agent) => {
    const name = agent.name?.toLowerCase() || agent.id?.toLowerCase() || '';
    if (name.includes('rag') || name.includes('search')) return 'search';
    if (name.includes('data') || name.includes('analytics')) return 'analytics';
    if (name.includes('code') || name.includes('developer')) return 'development';
    if (name.includes('creative') || name.includes('content')) return 'creative';
    if (name.includes('social') || name.includes('community')) return 'social';
    return 'general';
  };

  const categories = [
    { id: 'all', name: 'All Agents', icon: <FaRocket />, count: agents.length },
    { id: 'search', name: 'Search & RAG', icon: <FaSearch />, count: agents.filter(a => getAgentCategory(a) === 'search').length },
    { id: 'analytics', name: 'Analytics', icon: <FaChartLine />, count: agents.filter(a => getAgentCategory(a) === 'analytics').length },
    { id: 'development', name: 'Development', icon: <FaCode />, count: agents.filter(a => getAgentCategory(a) === 'development').length },
    { id: 'creative', name: 'Creative', icon: <FaLightbulb />, count: agents.filter(a => getAgentCategory(a) === 'creative').length },
    { id: 'social', name: 'Social', icon: <FaUsers />, count: agents.filter(a => getAgentCategory(a) === 'social').length },
    { id: 'general', name: 'General', icon: <FaBrain />, count: agents.filter(a => getAgentCategory(a) === 'general').length },
  ];

  const filteredAgents = selectedCategory === 'all' 
    ? agents 
    : agents.filter(agent => getAgentCategory(agent) === selectedCategory);

  // Reset to first page when category changes
  useEffect(() => {
    setCurrentPage(1);
  }, [selectedCategory]);

  // Calculate pagination
  const totalPages = Math.ceil(filteredAgents.length / agentsPerPage);
  const startIndex = (currentPage - 1) * agentsPerPage;
  const endIndex = startIndex + agentsPerPage;
  const currentAgents = filteredAgents.slice(startIndex, endIndex);

  if (isLoading) {
    return (
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        gap: '24px'
      }}>
        <LoadingSpinner size="large" variant="light" />
        <p style={{ color: '#6b7280', fontSize: '16px' }}>Loading agents...</p>
      </div>
    );
  }

  return (
    <div style={{
      width: '100%',
      maxWidth: '100%',
      margin: '0',
      padding: '12px 16px 32px 16px',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      backgroundColor: '#ffffff',
      height: containerHeight,
      overflow: 'auto',
      display: 'flex',
      flexDirection: 'column',
      borderRadius: '0',
      boxShadow: 'none'
    }}>
      {/* Hero Section */}
      <div style={{
        textAlign: 'center',
        marginBottom: '16px',
        padding: '12px 0',
        flexShrink: 0
      }}>
        <div style={{
          maxWidth: '700px',
          margin: '0 auto'
        }}>
          <h1 style={{
            fontSize: '1.875rem',
            fontWeight: '600',
            color: '#1f2937',
            margin: '0 0 12px 0',
            lineHeight: '1.2',
            letterSpacing: '-0.025em'
          }}>
            Choose Your AI Agent
          </h1>
          <p style={{
            fontSize: '1rem',
            color: '#6b7280',
            margin: '0 0 16px 0',
            lineHeight: '1.5',
            maxWidth: '500px',
            marginLeft: 'auto',
            marginRight: 'auto',
            fontWeight: '400'
          }}>
            Select from our collection of specialized AI agents to help you automate tasks, 
            analyze data, and boost your productivity.
          </p>
          
          {/* Stats */}
          <div style={{
            display: 'flex',
            justifyContent: 'center',
            gap: '24px',
            marginTop: '12px',
            padding: '12px 0',
            borderTop: '1px solid #f3f4f6'
          }}>
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '8px'
            }}>
              <span style={{
                fontSize: '1.5rem',
                fontWeight: '700',
                color: '#1f2937',
                lineHeight: '1'
              }}>{agents.length}</span>
              <span style={{
                fontSize: '0.875rem',
                color: '#9ca3af',
                fontWeight: '500',
                textTransform: 'uppercase',
                letterSpacing: '0.05em'
              }}>Available Agents</span>
            </div>
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '8px'
            }}>
              <span style={{
                fontSize: '1.5rem',
                fontWeight: '700',
                color: '#1f2937',
                lineHeight: '1'
              }}>24/7</span>
              <span style={{
                fontSize: '0.875rem',
                color: '#9ca3af',
                fontWeight: '500',
                textTransform: 'uppercase',
                letterSpacing: '0.05em'
              }}>Availability</span>
            </div>
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '8px'
            }}>
              <span style={{
                fontSize: '1.5rem',
                fontWeight: '700',
                color: '#1f2937',
                lineHeight: '1'
              }}>∞</span>
              <span style={{
                fontSize: '0.875rem',
                color: '#9ca3af',
                fontWeight: '500',
                textTransform: 'uppercase',
                letterSpacing: '0.05em'
              }}>Possibilities</span>
            </div>
          </div>
        </div>
      </div>

      {/* Category Filter */}
      <div style={{
        marginBottom: '16px',
        flexShrink: 0
      }}>
        <div style={{
          display: 'flex',
          gap: '8px',
          flexWrap: 'wrap',
          justifyContent: 'center'
        }}>
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                padding: '8px 16px',
                borderRadius: '6px',
                border: selectedCategory === category.id ? '1px solid #1f2937' : '1px solid #e5e7eb',
                backgroundColor: selectedCategory === category.id ? '#1f2937' : 'white',
                color: selectedCategory === category.id ? 'white' : '#6b7280',
                cursor: 'pointer',
                fontSize: '13px',
                fontWeight: '500',
                transition: 'all 0.2s ease',
                boxShadow: selectedCategory === category.id ? '0 2px 8px rgba(31, 41, 55, 0.15)' : '0 1px 3px rgba(0, 0, 0, 0.1)'
              }}
              onMouseEnter={(e) => {
                if (selectedCategory !== category.id) {
                  e.target.style.backgroundColor = '#f9fafb';
                  e.target.style.borderColor = '#d1d5db';
                }
              }}
              onMouseLeave={(e) => {
                if (selectedCategory !== category.id) {
                  e.target.style.backgroundColor = 'white';
                  e.target.style.borderColor = '#e5e7eb';
                }
              }}
            >
              {category.icon}
              {category.name}
              <span style={{
                backgroundColor: selectedCategory === category.id ? 'rgba(255, 255, 255, 0.2)' : '#f3f4f6',
                color: selectedCategory === category.id ? 'white' : '#6b7280',
                padding: '2px 8px',
                borderRadius: '6px',
                fontSize: '12px',
                fontWeight: '500',
                minWidth: '20px',
                textAlign: 'center'
              }}>
                {category.count}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Agents Grid */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 400px))',
        gap: '16px',
        marginBottom: '16px',
        flex: 1,
        overflow: 'auto',
        minHeight: 0,
        justifyContent: 'center'
      }}>
        {currentAgents.map((agent, index) => (
          <div 
            key={agent.id} 
            style={{
              background: 'white',
              borderRadius: '12px',
              padding: '16px',
              border: '1px solid #f3f4f6',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              transform: hoveredAgent === agent.id ? 'translateY(-2px)' : 'translateY(0)',
              boxShadow: hoveredAgent === agent.id 
                ? '0 8px 16px rgba(0, 0, 0, 0.08)' 
                : '0 1px 3px rgba(0, 0, 0, 0.05)',
              position: 'relative',
              overflow: 'hidden',
              height: '200px',
              display: 'flex',
              flexDirection: 'column'
            }}
            onClick={() => onAgentSelect(agent)}
            onMouseEnter={() => setHoveredAgent(agent.id)}
            onMouseLeave={() => setHoveredAgent(null)}
          >
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'flex-start',
              marginBottom: '12px'
            }}>
              <div style={{
                width: '48px',
                height: '48px',
                borderRadius: '8px',
                background: '#f8fafc',
                border: '1px solid #e5e7eb',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#6b7280',
                fontSize: '20px'
              }}>
                {getAgentIcon(agent.name || agent.id)}
              </div>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                padding: '4px 10px',
                backgroundColor: '#f3f4f6',
                borderRadius: '6px',
                border: '1px solid #e5e7eb'
              }}>
                <div style={{
                  width: '6px',
                  height: '6px',
                  backgroundColor: '#10b981',
                  borderRadius: '50%'
                }} />
                <span style={{
                  fontSize: '11px',
                  fontWeight: '500',
                  color: '#6b7280'
                }}>Available</span>
              </div>
            </div>
            
            <div style={{
              marginBottom: '12px',
              flex: 1,
              display: 'flex',
              flexDirection: 'column'
            }}>
              <h3 style={{
                fontSize: '1rem',
                fontWeight: '600',
                color: '#1f2937',
                margin: '0 0 6px 0',
                lineHeight: '1.3'
              }}>
                {agent.name || agent.id}
              </h3>
              <p style={{
                fontSize: '13px',
                color: '#6b7280',
                margin: 0,
                lineHeight: '1.4',
                flex: 1,
                overflow: 'hidden',
                display: '-webkit-box',
                WebkitLineClamp: 3,
                WebkitBoxOrient: 'vertical'
              }}>
                {getAgentDescription(agent)}
              </p>
            </div>

            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginTop: 'auto'
            }}>
              <div style={{
                display: 'flex',
                gap: '6px'
              }}>
                <span style={{
                  padding: '3px 8px',
                  backgroundColor: '#f3f4f6',
                  color: '#6b7280',
                  borderRadius: '4px',
                  fontSize: '11px',
                  fontWeight: '500',
                  border: '1px solid #e5e7eb'
                }}>
                  AI
                </span>
                {agent.tags && agent.tags.slice(0, 2).map((tag, index) => (
                  <span key={index} style={{
                    padding: '3px 8px',
                    backgroundColor: '#f3f4f6',
                    color: '#6b7280',
                    borderRadius: '4px',
                    fontSize: '11px',
                    fontWeight: '500',
                    border: '1px solid #e5e7eb'
                  }}>
                    {tag}
                  </span>
                ))}
              </div>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                color: '#1f2937',
                fontWeight: '500',
                fontSize: '13px',
                transition: 'transform 0.2s ease',
                transform: hoveredAgent === agent.id ? 'translateX(2px)' : 'translateX(0)'
              }}>
                <span>Start Chat</span>
                <FaArrowRight style={{ fontSize: '11px' }} />
              </div>
            </div>
          </div>
        ))}


      </div>

      {/* Navigation Controls */}
      {totalPages > 1 && (
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          gap: '12px',
          marginBottom: '16px',
          flexShrink: 0
        }}>
          <button
            onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
            disabled={currentPage === 1}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '8px 16px',
              borderRadius: '6px',
              border: '1px solid #e5e7eb',
              backgroundColor: currentPage === 1 ? '#f9fafb' : 'white',
              color: currentPage === 1 ? '#9ca3af' : '#6b7280',
              cursor: currentPage === 1 ? 'not-allowed' : 'pointer',
              fontSize: '14px',
              fontWeight: '500',
              transition: 'all 0.2s ease'
            }}
            onMouseEnter={(e) => {
              if (currentPage !== 1) {
                e.target.style.backgroundColor = '#f3f4f6';
                e.target.style.borderColor = '#d1d5db';
              }
            }}
            onMouseLeave={(e) => {
              if (currentPage !== 1) {
                e.target.style.backgroundColor = 'white';
                e.target.style.borderColor = '#e5e7eb';
              }
            }}
          >
            ← Previous
          </button>

          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
              <button
                key={page}
                onClick={() => setCurrentPage(page)}
                style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '6px',
                  border: page === currentPage ? '1px solid #1f2937' : '1px solid #e5e7eb',
                  backgroundColor: page === currentPage ? '#1f2937' : 'white',
                  color: page === currentPage ? 'white' : '#6b7280',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: '500',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => {
                  if (page !== currentPage) {
                    e.target.style.backgroundColor = '#f9fafb';
                    e.target.style.borderColor = '#d1d5db';
                  }
                }}
                onMouseLeave={(e) => {
                  if (page !== currentPage) {
                    e.target.style.backgroundColor = 'white';
                    e.target.style.borderColor = '#e5e7eb';
                  }
                }}
              >
                {page}
              </button>
            ))}
          </div>

          <button
            onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
            disabled={currentPage === totalPages}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '8px 16px',
              borderRadius: '6px',
              border: '1px solid #e5e7eb',
              backgroundColor: currentPage === totalPages ? '#f9fafb' : 'white',
              color: currentPage === totalPages ? '#9ca3af' : '#6b7280',
              cursor: currentPage === totalPages ? 'not-allowed' : 'pointer',
              fontSize: '14px',
              fontWeight: '500',
              transition: 'all 0.2s ease'
            }}
            onMouseEnter={(e) => {
              if (currentPage !== totalPages) {
                e.target.style.backgroundColor = '#f3f4f6';
                e.target.style.borderColor = '#d1d5db';
              }
            }}
            onMouseLeave={(e) => {
              if (currentPage !== totalPages) {
                e.target.style.backgroundColor = 'white';
                e.target.style.borderColor = '#e5e7eb';
              }
            }}
          >
            Next →
          </button>
        </div>
      )}

      {/* Page Info */}
      {totalPages > 1 && (
        <div style={{
          textAlign: 'center',
          marginBottom: '16px',
          fontSize: '14px',
          color: '#6b7280',
          flexShrink: 0
        }}>
          Showing {startIndex + 1}-{Math.min(endIndex, filteredAgents.length)} of {filteredAgents.length} agents
        </div>
      )}

    </div>
  );
};

export default AgentSelection;
