import io
import logging
import zipfile

from fastapi import (
    APIRouter,
    Depends,
    File,
    HTTPException,
    Query,
    Request,
    UploadFile,
    status,
)
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import (
    get_async_session,
    get_current_user,
    get_aws_service,
    get_dataset_service,
)
from app.domain.models import User
from app.application.services.aws_service import AWSService
from app.application.services.dataset_service import DatasetService
from app.domain.schemas import AWSCredentialsValidation, AWSValidationResponse
from app.application.utils.logging_utils import add_log_context

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/aws", tags=["aws"])


@router.post("/validate-credentials", response_model=AWSValidationResponse)
async def validate_aws_credentials(
    credentials: AWSCredentialsValidation,
    request: Request,
    current_user: User = Depends(get_current_user),
    aws_service: AWSService = Depends(get_aws_service),
):
    """
    Validate user-provided AWS S3 credentials
    """
    try:
        # Add context for logging
        add_log_context(
            request,
            operation="validate_aws_credentials",
            user_id=str(current_user.id),
            s3_path=credentials.aws_s3_folder_path,
        )
        # Extract bucket and path from S3 URL
        bucket_name, folder_path = AWSService.extract_bucket_and_path(
            credentials.aws_s3_folder_path
        )

        # Validate credentials using service instance
        validation_result = await aws_service.validate_credentials(
            aws_access_key_id=credentials.aws_access_key_id,
            aws_secret_access_key=credentials.aws_secret_access_key,
            bucket_name=bucket_name,
            folder_path=folder_path,
        )

        logger.info(f"AWS credentials validation result: {validation_result.status}")
        return validation_result

    except ValueError as e:
        logger.error(f"Invalid S3 path: {str(e)}")
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        logger.error(f"AWS credentials validation error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to validate AWS credentials",
        )


@router.post("/upload-file")
async def upload_file_to_s3(
    dataset_id: str,
    request: Request,
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session),
    dataset_service: DatasetService = Depends(get_dataset_service),
    aws_service: AWSService = Depends(get_aws_service),
):
    """
    Upload a file to S3 using dataset_id (credentials fetched from DB)
    """
    # Add context for logging
    add_log_context(
        request,
        operation="upload_file",
        resource_id=dataset_id,
        user_id=str(current_user.id),
        file_name=file.filename,
        file_size=file.size,
        content_type=file.content_type,
    )
    # Get AWS credentials for the dataset and user
    creds = await dataset_service.get_aws_credentials(db, dataset_id, current_user.id)
    logger.info(f"Fetched AWS credentials: {creds}")  # Info log for credentials
    if not creds:
        raise HTTPException(
            status_code=404, detail="Dataset not found or not owned by user"
        )
    bucket_name, folder_path = AWSService.extract_bucket_and_path(
        creds["aws_s3_folder_path"]
    )
    result = await aws_service.upload_file(
        aws_access_key_id=creds["aws_access_key_id"],
        aws_secret_access_key=creds["aws_secret_access_key"],
        bucket_name=bucket_name,
        file_obj=file.file,
        file_name=file.filename,
        folder_path=folder_path,
    )
    if result["status"] == "success":
        return result
    else:
        raise HTTPException(status_code=500, detail=result["message"])


@router.get("/download-file")
async def download_files_from_s3(
    dataset_id: str,
    request: Request,
    dataset_object_ids: list[str] = Query(..., description="List of dataset_object_id"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session),
    aws_service: AWSService = Depends(get_aws_service),
):
    """
    Download one or more files from S3 as a ZIP using dataset_id and dataset_object_ids
    """
    # Add context for logging
    add_log_context(
        request,
        operation="download_files",
        resource_id=dataset_id,
        user_id=str(current_user.id),
        object_count=len(dataset_object_ids),
        object_ids=dataset_object_ids,
    )
    files_to_zip = []
    for obj_id in dataset_object_ids:
        result = await aws_service.download_file_by_dataset_object_id(
            db=db,
            dataset_id=dataset_id,
            owner_id=current_user.id,
            dataset_object_id=obj_id,
        )
        if result["status"] == "success":
            files_to_zip.append((result["file_name"], result["file_bytes"]))
        else:
            logger.warning(
                f"Could not download file for object_id {obj_id}: {result['message']}"
            )
    if not files_to_zip:
        raise HTTPException(status_code=404, detail="No files found for provided IDs")
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w") as zipf:
        for fname, fbytes in files_to_zip:
            zipf.writestr(fname, fbytes)
    zip_buffer.seek(0)
    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={"Content-Disposition": "attachment; filename=downloaded_files.zip"},
    )
