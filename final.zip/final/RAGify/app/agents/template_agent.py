"""Template agent to copy when creating a new agent.

- Place the file in `app/agents`.
- Implement `invoke(payload) -> dict` and `register()` returning metadata.
- Avoid import-time side effects: defer heavy imports to `invoke()`.
"""

AGENT_ID = "template_agent"
DESCRIPTION = "A small template agent to copy for new agents."


def invoke(payload: dict) -> dict:
    # Simple echo example
    return {"agent": AGENT_ID, "result": payload}


def register():
    return {"id": AGENT_ID, "description": DESCRIPTION, "invoke": invoke}
