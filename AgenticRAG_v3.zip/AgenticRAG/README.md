# RAG-as-a-Service Backend

A scalable, secure, and robust backend for RAG-as-a-Service platform built with FastAPI and Python. This backend provides comprehensive APIs for user management, dataset handling, AWS S3 integration, Airflow orchestration, and RAG querying capabilities.

## 🚀 Features

- **Authentication & Authorization**: JWT-based authentication with refresh tokens
- **User Management**: Secure user registration, login, and profile management
- **Dataset Management**: CRUD operations for datasets with data ownership enforcement
- **AWS S3 Integration**: Secure credential validation and file handling
- **Airflow Orchestration**: Background processing pipeline management
- **RAG Querying**: Chat interfaces for single and multi-dataset queries
- **Data Ownership**: Row-level security ensuring users can only access their own data
- **Async Operations**: High-performance async/await throughout the application
- **Auto-generated Documentation**: Interactive API docs with Swagger UI and ReDoc

## 🏗️ Architecture

```
├── app/
│   ├── api/
│   │   └── routers/        # API endpoint definitions
│   ├── core/
│   │   └── config.py       # Application configuration
│   ├── db/
│   │   └── database.py     # Database connection and session management
│   ├── models/
│   │   └── database.py     # SQLAlchemy models
│   ├── schemas/
│   │   └── *.py           # Pydantic models for request/response validation
│   ├── services/
│   │   └── *.py           # Business logic layer
│   ├── utils/
│   │   └── auth.py        # Authentication utilities
│   └── main.py            # FastAPI application factory
├── alembic/               # Database migrations
├── tests/                 # Test suite
├── requirements.txt       # Python dependencies
└── docker-compose.yml     # Development environment
```

## 🔧 Tech Stack

- **Framework**: FastAPI 0.104+
- **Database**: PostgreSQL with PGVector extension
- **ORM**: SQLAlchemy 2.0 (async)
- **Authentication**: JWT with fastapi-users
- **Authorization**: fastapi-permissions for row-level security
- **Background Tasks**: Celery with Redis
- **Cloud Integration**: AWS S3 and Boto3
- **Orchestration**: Apache Airflow
- **Testing**: pytest with async support
- **Documentation**: Auto-generated OpenAPI/Swagger

## 🚦 Getting Started

### Prerequisites

- Python 3.11+
- PostgreSQL 15+
- Redis 7+
- Docker & Docker Compose (optional)

### Quick Start with Docker

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd AgenticRAG
   ```

2. **Start with Docker Compose**
   ```bash
   docker-compose up -d
   ```

3. **Apply database migrations**
   ```bash
   docker-compose exec backend alembic upgrade head
   ```

4. **Access the API**
   - API: http://localhost:8000
   - Documentation: http://localhost:8000/docs
   - Alternative docs: http://localhost:8000/redoc
   - pgAdmin: http://localhost:5050

### Manual Setup

1. **Setup environment**
   ```bash
   chmod +x setup.sh
   ./setup.sh
   ```

2. **Activate virtual environment**
   ```bash
   source venv/bin/activate
   ```

3. **Configure environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your configurations
   ```

4. **Initialize database**
   ```bash
   alembic upgrade head
   ```

5. **Run development server**
   ```bash
   python run_dev.py
   ```

## 🔐 Environment Configuration

Key environment variables to configure in `.env`:

```env
# Database
DATABASE_URL=postgresql+asyncpg://user:password@localhost/ragservice

# JWT Security
SECRET_KEY=your-secret-key-here
REFRESH_TOKEN_SECRET_KEY=your-refresh-secret-key-here

# AWS Configuration
AWS_ACCESS_KEY_ID=your-service-aws-key
AWS_SECRET_ACCESS_KEY=your-service-aws-secret

# Airflow
AIRFLOW_BASE_URL=http://localhost:8080
AIRFLOW_USERNAME=admin
AIRFLOW_PASSWORD=admin

# Redis
REDIS_URL=redis://localhost:6379/0
```

## 📊 API Endpoints

### Authentication
- `POST /api/v1/auth/register` - Register new user
- `POST /api/v1/auth/jwt/login` - Login and get tokens
- `POST /api/v1/auth/jwt/refresh` - Refresh access token
- `POST /api/v1/auth/logout` - Logout user

### Users
- `GET /api/v1/users/me` - Get current user profile

### Datasets
- `POST /api/v1/datasets` - Create new dataset
- `GET /api/v1/datasets` - List user's datasets
- `GET /api/v1/datasets/{id}` - Get dataset details
- `PUT /api/v1/datasets/{id}` - Update dataset
- `DELETE /api/v1/datasets/{id}` - Delete dataset
- `GET /api/v1/datasets/{id}/status` - Get processing status

### Dataset Objects
- `GET /api/v1/dataset_objects/{dataset_id}` - List files in dataset
- `GET /api/v1/dataset_objects/object/{object_id}` - Get file details

### AWS Integration
- `POST /api/v1/aws/validate-credentials` - Validate AWS credentials

### Chat/RAG
- `POST /api/v1/chat/{dataset_id}` - Chat with specific dataset
- `POST /api/v1/chat/all` - Chat with all user datasets

### Airflow
- `GET /api/v1/airflow/dag-status/{dag_run_id}` - Get DAG run status

## 🔒 Security Features

- **JWT Authentication**: Secure token-based authentication
- **Password Security**: bcrypt hashing with strong validation
- **Data Ownership**: Row-level security with fastapi-permissions
- **CORS Protection**: Configurable CORS middleware
- **Input Validation**: Comprehensive Pydantic validation
- **SQL Injection Prevention**: SQLAlchemy ORM with parameterized queries
- **Credential Handling**: Ephemeral AWS credential usage

## 🗄️ Database Schema

### Users
- User authentication and profile information
- Extends fastapi-users base table

### Datasets
- User-created collections of files
- Embedding and chunking configurations
- Processing status tracking

### Dataset Objects
- Individual files within datasets
- Processing status and metadata
- Links to vector embeddings

### Embedding Vectors
- Vector embeddings with PGVector
- Chunk text and metadata
- Similarity search capabilities

## 🧪 Testing

Run the test suite:

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=app

# Run specific test file
pytest tests/test_auth.py

# Run with verbose output
pytest -v
```

## 📈 Performance Considerations

- **Async Operations**: Full async/await throughout the stack
- **Database Optimization**: Efficient queries with proper indexing
- **Background Processing**: Celery for long-running tasks
- **Caching**: Redis for session and temporary data
- **Connection Pooling**: Optimized database connections

## 🚀 Deployment

### Production Deployment

1. **Build and deploy**
   ```bash
   chmod +x deploy.sh
   ./deploy.sh
   ```

2. **Set up production environment**
   ```bash
   cp .env.example .env.production
   # Configure production values
   ```

3. **Run database migrations**
   ```bash
   alembic upgrade head
   ```

### Environment-specific Configurations

- **Development**: `docker-compose.yml`
- **Testing**: Separate test database configuration
- **Production**: Environment variables and secrets management

## 📚 Development Guidelines

### Code Style
- Follow PEP 8 standards
- Use type hints throughout
- Comprehensive docstrings
- Async/await for I/O operations

### Project Structure
- Modular design with clear separation of concerns
- Service layer for business logic
- Router layer for API endpoints
- Model layer for data structures

### Best Practices
- Error handling with proper HTTP status codes
- Comprehensive logging
- Input validation and sanitization
- Security-first approach

## 🔄 Database Migrations

Create and apply migrations:

```bash
# Create new migration
alembic revision --autogenerate -m "Description of changes"

# Apply migrations
alembic upgrade head

# Rollback migration
alembic downgrade -1

# View migration history
alembic history
```

## 📋 TODO / Future Enhancements

- [ ] Implement actual RAG querying with vector search
- [ ] Add comprehensive test coverage
- [ ] Implement rate limiting
- [ ] Add user email verification
- [ ] Implement subscription management
- [ ] Add comprehensive logging and monitoring
- [ ] Implement caching strategies
- [ ] Add API versioning
- [ ] Implement webhook notifications
- [ ] Add metrics and analytics

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Issues**
   - Check PostgreSQL is running
   - Verify DATABASE_URL configuration
   - Ensure database exists

2. **Authentication Issues**
   - Verify SECRET_KEY configuration
   - Check token expiration settings
   - Validate JWT token format

3. **AWS Integration Issues**
   - Verify AWS credentials
   - Check S3 permissions
   - Validate bucket access

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass
6. Submit a pull request

## 📞 Support

For questions and support:
- Create an issue in the repository
- Review the API documentation at `/docs`
- Check the troubleshooting section

---

**Note**: This is a comprehensive backend scaffolding that provides a solid foundation for a RAG-as-a-Service platform. Some components (like the actual RAG querying implementation) are marked as TODO items and would need to be implemented based on specific requirements and chosen ML/AI frameworks.
