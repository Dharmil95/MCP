import Login from '../pages/Login';
import Signup from '../pages/Signup';
import Dashboard from '../pages/Dashboard';
import DatasetFilesPage from '../pages/DatasetFilesPage';
import ProtectedRoute from '../components/common/ProtectedRoute';

/**
 * Route configuration for the application
 */
export const routes = [
  // Public routes
  {
    path: '/login',
    element: <Login />,
    public: true
  },
  {
    path: '/signup',
    element: <Signup />,
    public: true
  },
  
  // Protected routes
  {
    path: '/dashboard',
    element: <Dashboard />,
    protected: true
  },
  {
    path: '/datasets/:datasetId/files',
    element: <DatasetFilesPage />,
    protected: true
  }
];

/**
 * Get route elements with protection applied
 * @returns {Array} Array of route elements
 */
export const getRouteElements = () => {
  return routes.map(route => {
    if (route.protected) {
      return {
        ...route,
        element: <ProtectedRoute>{route.element}</ProtectedRoute>
      };
    }
    return route;
  });
};
