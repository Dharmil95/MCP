import { useState } from 'react';

// Predefined loading messages for common scenarios
const LOADING_MESSAGES = {
  // Authentication
  signin: {
    message: "Signing In",
    subtitle: "Authenticating your credentials"
  },
  signup: {
    message: "Creating Account",
    subtitle: "Setting up your RAGify workspace"
  },
  
  // Data Loading
  datasets: {
    message: "Loading Datasets",
    subtitle: "Fetching your dataset collection"
  },
  datasetFiles: {
    message: "Loading Dataset Files",
    subtitle: "Fetching your dataset information and file status"
  },
  
  // File Operations
  upload: {
    message: "Uploading Files",
    subtitle: "Processing your documents"
  },
  processing: {
    message: "Processing Files",
    subtitle: "Analyzing and indexing your content"
  },
  
  // General
  loading: {
    message: "Loading...",
    subtitle: "Please wait while we prepare your experience"
  },
  initializing: {
    message: "Initializing RAGify",
    subtitle: "Setting up your AI-powered workspace"
  },
  
  // Search
  searching: {
    message: "Searching",
    subtitle: "Finding relevant information for you"
  },
  
  // Agent
  agentChat: {
    message: "Connecting to Agent",
    subtitle: "Establishing secure communication"
  }
};

/**
 * Custom hook for managing loading states with consistent messaging
 * @param {string} type - The type of loading (e.g., 'signin', 'datasets', 'upload')
 * @param {object} customMessages - Custom message and subtitle
 * @returns {object} - Loading state and functions
 */
const useLoadingScreen = (type = 'loading', customMessages = null) => {
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showProgress, setShowProgress] = useState(false);

  // Get messages based on type or use custom messages
  const messages = customMessages || LOADING_MESSAGES[type] || LOADING_MESSAGES.loading;

  const startLoading = (showProgressBar = false) => {
    setIsLoading(true);
    setProgress(0);
    setShowProgress(showProgressBar);
  };

  const stopLoading = () => {
    setIsLoading(false);
    setProgress(0);
    setShowProgress(false);
  };

  const updateProgress = (newProgress) => {
    setProgress(Math.min(100, Math.max(0, newProgress)));
  };

  const LoadingComponent = () => {
    if (!isLoading) return null;
    
    return {
      message: messages.message,
      subtitle: messages.subtitle,
      showProgress,
      progress
    };
  };

  return {
    isLoading,
    progress,
    showProgress,
    startLoading,
    stopLoading,
    updateProgress,
    LoadingComponent
  };
};

export default useLoadingScreen;
export { LOADING_MESSAGES };
