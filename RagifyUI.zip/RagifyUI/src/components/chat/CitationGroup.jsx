import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { FaQuoteRight, FaFileAlt, FaChevronDown, FaChevronUp } from 'react-icons/fa';

const CitationGroup = ({ citations, selectedCitation, onCitationClick }) => {
  const [expandedCitations, setExpandedCitations] = useState(new Set());

  const toggleCitationExpansion = (citationIndex) => {
    setExpandedCitations(prev => {
      const newSet = new Set(prev);
      if (newSet.has(citationIndex)) {
        newSet.delete(citationIndex);
      } else {
        newSet.add(citationIndex);
      }
      return newSet;
    });
  };

  const getUniqueCitations = (citations) => {
    const uniqueFiles = new Map();
    citations.forEach((citation, index) => {
      const title = citation.title || citation.filename || 'Untitled Document';
      if (!uniqueFiles.has(title)) {
        uniqueFiles.set(title, {
          title,
          citations: []
        });
      }
      uniqueFiles.get(title).citations.push({ ...citation, originalIndex: index });
    });
    return Array.from(uniqueFiles.values());
  };

  if (!citations || citations.length === 0) {
    return null;
  }

  const fileGroups = getUniqueCitations(citations);

  return (
    <div className="citations-container">
      <h4 className="citations-title">
        <FaQuoteRight /> Sources ({citations.length})
      </h4>
      <div className="citations-list">
        {fileGroups.map((fileGroup, fileIndex) => {
          const isExpanded = expandedCitations.has(fileIndex);
          return (
            <div key={fileIndex} className="citation-file-group">
              <div 
                className="citation-file-header"
                onClick={() => toggleCitationExpansion(fileIndex)}
              >
                <div className="citation-icon">
                  <FaFileAlt />
                </div>
                <div className="citation-title">
                  {fileGroup.title}
                </div>
                <div className="citation-count">
                  ({fileGroup.citations.length} chunk{fileGroup.citations.length > 1 ? 's' : ''})
                </div>
                <div className="citation-expand-icon">
                  {isExpanded ? <FaChevronUp /> : <FaChevronDown />}
                </div>
              </div>
              
              {isExpanded && (
                <div className="citation-chunks">
                  {fileGroup.citations.map((citation, chunkIndex) => (
                    <div 
                      key={chunkIndex}
                      className={`citation-chunk ${selectedCitation === citation ? 'selected' : ''}`}
                      onClick={() => onCitationClick(citation)}
                    >
                      <div className="citation-chunk-header">
                        <span className="chunk-number">Chunk {chunkIndex + 1}</span>
                        {citation.page && (
                          <span className="chunk-page">Page {citation.page}</span>
                        )}
                        {citation.similarity && (
                          <span className="chunk-similarity">
                            {(citation.similarity * 100).toFixed(1)}% match
                          </span>
                        )}
                      </div>
                      <div className="citation-snippet">
                        {citation.snippet}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

CitationGroup.propTypes = {
  citations: PropTypes.arrayOf(PropTypes.shape({
    title: PropTypes.string,
    snippet: PropTypes.string,
    page: PropTypes.number,
    similarity: PropTypes.number
  })),
  selectedCitation: PropTypes.object,
  onCitationClick: PropTypes.func.isRequired
};

export default CitationGroup;
