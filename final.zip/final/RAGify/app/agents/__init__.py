import importlib
import logging
import pkgutil
import traceback
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# Internal registries
_agents: Dict[str, Dict[str, Any]] = {}
_import_errors: Dict[str, str] = {}


def _load_agents() -> None:
    """Scan package modules and populate the `_agents` mapping.

    Agents may expose either:
      - a callable `register()` function returning a metadata dict OR
      - module-level attributes: `AGENT_ID`/`agent_id`, `DESCRIPTION`/`description`,
        and at least one of `invoke` or `graph`.
    """
    global _agents, _import_errors
    _agents = {}
    _import_errors = {}

    for finder, name, ispkg in pkgutil.iter_modules(__path__):
        if name.startswith("_"):
            continue
        full_name = f"{__name__}.{name}"
        try:
            mod = importlib.import_module(full_name)

            meta: Optional[Dict[str, Any]] = None
            # Preferred contract: register() callable
            if hasattr(mod, "register") and callable(getattr(mod, "register")):
                meta = mod.register()
            else:
                agent_id = (
                    getattr(mod, "AGENT_ID", None)
                    or getattr(mod, "agent_id", None)
                    or name
                )
                description = getattr(mod, "DESCRIPTION", None) or getattr(
                    mod, "description", ""
                )
                invoke = getattr(mod, "invoke", None)
                graph = getattr(mod, "graph", None)
                # If a module doesn't expose an agent entrypoint, skip it silently.
                # This allows helper modules (e.g. base.py) to live in the package
                # without creating an import-time error in the registry.
                if invoke is None and graph is None:
                    logger.debug(
                        "module %s does not expose invoke or graph; skipping", full_name
                    )
                    continue
                meta = {
                    "id": agent_id,
                    "description": description,
                    "invoke": invoke,
                    "graph": graph,
                }

            _agents[meta["id"]] = meta
        except Exception:
            tb = traceback.format_exc()
            _import_errors[name] = tb
            logger.exception("failed to import agent module %s", full_name)


def refresh() -> None:
    """Public: refresh the agent list by rescanning the package."""
    _load_agents()


def list_agents() -> List[Dict[str, str]]:
    refresh()
    return [
        {"id": v["id"], "description": v.get("description", "")}
        for v in _agents.values()
    ]


def get(agent_id: str) -> Optional[Dict[str, Any]]:
    refresh()
    return _agents.get(agent_id)


def import_errors() -> Dict[str, str]:
    """Return any import-time errors keyed by module name for debugging."""
    refresh()
    return _import_errors


__all__ = ["refresh", "list_agents", "get", "import_errors"]
