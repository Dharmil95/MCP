import api from './api';

// We'll use the main API instance since our Vite proxy is now properly configured to route
// requests to the appropriate services based on the path

const datasetService = {
  /**
   * Get all datasets
   * @returns {Promise} - Array of datasets
   */
  getDatasets: async () => {
    try {
      const response = await api.get('/datasets');
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  /**
   * Create a new dataset
   * @param {Object} datasetData - Dataset configuration
   * @returns {Promise} - Created dataset
   */
  createDataset: async (datasetData) => {
    try {
      const response = await api.post('/datasets', datasetData);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  /**
   * Delete a dataset
   * @param {string} datasetId - Dataset UUID
   * @returns {Promise} - Success response
   */
  deleteDataset: async (datasetId) => {
    try {
      const response = await api.delete(`/datasets/${datasetId}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  /**
   * Get dataset files
   * @param {string} datasetId - Dataset UUID
   * @returns {Promise} - Array of files
   */
  getDatasetFiles: async (datasetId) => {
    try {
      const response = await api.get(`/datasets/${datasetId}/files`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  /**
   * Delete a file from dataset
   * @param {string} fileId - File UUID
   * @returns {Promise} - Success response
   */
  deleteFile: async (fileId) => {
    try {
      // Use the correct endpoint for deleting dataset objects
      const response = await api.delete(`/dataset_objects/object/${fileId}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  /**
   * Get dataset by ID
   * @param {string} datasetId - Dataset UUID
   * @returns {Promise} - Dataset object
   */
  getDatasetById: async (datasetId) => {
    try {
      const response = await api.get(`/datasets/${datasetId}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  /**
   * Get dataset files with status
   * @param {string} datasetId - Dataset UUID
   * @returns {Promise} - Array of files with status
   */
  getDatasetFilesWithStatus: async (datasetId) => {
    try {
      const response = await api.get(`/dataset_objects/objects_with_status/${datasetId}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  /**
   * Upload file to dataset (via AWS S3)
   * @param {string} datasetId - Dataset UUID
   * @param {File} file - File to upload
   * @returns {Promise} - Upload response
   */
  uploadFileToDataset: async (datasetId, file) => {
    try {
      const formData = new FormData();
      formData.append('file', file);
      
      const response = await api.post(`/aws/upload-file`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        params: { dataset_id: datasetId }
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  /**
   * Get dataset status
   * @param {string} datasetId - Dataset UUID
   * @returns {Promise} - Dataset status response
   */
  getDatasetStatus: async (datasetId) => {
    try {
      const response = await api.get(`/datasets/${datasetId}/status`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  /**
   * Process dataset
   * @param {string} datasetId - Dataset UUID
   * @returns {Promise} - Processing response
   */
  processDataset: async (datasetId) => {
    try {
      const response = await api.post(`/datasets/${datasetId}/process`);
      return response.data;
    } catch (error) {
      throw error;
    }
  }
};

export default datasetService;
