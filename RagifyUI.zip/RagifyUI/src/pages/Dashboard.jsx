import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import DashboardTab from '../components/DashboardTab';
import DatasetsTab from '../components/DatasetsTab';
import SearchTab from '../components/SearchTab';
import AgentChatTab from '../components/AgentChatTab';

// Removed Settings and Debug tabs from UI
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';
import useDatasets from '../hooks/useDatasets';
import useChat from '../hooks/useChat';
import useAuth from '../hooks/useAuth';
import { useAgent } from '../hooks/useAgent';
import '../styles/content-header.css';
import '../styles/search-fullscreen.css';
import '../styles/dashboard-main.css';
import '../styles/sidebar.css';
import '../styles/header.css';
import '../styles/datasets.css';
import '../styles/modal.css';
import '../styles/responsive.css';
import { FaPlus } from 'react-icons/fa';

const Dashboard = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState('dashboard');
  
  // Check for tab query parameter on component mount
  useEffect(() => {
    const tabParam = searchParams.get('tab');
    if (tabParam && ['dashboard', 'datasets', 'search', 'agent-chat'].includes(tabParam)) {
      setActiveTab(tabParam);
    }
  }, [searchParams]);

  // Auth/user logic
  const { username, authDebug, userInfo, handleLogout, handleTestApi, handleForceRefresh } = useAuth(navigate);
  // Dataset logic
  const {
    datasets,
    isLoading,
    showDatasetModal,
    openDatasetModal,
    closeDatasetModal,
    datasetFormData,
    handleDatasetInputChange,
    handleCreateDataset,
    requestDeleteDataset,
    handleConfirmDelete,
    handleCancelDelete,
    confirmDelete,
    datasetError,
    toast,
    loadDatasets
  } = useDatasets();
  // Chat logic
  const {
    messages,
    query,
    setQuery,
    isSearching,
    handleSearch,
    chatContainerRef,
    selectedCitation,
    handleCitationClick,
    closeCitationModal
  } = useChat();
  // Agent logic - lift state up to Dashboard level
  const {
    agents,
    selectedAgent,
    currentSession,
    isLoading: agentLoading,
    error: agentError,
    isThinking,
    startSession,
    sendMessage,
    cancelTask,
    clearSession,
    setSelectedAgent,
    setCurrentSession
  } = useAgent();

  useEffect(() => {
    if (activeTab === 'datasets') loadDatasets();
  }, [activeTab, loadDatasets]);

  // Prepare agent session data for sidebar
  const currentAgentSession = currentSession && selectedAgent ? {
    ...currentSession,
    agent: selectedAgent
  } : null;
  


  return (
    <div className="dashboard-container">
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        handleLogout={handleLogout}
        currentAgentSession={currentAgentSession}
      />
      <main className="main-content">
        <Header 
          username={username} 
          title={
            activeTab === 'agent-chat' ? 'Agent Chat' :
            activeTab === 'datasets' ? 'Datasets' :
            activeTab === 'search' ? 'Search' :
            'Welcome to Your Dashboard'
          }
        />
        <div className="content">
          {activeTab === 'dashboard' && <DashboardTab />}
          {activeTab === 'datasets' && (
            <DatasetsTab
              datasets={datasets}
              isLoading={isLoading}
              showDatasetModal={showDatasetModal}
              openDatasetModal={openDatasetModal}
              closeDatasetModal={closeDatasetModal}
              datasetFormData={datasetFormData}
              handleDatasetInputChange={handleDatasetInputChange}
              handleCreateDataset={handleCreateDataset}
              requestDeleteDataset={requestDeleteDataset}
              handleConfirmDelete={handleConfirmDelete}
              handleCancelDelete={handleCancelDelete}
              confirmDelete={confirmDelete}
              datasetError={datasetError}
              toast={toast}
            />
          )}
          {activeTab === 'search' && (
            <SearchTab
              messages={messages}
              query={query}
              setQuery={setQuery}
              isSearching={isSearching}
              handleSearch={handleSearch}
              chatContainerRef={chatContainerRef}
              selectedCitation={selectedCitation}
              handleCitationClick={handleCitationClick}
              closeCitationModal={closeCitationModal}
            />
          )}
          {activeTab === 'agent-chat' && (
            <AgentChatTab 
              agents={agents}
              selectedAgent={selectedAgent}
              currentSession={currentSession}
              isLoading={agentLoading}
              error={agentError}
              isThinking={isThinking}
              startSession={startSession}
              sendMessage={sendMessage}
              cancelTask={cancelTask}
              clearSession={clearSession}
              setSelectedAgent={setSelectedAgent}
              setCurrentSession={setCurrentSession}
            />
          )}
          {/* Settings and Debug tabs removed */}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
