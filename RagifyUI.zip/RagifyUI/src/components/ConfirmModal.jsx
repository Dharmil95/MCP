import React from 'react';

const ConfirmModal = ({ isOpen, title, message, onConfirm, onCancel, fileId }) => {
  if (!isOpen) return null;
  return (
    <div className="modal-overlay">
      <div className="modal confirm-modal">
        <h3>{title || 'Confirm Action'}</h3>
        <p>{message || 'Are you sure you want to proceed?'}</p>
        <div className="modal-actions">
          <button className="primary-btn" onClick={() => { 
            if (typeof onConfirm === 'function') { 
              onConfirm(fileId); // Pass fileId directly
            }
          }}>Yes</button>
          <button className="secondary-btn" onClick={onCancel}>Cancel</button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmModal;
