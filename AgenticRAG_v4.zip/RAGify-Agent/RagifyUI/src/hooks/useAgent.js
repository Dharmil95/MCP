import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import agentService from '../services/agentService';

export const useAgent = () => {
  const [agents, setAgents] = useState([]);
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [currentSession, setCurrentSession] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [taskId, setTaskId] = useState(null);
  const [isThinking, setIsThinking] = useState(false);
  
  // Use ref to track current session for sendMessage function
  const currentSessionRef = useRef(null);
  
  // Update ref whenever currentSession changes
  useEffect(() => {
    currentSessionRef.current = currentSession;
  }, [currentSession]);

  // Memoized agent lookup
  const getAgentById = useCallback((agentId) => {
    return agents.find(agent => agent.id === agentId);
  }, [agents]);

  // Load available agents
  const loadAgents = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const agentsData = await agentService.getAgents();
      setAgents(agentsData);
    } catch (err) {
      console.error('Error loading agents:', err);
      const errorMessage = err.response?.data?.detail || err.message || 'Failed to load agents';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Load agents on mount
  useEffect(() => {
    loadAgents();
  }, [loadAgents]);

  // Start a new session with an agent
  const startSession = useCallback(async (agentId, initialMessage = null) => {
    try {
      setIsLoading(true);
      setError(null);
      
      const sessionResponse = await agentService.startSession(agentId, initialMessage);
      const session = {
        session_id: sessionResponse.session_id,
        agent_id: agentId,
        messages: []
      };
      
      setCurrentSession(session);
      setSelectedAgent(getAgentById(agentId));
      
      return session;
    } catch (err) {
      console.error('Error starting session:', err);
      const errorMessage = err.response?.data?.detail || err.message || 'Failed to start session';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [getAgentById]);

  // Send message to agent
  const sendMessage = useCallback(async (message) => {
    if (!selectedAgent) {
      const error = new Error('No agent selected');
      setError(error.message);
      throw error;
    }

    try {
      setIsThinking(true);
      setError(null);
      
      // Get current session state from ref
      const session = currentSessionRef.current;
      if (!session) {
        const error = new Error('No session selected');
        setError(error.message);
        throw error;
      }
      
      // Start agent interaction
      const interaction = await agentService.interactWithAgent(
        selectedAgent.id, 
        message, 
        session.session_id
      );
      
      setTaskId(interaction.task_id);
      
      // Poll for results
      const result = await agentService.pollTaskStatus(interaction.task_id);
      
      // Update session with agent response only (user message already added by component)
      setCurrentSession(prev => {
        if (!prev) return prev;
        const updatedMessages = [...(prev.messages || []), {
          role: 'assistant',
          content: result.result.answer,
          timestamp: new Date().toISOString()
        }];
        return {
          ...prev,
          messages: updatedMessages
        };
      });
      
      setTaskId(null);
      return result;
    } catch (err) {
      console.error('Error sending message:', err);
      const errorMessage = err.response?.data?.detail || err.message || 'Failed to send message';
      setError(errorMessage);
      throw err;
    } finally {
      setIsThinking(false);
    }
  }, [selectedAgent]);

  // Cancel current task
  const cancelTask = useCallback(async () => {
    if (!taskId) return;
    
    try {
      await agentService.cancelTask(taskId);
      setTaskId(null);
      setIsThinking(false);
    } catch (err) {
      console.error('Error canceling task:', err);
      // Don't throw error for cancel operation
    }
  }, [taskId]);

  // Clear current session
  const clearSession = useCallback(() => {
    setCurrentSession(null);
    setSelectedAgent(null);
    setTaskId(null);
    setIsThinking(false);
    setError(null);
  }, []);

  // Memoized state for performance
  const agentState = useMemo(() => ({
    agents,
    selectedAgent,
    currentSession,
    isLoading,
    error,
    isThinking,
    taskId
  }), [agents, selectedAgent, currentSession, isLoading, error, isThinking, taskId]);

  const agentActions = useMemo(() => ({
    loadAgents,
    startSession,
    sendMessage,
    cancelTask,
    clearSession,
    setSelectedAgent,
    setCurrentSession
  }), [loadAgents, startSession, sendMessage, cancelTask, clearSession]);

  return {
    ...agentState,
    ...agentActions
  };
};
