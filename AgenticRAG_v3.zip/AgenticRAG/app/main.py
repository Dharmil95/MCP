# Standard library
import logging
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import AsyncGenerator


# Third-party
from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse


# Local imports
from app.core.config import settings
from app.db.database import init_db, check_database_health
from app.api import api_router
from app.schemas import ErrorResponse


# Configure structured logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Manage application lifespan events.

    Handles startup tasks like database initialization
    and cleanup during shutdown.
    """
    # Startup
    logger.info("Starting up RAG-as-a-Service backend...")
    try:
        db_pool = await init_db()
        app.state.db_pool = db_pool
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize database: {str(e)}")
        raise

    yield

    # Shutdown - Proper cleanup
    logger.info("Shutting down RAG-as-a-Service backend...")
    if hasattr(app.state, "db_pool"):
        await app.state.db_pool.close()
        logger.info("Database connections closed")


def validate_settings() -> None:
    """Validate required configuration settings."""
    if not settings.app_name:
        raise ValueError("app_name is required")
    if not settings.allowed_hosts:
        raise ValueError("allowed_hosts must be configured")


def create_application() -> FastAPI:
    """
    Create FastAPI application with all configurations.

    Returns:
        FastAPI: Configured application instance
    """
    # Validate configuration
    validate_settings()

    app = FastAPI(
        title=settings.app_name,
        description="A scalable RAG-as-a-Service platform built with FastAPI",
        version=settings.app_version,
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
    )

    # Add CORS middleware with specific permissions
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.allowed_hosts,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["Content-Type", "Authorization", "X-Requested-With"],
    )

    # Add custom middleware for request logging
    @app.middleware("http")
    async def log_requests(request: Request, call_next):
        start_time = time.time()

        # Structured logging for requests
        if logger.isEnabledFor(logging.INFO):
            logger.info(
                "Request received",
                extra={
                    "method": request.method,
                    "url": str(request.url),
                    "user_agent": request.headers.get("user-agent", "unknown"),
                    "client_ip": request.client.host if request.client else "unknown",
                },
            )

        # Process request
        response = await call_next(request)

        # Log response with timing
        process_time = time.time() - start_time
        logger.info(
            "Request processed",
            extra={
                "method": request.method,
                "url": str(request.url),
                "status_code": response.status_code,
                "process_time": f"{process_time:.3f}s",
            },
        )

        return response

    # Include API routes
    app.include_router(api_router, prefix="/api/v1")

    # Global exception handler for HTTP exceptions
    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException):
        logger.error(f"HTTP Exception: {exc.status_code} - {exc.detail}")

        # Sanitize error details in production
        detail = exc.detail if settings.debug else "An error occurred"

        return JSONResponse(
            status_code=exc.status_code,
            content=ErrorResponse(
                detail=detail, timestamp=datetime.now(timezone.utc).isoformat()
            ).dict(),
        )

    # Global exception handler for unexpected errors
    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception):
        logger.error(f"Unexpected error: {str(exc)}", exc_info=True)

        # Never expose internal error details in production
        detail = str(exc) if settings.debug else "Internal server error"

        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=ErrorResponse(
                detail=detail, timestamp=datetime.now(timezone.utc).isoformat()
            ).dict(),
        )

    # Enhanced health check endpoint
    @app.get("/health")
    async def health_check():
        """
        Comprehensive health check endpoint.

        Returns:
            dict: Health status with database and service information
        """
        try:
            db_status = await check_database_health()
            overall_status = "healthy" if db_status else "unhealthy"

            return {
                "status": overall_status,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "database": db_status,
                "version": settings.app_version,
                "environment": (
                    settings.environment
                    if hasattr(settings, "environment")
                    else "unknown"
                ),
            }
        except Exception as e:
            logger.error(f"Health check failed: {str(e)}")
            return {
                "status": "unhealthy",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "error": "Health check failed",
            }

    return app


# Create the application instance
app = create_application()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.debug,
        log_level="info",
        access_log=True,
    )
