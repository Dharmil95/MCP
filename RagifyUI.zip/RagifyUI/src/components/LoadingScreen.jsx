import React from 'react';
import Logo from './Logo';

const LoadingScreen = ({ 
  message = "Loading...", 
  subtitle = "Please wait while we prepare your experience",
  showProgress = false,
  progress = 0 
}) => {
  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100vw',
      height: '100vh',
      background: 'transparent',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 9999,
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    }}>
      <div style={{ marginBottom: '20px' }}>
        <Logo />
      </div>
      <h1 style={{ 
        color: '#333', 
        fontSize: '1.5rem', 
        marginBottom: '10px',
        fontWeight: '600'
      }}>
        {message}
      </h1>
      <p style={{ 
        color: '#666', 
        fontSize: '1rem',
        marginBottom: '20px'
      }}>
        {subtitle}
      </p>
      
      {/* Simple spinner */}
      <div style={{
        width: '40px',
        height: '40px',
        border: '3px solid #f3f3f3',
        borderTop: '3px solid #3b82f6',
        borderRadius: '50%',
        animation: 'spin 1s linear infinite'
      }}></div>
      
      {showProgress && (
        <div style={{ marginTop: '20px', textAlign: 'center' }}>
          <div style={{
            width: '200px',
            height: '8px',
            backgroundColor: '#f3f3f3',
            borderRadius: '4px',
            overflow: 'hidden'
          }}>
            <div style={{
              width: `${progress}%`,
              height: '100%',
              backgroundColor: '#3b82f6',
              transition: 'width 0.3s ease'
            }}></div>
          </div>
          <span style={{ 
            color: '#333', 
            fontSize: '0.875rem',
            marginTop: '8px',
            display: 'block'
          }}>
            {Math.round(progress)}%
          </span>
        </div>
      )}
      
      <style>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default LoadingScreen;
