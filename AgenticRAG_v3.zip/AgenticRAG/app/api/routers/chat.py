from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
from uuid import UUID
from app.db.database import get_async_session
from app.schemas import ChatRequest, ChatResponse
from app.services import DatasetService
from app.utils.auth import get_current_user
from app.models import User
import logging
import time
from app.services.embedding import EmbeddingService
from app.core.config import settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/chat", tags=["chat"])


@router.post("/all", response_model=ChatResponse)
async def chat_with_all_datasets(
    chat_request: ChatRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session)
):
    """
    Chat with all datasets owned by the user
    """
    try:
        start_time = time.time()
        
        # Get all ready datasets owned by the user
        datasets = await DatasetService.get_datasets_by_owner(
            db=db,
            owner_id=current_user.id
        )
        
        ready_datasets = [d for d in datasets if d.status in ["ready", "completed"]]
        if not ready_datasets:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No ready or completed datasets found for chat"
            )
        
        # 1. Search for similar chunks across all user's datasets
        embedding_service = EmbeddingService(settings.openai_api_key)
        source_documents = await embedding_service.search_chunks(
            db=db,
            query=chat_request.query,
            top_k=chat_request.top_k or 5,
            owner_id=str(current_user.id)
        )
        response_text = "\n---\n".join([doc["chunk_text"] for doc in source_documents])
        
        # 2. Generate LLM answer using retrieved chunks
        from langchain_openai import ChatOpenAI
        from langchain.schema import HumanMessage
        import os
        from dotenv import load_dotenv
        load_dotenv()
        api_key = os.getenv("OPENAI_API_KEY") or settings.openai_api_key
        if not api_key:
            raise RuntimeError("Missing OPENAI_API_KEY in .env or settings")
        chat = ChatOpenAI(
            openai_api_key=api_key,
            model_name="gpt-4o-mini",
            temperature=0
        )
        # Prepare context for LLM
        context_chunks = "\n---\n".join([doc["chunk_text"] for doc in source_documents])
        # llm_prompt = (
        #     f"Answer the following user question using only the context below. "
        #     f"Format your answer in Markdown for clarity. If the answer includes tabular data, present it as a Markdown table. "
        #     f"\n\nContext:\n{context_chunks}\n\nQuestion: {chat_request.query}"
        # )

        llm_prompt = (
            f"You are a helpful assistant that answers **only** using the context below."
            f" Format your answer in **Markdown** (React‑renderable)."
            f" If your answer includes tables, use valid Markdown table syntax."
            f"\nContext:\n{context_chunks}\nQuestion:: {chat_request.query}"
        )

        llm_response = chat.invoke([HumanMessage(content=llm_prompt)])
        llm_answer = llm_response.content if hasattr(llm_response, "content") else str(llm_response)
        processing_time = time.time() - start_time
        return ChatResponse(
            response_text=llm_answer,
            source_documents=source_documents,
            dataset_ids=[doc["dataset_object_id"] for doc in source_documents],
            processing_time=processing_time,
            llm_answer=llm_answer,
            retrieved_chunks=[doc["chunk_text"] for doc in source_documents]
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Chat with all datasets error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Chat failed"
        )


@router.post("/{dataset_id}", response_model=ChatResponse)
async def chat_with_dataset(
    dataset_id: UUID,
    chat_request: ChatRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session)
):
    """
    Chat with a selected dataset
    """
    try:
        start_time = time.time()
        
        # Verify dataset ownership
        dataset = await DatasetService.get_dataset_by_id(
            db=db,
            dataset_id=dataset_id,
            owner_id=current_user.id
        )
        
        if not dataset:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Dataset not found"
            )
        
        if dataset.status not in ["ready", "completed"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Dataset is not ready for chat. Current status: {dataset.status}"
            )
        
        # 1. Search for similar chunks using EmbeddingService
        embedding_service = EmbeddingService(settings.openai_api_key)
        source_documents = await embedding_service.search_chunks(
            db=db,
            query=chat_request.query,
            top_k=chat_request.top_k or 5,
            dataset_id=str(dataset_id)
        )
        # 2. (Optional) Generate response using LLM (here: just concatenate top chunks)
        response_text = "\n---\n".join([doc["chunk_text"] for doc in source_documents])
        processing_time = time.time() - start_time

        return ChatResponse(
            response_text=response_text,
            source_documents=source_documents,
            dataset_ids=[dataset_id],
            processing_time=processing_time
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Chat error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Chat failed"
        )
