from typing import Any, Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class AWSCredentialsValidation(BaseModel):
    """Schema for AWS credentials validation"""

    aws_access_key_id: str
    aws_secret_access_key: str
    aws_s3_bucket_name: str
    aws_s3_folder_path: str


class AWSValidationResponse(BaseModel):
    """Schema for AWS validation response"""

    status: str
    message: Optional[str] = None


class ChatRequest(BaseModel):
    """Schema for chat request"""

    query: str = Field(..., min_length=1, max_length=1000)
    top_k: Optional[int] = 5


class ChatResponse(BaseModel):
    """Schema for chat response"""

    response_text: str
    source_documents: List[Dict[str, Any]]
    dataset_ids: List[UUID]
    processing_time: float


class ErrorResponse(BaseModel):
    """Schema for error responses"""

    detail: str
    error_code: Optional[str] = None
    timestamp: str


class SuccessResponse(BaseModel):
    """Schema for success responses"""

    message: str
    data: Optional[Dict[str, Any]] = None
