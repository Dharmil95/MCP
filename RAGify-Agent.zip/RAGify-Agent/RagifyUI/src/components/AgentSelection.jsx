import React from 'react';
import { FaRobot, FaLightbulb, FaChartLine, FaSearch, FaCode, FaUsers, FaBrain, FaRocket } from 'react-icons/fa';
import LoadingSpinner from './LoadingSpinner';

const AgentSelection = ({ agents, onAgentSelect, isLoading }) => {
  // Default agent icons mapping
  const getAgentIcon = (agentName) => {
    const name = agentName.toLowerCase();
    if (name.includes('rag')) return <FaSearch />;
    if (name.includes('echo')) return <FaRobot />;
    if (name.includes('research') || name.includes('search')) return <FaSearch />;
    if (name.includes('data') || name.includes('analytics')) return <FaChartLine />;
    if (name.includes('code') || name.includes('developer')) return <FaCode />;
    if (name.includes('creative') || name.includes('content')) return <FaLightbulb />;
    if (name.includes('social') || name.includes('community')) return <FaUsers />;
    if (name.includes('ai') || name.includes('intelligence')) return <FaBrain />;
    if (name.includes('assistant') || name.includes('helper')) return <FaRobot />;
    return <FaRocket />;
  };

  // Default agent descriptions if not provided
  const getAgentDescription = (agent) => {
    if (agent.description) return agent.description;
    
    const name = agent.name?.toLowerCase() || agent.id?.toLowerCase() || '';
    if (name.includes('rag')) return 'RAG workflow: dataset discovery, query decomposition, querying, and synthesis with Langfuse tracing';
    if (name.includes('echo')) return 'Echo agent that returns the provided input and session id';
    if (name.includes('research')) return 'Research and analyze information from multiple sources';
    if (name.includes('data')) return 'Analyze data and generate insights';
    if (name.includes('code')) return 'Help with coding tasks and development';
    if (name.includes('creative')) return 'Generate creative content and ideas';
    if (name.includes('social')) return 'Manage social media and community interactions';
    if (name.includes('ai')) return 'Advanced AI-powered assistance';
    if (name.includes('assistant')) return 'General purpose AI assistant';
    return 'Specialized AI agent for your needs';
  };

  if (isLoading) {
    return (
      <div className="agent-selection-loading">
        <LoadingSpinner size="large" variant="light" />
        <p>Loading agents...</p>
      </div>
    );
  }

  return (
    <div className="agent-selection-container">
      {/* Hero Section */}
      <div className="agent-selection-hero">
        <div className="hero-content">
          <h1 className="hero-title">
            Choose Your AI Agent
          </h1>
          <p className="hero-subtitle">
            Select from our collection of specialized AI agents to help you automate tasks, 
            analyze data, and boost your productivity. Each agent is designed for specific use cases.
          </p>
          <div className="hero-stats">
            <div className="stat-item">
              <span className="stat-number">{agents.length}</span>
              <span className="stat-label">Available Agents</span>
            </div>
            <div className="stat-item">
              <span className="stat-number">24/7</span>
              <span className="stat-label">Availability</span>
            </div>
            <div className="stat-item">
              <span className="stat-number">∞</span>
              <span className="stat-label">Possibilities</span>
            </div>
          </div>
        </div>
      </div>

      {/* Agents Grid */}
      <div className="agents-grid">
        {agents.map((agent) => (
          <div 
            key={agent.id} 
            className="agent-card"
            onClick={() => onAgentSelect(agent)}
          >
            <div className="agent-card-header">
              <div className="agent-icon">
                {getAgentIcon(agent.name || agent.id)}
              </div>
              <div className="agent-status">
                <span className="status-dot"></span>
                <span className="status-text">Available</span>
              </div>
            </div>
            
            <div className="agent-card-content">
              <h3 className="agent-name">
                {agent.name || agent.id}
              </h3>
              <p className="agent-description">
                {getAgentDescription(agent)}
              </p>
            </div>

            <div className="agent-card-footer">
              <div className="agent-tags">
                {agent.tags && agent.tags.length > 0 ? (
                  agent.tags.slice(0, 3).map((tag, index) => (
                    <span key={index} className="agent-tag">{tag}</span>
                  ))
                ) : (
                  <span className="agent-tag">AI</span>
                )}
              </div>
              <div className="agent-cta">
                <span>Start Chat</span>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom CTA */}
      <div className="agent-selection-cta">
        <div className="cta-content">
          <h3>Can't find what you're looking for?</h3>
          <p>We're constantly adding new agents. Let us know what you need!</p>
          <button className="cta-button">
            Request New Agent
          </button>
        </div>
      </div>
    </div>
  );
};

export default AgentSelection;
