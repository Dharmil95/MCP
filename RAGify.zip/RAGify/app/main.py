# Standard library
import logging
import time
import sys
import json
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import AsyncGenerator, Dict, Any, Optional

# Third-party
from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pythonjsonlogger import jsonlogger

from app.api import api_router

# Local imports
from app.application.exceptions.exception_handlers import register_exception_handlers
from app.core.config import settings
from app.domain.database import check_database_health, init_db
from app.domain.schemas import ErrorResponse

# Configure JSON logging
class CustomJsonFormatter(jsonlogger.JsonFormatter):
    def add_fields(self, log_record, record, message_dict):
        super().add_fields(log_record, record, message_dict)
        
        # Add timestamp in ISO format if not present
        if not log_record.get('timestamp'):
            log_record['timestamp'] = datetime.now(timezone.utc).isoformat()
            
        # Add log level
        log_record['level'] = record.levelname
        
        # Add logger name
        log_record['logger'] = record.name
        
        # Add request_id if present in record but not in log_record
        if hasattr(record, 'request_id') and not log_record.get('request_id'):
            log_record['request_id'] = record.request_id
        
        # Add environment information
        log_record['environment'] = getattr(settings, 'environment', 'development')
        log_record['app_version'] = settings.app_version
        
        # Add thread/process ID for tracking concurrent operations
        log_record['thread'] = record.thread
        
        # Add exception info if present
        if record.exc_info:
            log_record['exception'] = {
                'type': record.exc_info[0].__name__ if record.exc_info[0] else None,
                'message': str(record.exc_info[1]) if record.exc_info[1] else None,
            }

# Setup JSON logger
handler = logging.StreamHandler(sys.stdout)
formatter = CustomJsonFormatter('%(timestamp)s %(level)s %(name)s %(message)s')
handler.setFormatter(formatter)
root_logger = logging.getLogger()
root_logger.handlers = []
root_logger.addHandler(handler)
root_logger.setLevel(logging.INFO)

# Configure specific loggers
logging.getLogger('uvicorn').setLevel(logging.INFO)
logging.getLogger('uvicorn.access').setLevel(logging.INFO)
logging.getLogger('sqlalchemy.engine').setLevel(logging.WARNING)  # Reduce SQL query logs

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Manage application lifespan events.

    Handles startup tasks like database initialization
    and cleanup during shutdown.
    """
    # Startup
    logger.info("Starting up RAG-as-a-Service backend...")
    try:
        db_pool = await init_db()
        app.state.db_pool = db_pool
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize database: {str(e)}")
        raise

    yield

    # Shutdown - Proper cleanup
    logger.info("Shutting down RAG-as-a-Service backend...")
    if hasattr(app.state, "db_pool"):
        await app.state.db_pool.close()
        logger.info("Database connections closed")


def validate_settings() -> None:
    """Validate required configuration settings."""
    if not settings.app_name:
        raise ValueError("app_name is required")
    if not settings.allowed_hosts:
        raise ValueError("allowed_hosts must be configured")


def create_application() -> FastAPI:
    """
    Create FastAPI application with all configurations.

    Returns:
        FastAPI: Configured application instance
    """
    # Validate configuration
    validate_settings()

    app = FastAPI(
        title=settings.app_name,
        description="A scalable RAG-as-a-Service platform built with FastAPI",
        version=settings.app_version,
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
    )

    # Add CORS middleware with specific permissions
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.allowed_hosts,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["Content-Type", "Authorization", "X-Requested-With"],
    )

    # Add custom middleware for request logging with JSON format
    @app.middleware("http")
    async def log_requests(request: Request, call_next):
        # Generate unique request ID
        request_id = str(uuid.uuid4())
        
        # Add request ID to request state for use in endpoints
        request.state.request_id = request_id
        
        # Start timer
        start_time = time.time()

        # Import utility for extracting request metadata
        from app.application.utils.logging_utils import get_request_metadata
        
        # Extract request metadata using utility function
        log_context = get_request_metadata(request)
        log_context["request_id"] = request_id
        
        # Try to extract user ID from token if available
        try:
            auth_header = request.headers.get("Authorization")
            if auth_header and auth_header.startswith("Bearer "):
                from jose import jwt
                
                token = auth_header.replace("Bearer ", "")
                # Verify token without exceptions
                try:
                    payload = jwt.decode(
                        token, 
                        settings.secret_key, 
                        algorithms=[settings.algorithm]
                    )
                    if payload and "sub" in payload:
                        log_context["user_id"] = payload.get("sub")
                except Exception:
                    # Don't fail if token verification fails
                    pass
        except Exception:
            # Don't fail if we can't extract user information
            pass
        
        # Log the incoming request
        logger.info("Request received", extra=log_context)

        try:
            # Process request
            response = await call_next(request)
            
            # Calculate processing time
            process_time = time.time() - start_time
            process_time_ms = round(process_time * 1000, 2)
            
            # Add response information
            response_log = {
                **log_context,
                "status_code": response.status_code,
                "process_time_ms": process_time_ms,
            }
            
            # Add any context variables that might have been set in endpoints
            # This allows endpoints to add specific context to logs
            
            # Common context variables
            if hasattr(request.state, "resource_id"):
                response_log["resource_id"] = request.state.resource_id
                
            if hasattr(request.state, "operation"):
                response_log["operation"] = request.state.operation
                
            if hasattr(request.state, "user_id") and not response_log.get("user_id"):
                response_log["user_id"] = request.state.user_id
            
            # Dataset-specific variables
            if hasattr(request.state, "dataset_name"):
                response_log["dataset_name"] = request.state.dataset_name
                
            if hasattr(request.state, "s3_path"):
                response_log["s3_path"] = request.state.s3_path
            
            # Query-specific variables
            if hasattr(request.state, "search_query"):
                response_log["search_query"] = request.state.search_query
                
            if hasattr(request.state, "query_length"):
                response_log["query_length"] = request.state.query_length
                
            if hasattr(request.state, "query_type"):
                response_log["query_type"] = request.state.query_type
                
            if hasattr(request.state, "top_k"):
                response_log["top_k"] = request.state.top_k
            
            if hasattr(request.state, "results_count"):
                response_log["results_count"] = request.state.results_count
            
            # File operations
            if hasattr(request.state, "file_name"):
                response_log["file_name"] = request.state.file_name
                
            if hasattr(request.state, "file_size"):
                response_log["file_size"] = request.state.file_size
                
            if hasattr(request.state, "content_type"):
                response_log["content_type"] = request.state.content_type
                
            if hasattr(request.state, "object_count"):
                response_log["object_count"] = request.state.object_count
            
            # Log based on status code
            if response.status_code >= 500:
                logger.error("Server error", extra=response_log)
            elif response.status_code >= 400:
                logger.warning("Client error", extra=response_log)
            else:
                logger.info("Request processed", extra=response_log)
                
            return response
            
        except Exception as e:
            # Calculate processing time
            process_time = time.time() - start_time
            process_time_ms = round(process_time * 1000, 2)
            
            # Log exception with same context
            error_log = {
                **log_context,
                "status_code": 500,
                "process_time_ms": process_time_ms,
                "error": str(e),
                "error_type": type(e).__name__,
            }
            
            logger.exception("Request failed", extra=error_log)
            raise

    # Include API routes
    app.include_router(api_router, prefix="/api/v1")

    # Register domain exception handlers
    register_exception_handlers(app)

    # Global exception handler for HTTP exceptions
    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException):
        logger.error(f"HTTP Exception: {exc.status_code} - {exc.detail}")

        # Sanitize error details in production
        detail = exc.detail if settings.debug else "An error occurred"

        return JSONResponse(
            status_code=exc.status_code,
            content=ErrorResponse(
                detail=detail, timestamp=datetime.now(timezone.utc).isoformat()
            ).dict(),
        )

    # Global exception handler for unexpected errors
    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception):
        logger.error(f"Unexpected error: {str(exc)}", exc_info=True)

        # Never expose internal error details in production
        detail = str(exc) if settings.debug else "Internal server error"

        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=ErrorResponse(
                detail=detail, timestamp=datetime.now(timezone.utc).isoformat()
            ).dict(),
        )

    # Enhanced health check endpoint
    @app.get("/health")
    async def health_check():
        """
        Comprehensive health check endpoint.

        Returns:
            dict: Health status with database and service information
        """
        try:
            db_status = await check_database_health()
            overall_status = "healthy" if db_status else "unhealthy"

            return {
                "status": overall_status,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "database": db_status,
                "version": settings.app_version,
                "environment": (
                    settings.environment
                    if hasattr(settings, "environment")
                    else "unknown"
                ),
            }
        except Exception as e:
            logger.error(f"Health check failed: {str(e)}")
            return {
                "status": "unhealthy",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "error": "Health check failed",
            }

    return app


# Create the application instance
app = create_application()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.debug,
        log_level="info",
        access_log=True,
    )
