"""User model and related operations."""

import uuid
from typing import Optional

from fastapi_permissions import Allow, Everyone
from fastapi_users.db import SQLAlchemyBaseUserTableUUID
from passlib.context import CryptContext
from sqlalchemy import Column, DateTime
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.domain.database import Base

# Password context for hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


class User(SQLAlchemyBaseUserTableUUID, Base):
    """User model extending fastapi-users base user table"""

    __tablename__ = "users"

    # Additional fields beyond fastapi-users base
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    datasets = relationship(
        "Dataset", back_populates="owner", cascade="all, delete-orphan"
    )

    def __acl__(self):
        """Access Control List for user permissions"""
        return [
            (Allow, Everyone, "view"),
            (Allow, f"user:{self.id}", "edit"),
            (Allow, f"user:{self.id}", "delete"),
        ]

    @classmethod
    async def get_by_email(cls, db: AsyncSession, email: str) -> Optional["User"]:
        """Get user by email"""
        query = select(cls).where(cls.email == email)
        result = await db.execute(query)
        return result.scalar_one_or_none()

    @classmethod
    async def get_by_id(cls, db: AsyncSession, user_id: str) -> Optional["User"]:
        """Get user by ID"""
        query = select(cls).where(cls.id == user_id)
        result = await db.execute(query)
        return result.scalar_one_or_none()

    @classmethod
    async def create(cls, db: AsyncSession, user_data) -> "User":
        """Create a new user"""
        hashed_password = pwd_context.hash(user_data.password)
        user = cls(
            email=user_data.email,
            hashed_password=hashed_password,
            is_active=True,
            is_verified=False,
            is_superuser=False,
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)
        return user

    @classmethod
    async def authenticate(
        cls, db: AsyncSession, email: str, password: str
    ) -> Optional["User"]:
        """Authenticate user with email and password"""
        user = await cls.get_by_email(db, email)
        if not user:
            return None
        if not pwd_context.verify(password, user.hashed_password):
            return None
        return user
