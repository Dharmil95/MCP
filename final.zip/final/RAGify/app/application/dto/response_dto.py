from typing import Any, Dict, Optional


from pydantic import BaseModel


class SuccessResponse(BaseModel):
    """Standard success response model."""

    message: str
    data: Optional[Dict[str, Any]] = None
