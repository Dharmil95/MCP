#!/bin/bash

echo "🧪 Testing Grafana Setup"
echo "========================"

# Check if services are running
echo "📊 Checking service status..."
docker compose ps --format "table {{.Name}}\t{{.Status}}\t{{.Ports}}"

echo ""
echo "🔍 Checking Elasticsearch..."
if curl -s http://localhost:9200/_cluster/health > /dev/null; then
    echo "✅ Elasticsearch is healthy"
    echo "   - Indices: $(curl -s http://localhost:9200/_cat/indices | wc -l) indices found"
else
    echo "❌ Elasticsearch is not responding"
fi

echo ""
echo "🔍 Checking Kibana..."
if curl -s http://localhost:5601/api/status > /dev/null; then
    echo "✅ Kibana is ready"
else
    echo "❌ Kibana is not responding"
fi

echo ""
echo "🔍 Checking Grafana..."
if curl -s http://localhost:3000/api/health > /dev/null; then
    echo "✅ Grafana is ready"
else
    echo "❌ Grafana is not responding"
fi

echo ""
echo "📈 Checking for logs in Elasticsearch..."
LOG_COUNT=$(curl -s "http://localhost:9200/filebeat-*/_count" | jq '.count' 2>/dev/null || echo "0")
echo "   - Found $LOG_COUNT log entries"

echo ""
echo "🎯 Next Steps:"
echo "1. Open Grafana: http://localhost:3000 (admin/admin)"
echo "2. Go to Dashboards → Browse → 'Application Logs Overview'"
echo "3. Or explore logs in Kibana: http://localhost:5601"
echo ""
echo "🔧 To generate test logs:"
echo "   curl http://localhost:8000/health"
echo "   docker compose logs backend" 