module.exports = {
    preset: 'ts-jest',
    testEnvironment: 'node',
    globalTeardown: './teardown.ts',
};
  