from __future__ import annotations

import os
import uuid
from typing import Annotated, Any, Dict, List, TypedDict, Optional

from langchain_openai import ChatOpenAI
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages

from app.application.utils.langfuse_obs import get_langfuse_client
from app.application.services.ragify_service import (
    discover_datasets,
    query_dataset,
    a_discover_datasets,
    a_query_dataset,
)
import asyncio
from app.core.config import settings

# Max worker threads for parallel dataset/query requests (safe default for IO-bound tasks)
MAX_QUERY_WORKERS = int(
    os.getenv("RAG_QUERY_MAX_WORKERS", str(settings.rag_query_max_workers))
)

# Agent metadata
AGENT_ID = "rag_system"
DESCRIPTION = "RAG workflow: dataset discovery, query decomposition, querying, and synthesis with Langfuse tracing"


class State(TypedDict):
    messages: Annotated[list, add_messages]
    user_query: str
    datasets: List[Dict[str, Any]]
    relevant_datasets: List[str]
    decomposed_queries: List[str]
    chat_responses: List[Dict[str, Any]]
    final_answer: str


# ------------------------------
# Core steps (delegated to `app.application.services.dataset_service`)
# ------------------------------
# discover_datasets() and query_dataset() are provided by the dataset_service
# facade so agent modules don't implement HTTP logic directly.


def identify_relevant_datasets(
    user_query: str, datasets: List[Dict[str, Any]], model: ChatOpenAI
) -> List[str]:
    dataset_info = "\n".join(
        f"- {d.get('name')}: {d.get('description')} (ID: {d.get('id')})"
        for d in datasets
    )
    prompt = (
        f'User query: "{user_query}"\n\n'
        f"Available datasets:\n{dataset_info}\n\n"
        "Return only relevant dataset IDs as a comma-separated list, or 'NONE'."
    )
    response = model.invoke(prompt).content.strip().upper()
    if response.startswith("NONE"):
        return []
    return [x.strip() for x in response.split(",") if x.strip()]


def decompose_query(user_query: str, model: ChatOpenAI) -> List[str]:
    prompt = f"Decompose into 2-4 simpler questions:\n\nQuery: {user_query}"
    response = model.invoke(prompt)
    return [
        ln.strip().strip('"').strip(",")
        for ln in response.content.split("\n")
        if ln.strip()
    ]


def synthesize_answer(
    user_query: str, chat_responses: List[Dict[str, Any]], model: ChatOpenAI
) -> str:
    if not any(r.get("source_documents") for r in chat_responses):
        prompt = (
            f'User asked: "{user_query}". No dataset results. '
            "Provide a helpful general response."
        )
        return model.invoke(prompt).content.strip()

    parts = []
    for idx, r in enumerate(chat_responses):
        if r.get("response_text"):
            parts.append(f"Response {idx+1}: {r['response_text']}")
        if r.get("source_documents"):
            parts.append(f"Source docs {idx+1}: {len(r['source_documents'])} chunks")

    prompt = (
        f'User Question: "{user_query}"\n\n'
        f"Retrieved Information:\n"
        + "\n".join(parts)
        + "\n\nProvide a comprehensive, direct answer."
    )
    return model.invoke(prompt).content.strip()


# ------------------------------
# Node factories
# ------------------------------
def node_discover(api_base, auth_header):
    def _inner(state: State):
        # prefer async discover for better networking performance
        # run the async discover helper directly; environments invoking
        # agents should support running an event loop via asyncio.run
        datasets = asyncio.run(a_discover_datasets(api_base, auth_header))
        return {"datasets": datasets}

    return _inner


def node_identify(llm):
    def _inner(state: State):
        if not state["datasets"]:
            return {"relevant_datasets": []}
        return {
            "relevant_datasets": identify_relevant_datasets(
                state["user_query"], state["datasets"], llm
            )
        }

    return _inner


def node_decompose(llm):
    def _inner(state: State):
        return {"decomposed_queries": decompose_query(state["user_query"], llm)}

    return _inner


def has_no_datasets(state: State) -> str:
    """Graph conditional: go to `no_datasets_available` when there are no datasets,
    otherwise proceed to identification."""
    return "no_datasets_available" if not state.get("datasets") else "identify_datasets"


def has_no_relevant_datasets(state: State) -> str:
    """Graph conditional: go to `no_datasets_found` when no relevant datasets found,
    otherwise proceed to decomposition."""
    return (
        "no_datasets_found" if not state.get("relevant_datasets") else "decompose_query"
    )


def node_query(api_base, auth_header):
    def _inner(state: State):
        responses: List[Dict[str, Any]] = []

        # Build list of (dataset_id, query) work items. Limit queries per dataset
        work_items: List[tuple] = []
        max_q_per_ds = settings.rag_max_q_per_ds
        for ds in state.get("relevant_datasets", []):
            for q in state.get("decomposed_queries", [])[:max_q_per_ds]:
                work_items.append((ds, q))

        if not work_items:
            return {"chat_responses": responses}

        async def _gather_all():
            sem = asyncio.Semaphore(MAX_QUERY_WORKERS)

            async def _call(ds, q):
                async with sem:
                    try:
                        return await a_query_dataset(api_base, auth_header, ds, q)
                    except Exception:
                        return {"error": "exception"}

            tasks = [asyncio.create_task(_call(ds, q)) for (ds, q) in work_items]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            return results

        # Use asyncio.run to execute the concurrent HTTP queries. Caller
        # environments are expected to allow asyncio.run; we no longer
        # fall back to a threaded sync implementation.
        results = asyncio.run(_gather_all())

        for r in results:
            if isinstance(r, dict) and "error" not in r:
                responses.append(r)

        return {"chat_responses": responses}

    return _inner


def node_synthesize(llm):
    def _inner(state: State):
        return {
            "final_answer": synthesize_answer(
                state["user_query"], state.get("chat_responses", []), llm
            )
        }

    return _inner


def node_no_datasets_available():
    def _inner(state: State):
        return {
            "final_answer": (
                f"I'm sorry, I cannot answer your question: '{state['user_query']}'. "
                "No datasets are currently available to search from."
            ),
            "messages": [],
        }

    return _inner


def node_no_datasets_found():
    def _inner(state: State):
        return {
            "final_answer": (
                f"I'm sorry, I cannot answer your question: '{state['user_query']}'. "
                "I don't have any relevant datasets related to your query."
            ),
            "messages": [],
        }

    return _inner


# ------------------------------
# Main entry point
# ------------------------------
def invoke(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Entry point. Expects keys: session_id, input/query/message, auth_header.

    Heavy runtime initialization (LLM clients, langfuse handlers) is performed here
    so imports stay safe during package discovery.
    """
    try:
        api_base = os.getenv("API_BASE_URL", settings.api_base_url)
        auth_header = payload.get("auth_header")
        user_query = str(
            payload.get("query") or payload.get("input") or payload.get("message") or ""
        ).strip()
        if not user_query:
            return {"error": "Missing input/query"}

        # Init LLM (deferred to runtime to avoid import-time side effects)
        api_key = settings.openai_api_key or os.getenv("OPENAI_API_KEY")
        if not api_key:
            return {"error": "OpenAI API key not configured"}

        llm = ChatOpenAI(
            model=settings.llm_model,
            temperature=settings.llm_temperature,
            openai_api_key=api_key,
            timeout=settings.llm_timeout,
        )

        # Langfuse setup (deferred)
        langfuse_client = get_langfuse_client()
        langfuse_handler = None
        if langfuse_client:
            try:
                from langfuse.langchain import CallbackHandler

                langfuse_handler = CallbackHandler()
            except Exception:
                langfuse_handler = None

        # Define graph
        gb = StateGraph(State)

        gb.add_node("discover_datasets", node_discover(api_base, auth_header))
        gb.add_node("identify_datasets", node_identify(llm))
        gb.add_node("decompose_query", node_decompose(llm))
        gb.add_node("query_datasets", node_query(api_base, auth_header))
        gb.add_node("synthesize_answer", node_synthesize(llm))
        gb.add_node("no_datasets_available", node_no_datasets_available())
        gb.add_node("no_datasets_found", node_no_datasets_found())

        # Edges
        gb.set_entry_point("discover_datasets")

        gb.add_conditional_edges(
            "discover_datasets",
            has_no_datasets,
        )

        gb.add_conditional_edges(
            "identify_datasets",
            has_no_relevant_datasets,
        )

        gb.add_edge("decompose_query", "query_datasets")
        gb.add_edge("query_datasets", "synthesize_answer")
        gb.add_edge("synthesize_answer", END)
        gb.add_edge("no_datasets_available", END)
        gb.add_edge("no_datasets_found", END)

        graph = gb.compile()

        # Run graph
        response = graph.invoke(
            {
                "user_query": user_query,
                "datasets": [],
                "relevant_datasets": [],
                "decomposed_queries": [],
                "chat_responses": [],
                "final_answer": "",
                "messages": [],
            },
            config={"callbacks": [langfuse_handler]} if langfuse_handler else {},
        )

        return {"agent": AGENT_ID, "answer": response.get("final_answer", "")}

    except Exception as e:
        return {"error": f"RAG agent failed: {str(e)}"}


def register() -> Dict[str, Any]:
    """Return minimal metadata for the agents registry.

    Keep heavy runtime work inside `invoke()` so importing this module never fails
    during package discovery.
    """
    return {"id": AGENT_ID, "description": DESCRIPTION, "invoke": invoke}
