from pydantic import BaseModel, Field, validator
from typing import List, Dict, Any, Optional
from datetime import datetime
from uuid import UUID


class DatasetCreate(BaseModel):
    """Schema for dataset creation"""
    name: str = Field(..., min_length=3, max_length=255)
    description: Optional[str] = Field(None, max_length=1000)
    embedding_model: str
    chunking_strategy: str
    chunking_parameters: Dict[str, Any]
    allowed_file_types: List[str]
    aws_s3_folder_path: str
    aws_access_key_id: str = Field(..., description="Ephemeral AWS Access Key")
    aws_secret_access_key: str = Field(..., description="Ephemeral AWS Secret Key")
    
    @validator('embedding_model')
    def validate_embedding_model(cls, v):
        from app.core.config import settings
        if v not in settings.supported_embedding_models:
            raise ValueError(f'Embedding model must be one of: {settings.supported_embedding_models}')
        return v
    
    @validator('chunking_strategy')
    def validate_chunking_strategy(cls, v):
        from app.core.config import settings
        if v not in settings.supported_chunking_strategies:
            raise ValueError(f'Chunking strategy must be one of: {settings.supported_chunking_strategies}')
        return v
    
    @validator('allowed_file_types')
    def validate_file_types(cls, v):
        from app.core.config import settings
        invalid_types = [ft for ft in v if ft not in settings.supported_file_types]
        if invalid_types:
            raise ValueError(f'Invalid file types: {invalid_types}. Supported: {settings.supported_file_types}')
        return v
    
    @validator('aws_s3_folder_path')
    def validate_s3_path(cls, v):
        if not v.startswith('s3://'):
            raise ValueError('S3 path must start with s3://')
        return v


class DatasetUpdate(BaseModel):
    """Schema for dataset updates"""
    name: Optional[str] = Field(None, min_length=3, max_length=255)
    description: Optional[str] = Field(None, max_length=1000)
    embedding_model: Optional[str] = None
    chunking_strategy: Optional[str] = None
    chunking_parameters: Optional[Dict[str, Any]] = None
    allowed_file_types: Optional[List[str]] = None
    aws_s3_folder_path: Optional[str] = None
    
    @validator('embedding_model')
    def validate_embedding_model(cls, v):
        if v is not None:
            from app.core.config import settings
            if v not in settings.supported_embedding_models:
                raise ValueError(f'Embedding model must be one of: {settings.supported_embedding_models}')
        return v
    
    @validator('chunking_strategy')
    def validate_chunking_strategy(cls, v):
        if v is not None:
            from app.core.config import settings
            if v not in settings.supported_chunking_strategies:
                raise ValueError(f'Chunking strategy must be one of: {settings.supported_chunking_strategies}')
        return v


class DatasetRead(BaseModel):
    """Schema for dataset response data"""
    id: UUID
    owner_id: UUID
    name: str
    description: Optional[str]
    embedding_model: str
    chunking_strategy: str
    chunking_parameters: Dict[str, Any]
    allowed_file_types: List[str]
    aws_s3_folder_path: str
    status: str
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class DatasetObjectRead(BaseModel):
    """Schema for dataset object response data"""
    id: UUID
    dataset_id: UUID
    file_name: str
    original_s3_path: str
    processed_s3_path: Optional[str]
    pgvector_collection_name: str
    status: str
    last_processed_at: Optional[datetime]
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class DatasetStatus(BaseModel):
    """Schema for dataset status response"""
    dataset_id: UUID
    status: str
    total_files: int
    processed_files: int
    failed_files: int
    last_updated: datetime
