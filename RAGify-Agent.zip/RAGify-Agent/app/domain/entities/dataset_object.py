"""Dataset object domain entity."""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional
from uuid import UUID


@dataclass
class DatasetObject:
    """Dataset object domain entity representing individual files within a dataset."""

    id: UUID
    dataset_id: UUID
    file_name: str
    original_s3_path: str
    processed_s3_path: Optional[str]
    pgvector_collection_name: str
    status: str
    last_processed_at: Optional[datetime]
    created_at: datetime
    updated_at: datetime
    error_message: Optional[str]

    def __post_init__(self):
        """Validate dataset object data after initialization."""
        if not self.file_name.strip():
            raise ValueError("File name cannot be empty")

        if not self.original_s3_path.strip():
            raise ValueError("Original S3 path cannot be empty")

        if not self.pgvector_collection_name.strip():
            raise ValueError("PGVector collection name cannot be empty")

        valid_statuses = ["pending", "processing", "completed", "failed"]
        if self.status not in valid_statuses:
            raise ValueError(f"Invalid status. Must be one of: {valid_statuses}")

    def is_processed(self) -> bool:
        """Check if the dataset object has been processed."""
        return self.status == "completed"

    def is_processing(self) -> bool:
        """Check if the dataset object is currently being processed."""
        return self.status == "processing"

    def has_failed(self) -> bool:
        """Check if the dataset object processing has failed."""
        return self.status == "failed"

    def can_be_processed(self) -> bool:
        """Check if the dataset object can be processed."""
        return self.status in ["pending", "failed"]

    def mark_as_processing(self):
        """Mark the dataset object as being processed."""
        self.status = "processing"
        self.error_message = None

    def mark_as_completed(self, processed_s3_path: str):
        """Mark the dataset object as completed."""
        self.status = "completed"
        self.processed_s3_path = processed_s3_path
        self.last_processed_at = datetime.utcnow()
        self.error_message = None

    def mark_as_failed(self, error_message: str):
        """Mark the dataset object as failed."""
        self.status = "failed"
        self.error_message = error_message
