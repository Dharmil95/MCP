"""Core dependencies for dependency injection."""

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession

from app.application.facades.aws_facade import AWSS3Facade
from app.application.facades.dataset_facade import DatasetFacade
from app.application.facades.embedding_facade import EmbeddingFacade
from app.application.services.aws_service import AWSService
from app.application.services.dataset_service import DatasetService
from app.application.services.document_processor import DocumentProcessor
from app.application.services.embedding_service import EmbeddingService
from app.core.config import settings
from app.domain.database import get_async_session as get_db_session
from app.domain.models import User
from app.application.utils.auth_utils import get_current_user as auth_get_current_user


# Security
security = HTTPBearer()


# Database Dependencies
async def get_async_session() -> AsyncSession:
    """Get database session dependency."""
    async for session in get_db_session():
        yield session


# Authentication Dependencies
async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_async_session),
) -> User:
    """Get current authenticated user."""
    # Extract the token from credentials and pass it to auth function
    return await auth_get_current_user(credentials.credentials, db)


# Facade Dependencies
async def get_aws_facade() -> AWSS3Facade:
    """Get AWS S3 facade dependency."""
    return AWSS3Facade()


async def get_embedding_facade() -> EmbeddingFacade:
    """Get embedding facade dependency."""
    return EmbeddingFacade(api_key=settings.openai_api_key)


async def get_dataset_facade(
    db: AsyncSession = Depends(get_async_session),
    aws_facade: AWSS3Facade = Depends(get_aws_facade),
) -> DatasetFacade:
    """Get dataset facade dependency."""
    dataset_service = DatasetService()
    document_processor = DocumentProcessor(None, {})  # These will be set per operation
    return DatasetFacade(
        dataset_service=dataset_service,
        document_processor=document_processor,
        aws_facade=aws_facade,
        db_session=db,
    )


# Service Dependencies
async def get_aws_service() -> AWSService:
    """Get AWS service dependency."""
    return AWSService()


async def get_dataset_service() -> DatasetService:
    """Get dataset service dependency."""
    return DatasetService()


async def get_embedding_service() -> EmbeddingService:
    """Get embedding service dependency."""
    return EmbeddingService(api_key=settings.openai_api_key)


# Health Check Dependencies
async def get_health_check() -> dict:
    """Get health check dependency."""
    return {"status": "healthy", "timestamp": "2025-01-01T00:00:00Z"}
