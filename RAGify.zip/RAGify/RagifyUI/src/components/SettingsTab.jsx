import React from 'react';

const SettingsTab = ({ username }) => (
  <div className="settings-content">
    <h2>Account Settings</h2>
    <div className="settings-form">
      <div className="form-group">
        <label>Username</label>
        <input type="text" value={username} readOnly />
      </div>
      <div className="form-group">
        <label>Email</label>
        <input type="email" placeholder="user@example.com" />
      </div>
      <button className="primary-btn">Save Changes</button>
    </div>
  </div>
);

export default SettingsTab;
