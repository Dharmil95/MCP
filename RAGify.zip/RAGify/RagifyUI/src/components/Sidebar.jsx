import React from 'react';
import { FaChartBar, FaDatabase, FaSearch, FaCog, FaSignOutAlt } from 'react-icons/fa';

const Sidebar = ({ activeTab, setActiveTab, handleLogout }) => (
  <nav className="sidebar">
    <div className="sidebar-header">
      <h2>RAGify</h2>
    </div>
    <ul className="nav-links">
      <li className={`nav-item ${activeTab === 'dashboard' ? 'active' : ''}`} onClick={() => setActiveTab('dashboard')}><span className="icon"><FaChartBar /></span>Dashboard</li>
      <li className={`nav-item ${activeTab === 'datasets' ? 'active' : ''}`} onClick={() => setActiveTab('datasets')}><span className="icon"><FaDatabase /></span>Datasets</li>
      <li className={`nav-item ${activeTab === 'search' ? 'active' : ''}`} onClick={() => setActiveTab('search')}><span className="icon"><FaSearch /></span>Search</li>
      <li className={`nav-item ${activeTab === 'settings' ? 'active' : ''}`} onClick={() => setActiveTab('settings')}><span className="icon"><FaCog /></span>Settings</li>
      <li className={`nav-item ${activeTab === 'debug' ? 'active' : ''}`} onClick={() => setActiveTab('debug')}><span className="icon"><FaCog /></span>Debug</li>
    </ul>
    <div className="sidebar-footer">
      <button className="logout-btn" onClick={handleLogout}><span className="icon"><FaSignOutAlt /></span>Logout</button>
    </div>
  </nav>
);

export default Sidebar;
