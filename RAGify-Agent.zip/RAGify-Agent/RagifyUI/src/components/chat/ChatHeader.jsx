import React from 'react';
import PropTypes from 'prop-types';
import { FaExpand, FaCompress, FaRobot, FaSearch } from 'react-icons/fa';
import Button from '../common/Button';
import './ChatHeader.css';

const ChatHeader = ({
  title,
  icon: Icon = FaRobot,
  status = 'online',
  isThinking = false,
  onToggleFullscreen,
  onNewChat,
  isFullscreen = false,
  showNewChatButton = true,
  className = ''
}) => {
  const getStatusColor = () => {
    if (isThinking) return '#f59e0b';
    if (status === 'online') return '#10b981';
    return '#6b7280';
  };

  const getStatusText = () => {
    if (isThinking) return 'Thinking...';
    if (status === 'online') return 'Ready';
    return status;
  };

  return (
    <div className={`chat-header ${className}`}>
      <div className="chat-header__info">
        <div className="chat-header__icon">
          <Icon />
        </div>
        <div className="chat-header__content">
          <h3 className="chat-header__title">{title}</h3>
          <div className="chat-header__status">
            <div 
              className="chat-header__status-indicator"
              style={{ background: getStatusColor() }}
            />
            <span className="chat-header__status-text">{getStatusText()}</span>
          </div>
        </div>
      </div>
      
      <div className="chat-header__actions">
        <Button
          variant="outline"
          size="small"
          onClick={onToggleFullscreen}
          icon={isFullscreen ? FaCompress : FaExpand}
        >
          {isFullscreen ? 'Exit Full Screen' : 'Full Screen'}
        </Button>
        
        {showNewChatButton && (
          <Button
            variant="outline"
            size="small"
            onClick={onNewChat}
            icon={FaRobot}
          >
            New Chat
          </Button>
        )}
      </div>
    </div>
  );
};

ChatHeader.propTypes = {
  title: PropTypes.string.isRequired,
  icon: PropTypes.elementType,
  status: PropTypes.oneOf(['online', 'offline', 'thinking']),
  isThinking: PropTypes.bool,
  onToggleFullscreen: PropTypes.func.isRequired,
  onNewChat: PropTypes.func,
  isFullscreen: PropTypes.bool,
  showNewChatButton: PropTypes.bool,
  className: PropTypes.string
};

export default ChatHeader;
