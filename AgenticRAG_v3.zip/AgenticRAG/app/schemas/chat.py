from typing import List, Optional
from pydantic import BaseModel
from uuid import UUID

class ChatRequest(BaseModel):
    query: str
    top_k: Optional[int] = 5

class SourceDocument(BaseModel):
    dataset_object_id: str
    file_name: str
    chunk_text: str
    similarity_score: float

class ChatResponse(BaseModel):
    response_text: str
    source_documents: List[SourceDocument]
    dataset_ids: List[UUID]
    processing_time: float
