import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardTab from '../components/DashboardTab';
import DatasetsTab from '../components/DatasetsTab';
import SearchTab from '../components/SearchTab';
import SettingsTab from '../components/SettingsTab';
import DebugTab from '../components/DebugTab';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';
import useDatasets from '../hooks/useDatasets';
import useChat from '../hooks/useChat';
import useAuth from '../hooks/useAuth';
import '../styles/content-header.css';
// import '../styles/search-chat.css';
import '../styles/search-fullscreen.css';
// import '../styles/search-input.css';
// import '../styles/search-citations.css';
import '../styles/dashboard-main.css';
import '../styles/sidebar.css';
import '../styles/header.css';
import '../styles/datasets.css';
import '../styles/settings.css';
import '../styles/modal.css';
import '../styles/buttons.css';
import '../styles/responsive.css';

const Dashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('dashboard');
  // Auth/user logic
  const { username, authDebug, userInfo, handleLogout, handleTestApi, handleForceRefresh } = useAuth(navigate);
  // Dataset logic
  const {
    datasets,
    isLoading,
    showDatasetModal,
    openDatasetModal,
    closeDatasetModal,
    datasetFormData,
    handleDatasetInputChange,
    handleCreateDataset,
    requestDeleteDataset,
    handleConfirmDelete,
    handleCancelDelete,
    confirmDelete,
    datasetError,
    fetchDatasets
  } = useDatasets();
  // Chat logic
  const {
    messages,
    query,
    setQuery,
    isSearching,
    handleSearch,
    chatContainerRef,
    selectedCitation,
    handleCitationClick,
    closeCitationModal
  } = useChat();

  useEffect(() => {
    if (activeTab === 'datasets') fetchDatasets();
  }, [activeTab]);

  return (
    <div className="dashboard-container">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} handleLogout={handleLogout} />
      <main className="main-content">
        <Header username={username} />
        <div className="content">
          {activeTab === 'dashboard' && <DashboardTab />}
          {activeTab === 'datasets' && (
            <DatasetsTab
              datasets={datasets}
              isLoading={isLoading}
              showDatasetModal={showDatasetModal}
              openDatasetModal={openDatasetModal}
              closeDatasetModal={closeDatasetModal}
              datasetFormData={datasetFormData}
              handleDatasetInputChange={handleDatasetInputChange}
              handleCreateDataset={handleCreateDataset}
              requestDeleteDataset={requestDeleteDataset}
              handleConfirmDelete={handleConfirmDelete}
              handleCancelDelete={handleCancelDelete}
              confirmDelete={confirmDelete}
              datasetError={datasetError}
            />
          )}
          {activeTab === 'search' && (
            <SearchTab
              messages={messages}
              query={query}
              setQuery={setQuery}
              isSearching={isSearching}
              handleSearch={handleSearch}
              chatContainerRef={chatContainerRef}
              selectedCitation={selectedCitation}
              handleCitationClick={handleCitationClick}
              closeCitationModal={closeCitationModal}
            />
          )}
          {activeTab === 'settings' && <SettingsTab username={username} />}
          {activeTab === 'debug' && (
            <DebugTab
              authDebug={authDebug}
              userInfo={userInfo}
              handleTestApi={handleTestApi}
              handleForceRefresh={handleForceRefresh}
            />
          )}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
