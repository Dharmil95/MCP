#!/bin/bash

# Setup script for RAG-as-a-Service backend

echo "Setting up RAG-as-a-Service backend..."

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Copy environment file
cp .env.example .env

echo "Setup complete!"
echo ""
echo "Next steps:"
echo "1. Activate virtual environment: source venv/bin/activate"
echo "2. Update .env file with your configurations"
echo "3. Initialize database: alembic upgrade head"
echo "4. Run development server: python run_dev.py"
