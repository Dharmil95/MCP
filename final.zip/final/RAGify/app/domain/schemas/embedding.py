"""Embedding-related Pydantic schemas."""

from typing import Any, Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class EmbeddingSearchRequest(BaseModel):
    """Request model for embedding search operations."""

    query: str = Field(..., min_length=1, description="Search query text")
    top_k: int = Field(
        default=5, ge=1, le=50, description="Number of results to return"
    )
    dataset_ids: Optional[List[UUID]] = Field(
        default=None, description="Specific dataset IDs to search in"
    )
    similarity_threshold: float = Field(
        default=0.7, ge=0.0, le=1.0, description="Minimum similarity score"
    )


class EmbeddingSearchResult(BaseModel):
    """Result model for individual embedding search results."""

    chunk_text: str = Field(..., description="The text chunk content")
    similarity_score: float = Field(..., description="Cosine similarity score")
    chunk_index: int = Field(..., description="Index of chunk within document")
    file_name: str = Field(..., description="Original file name")
    dataset_object_id: UUID = Field(..., description="Dataset object ID")
    metadata: Optional[Dict[str, Any]] = Field(
        default=None, description="Additional chunk metadata"
    )


class EmbeddingSearchResponse(BaseModel):
    """Response model for embedding search operations."""

    query: str = Field(..., description="Original search query")
    results: List[EmbeddingSearchResult] = Field(
        default_factory=list, description="Search results"
    )
    total_results: int = Field(..., description="Total number of results found")
    processing_time: float = Field(..., description="Search processing time in seconds")


class EmbeddingConfig(BaseModel):
    """Configuration model for embedding operations."""

    model_name: str = Field(..., description="Embedding model name")
    dimension: int = Field(default=1536, ge=1, description="Embedding vector dimension")
    provider: str = Field(default="openai", description="Embedding provider")
    chunk_size: int = Field(default=1000, ge=100, description="Text chunk size")
    chunk_overlap: int = Field(default=200, ge=0, description="Chunk overlap size")

    class Config:
        schema_extra = {
            "example": {
                "model_name": "text-embedding-ada-002",
                "dimension": 1536,
                "provider": "openai",
                "chunk_size": 1000,
                "chunk_overlap": 200,
            }
        }


class ChunkMetadata(BaseModel):
    """Metadata associated with a text chunk."""

    page_number: Optional[int] = Field(
        default=None, description="Page number in document"
    )
    section_title: Optional[str] = Field(
        default=None, description="Section or chapter title"
    )
    document_type: Optional[str] = Field(default=None, description="Type of document")
    language: Optional[str] = Field(default=None, description="Document language")
    tags: Optional[List[str]] = Field(
        default_factory=list, description="Associated tags"
    )

    class Config:
        schema_extra = {
            "example": {
                "page_number": 1,
                "section_title": "Introduction",
                "document_type": "pdf",
                "language": "en",
                "tags": ["important", "summary"],
            }
        }


class EmbeddingVector(BaseModel):
    """Model representing an embedding vector."""

    id: UUID = Field(..., description="Unique identifier")
    dataset_object_id: UUID = Field(..., description="Associated dataset object ID")
    chunk_text: str = Field(..., description="Text content of the chunk")
    chunk_index: int = Field(..., ge=0, description="Index within the document")
    embedding: List[float] = Field(..., description="Embedding vector")
    metadata: Optional[ChunkMetadata] = Field(
        default=None, description="Chunk metadata"
    )
    created_at: str = Field(..., description="Creation timestamp")

    class Config:
        schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "dataset_object_id": "987fcdeb-51d2-43a1-9876-543210987654",
                "chunk_text": "This is a sample text chunk for embedding.",
                "chunk_index": 0,
                "embedding": [0.1, 0.2, 0.3],  # Truncated for example
                "metadata": {
                    "page_number": 1,
                    "section_title": "Introduction",
                },
                "created_at": "2025-08-25T10:30:00Z",
            }
        }
