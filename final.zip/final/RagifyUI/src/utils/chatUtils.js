/**
 * Format timestamp for chat messages
 * @param {string} timestamp - ISO timestamp string
 * @returns {string} Formatted time string
 */
export const formatTimestamp = (timestamp) => {
  return new Date(timestamp).toLocaleTimeString([], { 
    hour: '2-digit', 
    minute: '2-digit' 
  });
};

/**
 * Create a new user message object
 * @param {string} content - Message content
 * @returns {Object} User message object
 */
export const createUserMessage = (content) => ({
  role: 'user',
  content: content.trim(),
  timestamp: new Date().toISOString()
});

/**
 * Create a new assistant message object
 * @param {string} content - Message content
 * @returns {Object} Assistant message object
 */
export const createAssistantMessage = (content) => ({
  role: 'assistant',
  content,
  timestamp: new Date().toISOString()
});

/**
 * Add a message to the session
 * @param {Object} session - Current session
 * @param {Object} message - Message to add
 * @returns {Object} Updated session
 */
export const addMessageToSession = (session, message) => {
  if (!session) return null;
  
  return {
    ...session,
    messages: [...(session.messages || []), message]
  };
};

/**
 * Check if a message is from user
 * @param {Object} message - Message object
 * @returns {boolean} True if message is from user
 */
export const isUserMessage = (message) => message.role === 'user';

/**
 * Check if a message is from assistant
 * @param {Object} message - Message object
 * @returns {boolean} True if message is from assistant
 */
export const isAssistantMessage = (message) => message.role === 'assistant';

/**
 * Get the last message from the session
 * @param {Object} session - Session object
 * @returns {Object|null} Last message or null
 */
export const getLastMessage = (session) => {
  if (!session?.messages?.length) return null;
  return session.messages[session.messages.length - 1];
};

/**
 * Check if session has messages
 * @param {Object} session - Session object
 * @returns {boolean} True if session has messages
 */
export const hasMessages = (session) => {
  return session?.messages?.length > 0;
};

/**
 * Get message count for session
 * @param {Object} session - Session object
 * @returns {number} Number of messages
 */
export const getMessageCount = (session) => {
  return session?.messages?.length || 0;
};
