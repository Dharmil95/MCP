import React from 'react';
import { FaChartBar, FaDatabase, FaSearch, FaSignOutAlt, FaRobot, FaChevronDown, FaChevronUp, FaUser, FaComments, FaPaperPlane, FaChevronRight } from 'react-icons/fa';

const Sidebar = ({ activeTab, setActiveTab, handleLogout, currentAgentSession }) => {

  return (
    <nav className="sidebar">
      <div className="sidebar-header">
        <h2>RAGify</h2>
      </div>
      <ul className="nav-links">
        <li className={`nav-item ${activeTab === 'dashboard' ? 'active' : ''}`} onClick={() => setActiveTab('dashboard')}><span className="icon"><FaChartBar /></span>Dashboard</li>
        <li className={`nav-item ${activeTab === 'datasets' ? 'active' : ''}`} onClick={() => setActiveTab('datasets')}><span className="icon"><FaDatabase /></span>Datasets</li>
        <li className={`nav-item ${activeTab === 'search' ? 'active' : ''}`} onClick={() => setActiveTab('search')}><span className="icon"><FaSearch /></span>Search</li>
        <li className={`nav-item ${activeTab === 'agent-chat' ? 'active' : ''}`} onClick={() => setActiveTab('agent-chat')}><span className="icon"><FaRobot /></span>Agent Chat</li>
      </ul>
      
      {/* Active Chat Preview */}
      {currentAgentSession && (
        <div className="sidebar-chat-preview">
          <div 
            className="chat-preview-header"
            onClick={() => setActiveTab('agent-chat')}
          >
            <div className="chat-preview-title">
              <FaRobot />
              <span>{currentAgentSession.agent?.name || currentAgentSession.agent?.id}</span>
            </div>
            <span className="chat-preview-toggle">
              <FaChevronRight />
            </span>
          </div>
        </div>
      )}
      
      <div className="sidebar-footer">
        <button className="logout-btn" onClick={handleLogout}><span className="icon"><FaSignOutAlt /></span>Logout</button>
      </div>
    </nav>
  );
};

export default Sidebar;
