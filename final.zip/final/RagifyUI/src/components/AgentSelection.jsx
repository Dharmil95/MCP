import React, { useState, useEffect } from 'react';
import { FaUserTie, FaLightbulb, FaChartLine, FaSearch, FaCode, FaUsers, FaBrain, FaRocket, FaArrowRight, FaPlus } from 'react-icons/fa';
import LoadingSpinner from './LoadingSpinner';

const AgentSelection = ({ agents, onAgentSelect, isLoading }) => {
  const [hoveredAgent, setHoveredAgent] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [containerHeight, setContainerHeight] = useState('100vh');
  const [carouselIndex, setCarouselIndex] = useState(0);
  const [touchStart, setTouchStart] = useState(null);
  const [touchEnd, setTouchEnd] = useState(null);

  // Calculate available height for the component
  useEffect(() => {
    const calculateHeight = () => {
      const viewportHeight = window.innerHeight;
      const headerHeight = 64; // Dashboard header height
      const margins = 16; // Reduced top/bottom margins since we removed container margins
      const padding = 24; // Reduced component padding
      
      // Ensure minimum height for very small screens
      const availableHeight = Math.max(viewportHeight - headerHeight - margins - padding, 400);
      setContainerHeight(`${availableHeight}px`);
    };

    calculateHeight();
    window.addEventListener('resize', calculateHeight);
    
    return () => window.removeEventListener('resize', calculateHeight);
  }, []);

  // Default agent icons mapping
  const getAgentIcon = (agentName) => {
    const name = agentName.toLowerCase();
    if (name.includes('rag')) return <FaSearch />;
    if (name.includes('echo')) return <FaUserTie />;
    if (name.includes('research') || name.includes('search')) return <FaSearch />;
    if (name.includes('data') || name.includes('analytics')) return <FaChartLine />;
    if (name.includes('code') || name.includes('developer')) return <FaCode />;
    if (name.includes('creative') || name.includes('content')) return <FaLightbulb />;
    if (name.includes('social') || name.includes('community')) return <FaUsers />;
    if (name.includes('ai') || name.includes('intelligence')) return <FaBrain />;
    if (name.includes('assistant') || name.includes('helper')) return <FaUserTie />;
    return <FaRocket />;
  };

  // Default agent descriptions if not provided
  const getAgentDescription = (agent) => {
    if (agent.description) return agent.description;
    
    const name = agent.name?.toLowerCase() || agent.id?.toLowerCase() || '';
    if (name.includes('rag')) return 'RAG workflow: dataset discovery, query decomposition, querying, and synthesis with Langfuse tracing';
    if (name.includes('echo')) return 'Echo agent that returns the provided input and session id';
    if (name.includes('research')) return 'Research and analyze information from multiple sources';
    if (name.includes('data')) return 'Analyze data and generate insights';
    if (name.includes('code')) return 'Help with coding tasks and development';
    if (name.includes('creative')) return 'Generate creative content and ideas';
    if (name.includes('social')) return 'Manage social media and community interactions';
    if (name.includes('ai')) return 'Advanced AI-powered assistance';
    if (name.includes('assistant')) return 'General purpose AI assistant';
    return 'Specialized AI agent for your needs';
  };

  const getAgentCategory = (agent) => {
    const name = agent.name?.toLowerCase() || agent.id?.toLowerCase() || '';
    if (name.includes('rag') || name.includes('search')) return 'search';
    if (name.includes('data') || name.includes('analytics')) return 'analytics';
    if (name.includes('code') || name.includes('developer')) return 'development';
    if (name.includes('creative') || name.includes('content')) return 'creative';
    if (name.includes('social') || name.includes('community')) return 'social';
    return 'general';
  };

  const categories = [
    { id: 'all', name: 'All Agents', icon: <FaRocket />, count: agents.length },
    { id: 'search', name: 'Search & RAG', icon: <FaSearch />, count: agents.filter(a => getAgentCategory(a) === 'search').length },
    { id: 'analytics', name: 'Analytics', icon: <FaChartLine />, count: agents.filter(a => getAgentCategory(a) === 'analytics').length },
    { id: 'development', name: 'Development', icon: <FaCode />, count: agents.filter(a => getAgentCategory(a) === 'development').length },
    { id: 'creative', name: 'Creative', icon: <FaLightbulb />, count: agents.filter(a => getAgentCategory(a) === 'creative').length },
    { id: 'social', name: 'Social', icon: <FaUsers />, count: agents.filter(a => getAgentCategory(a) === 'social').length },
    { id: 'general', name: 'General', icon: <FaBrain />, count: agents.filter(a => getAgentCategory(a) === 'general').length },
  ];

  const filteredAgents = selectedCategory === 'all' 
    ? agents 
    : agents.filter(agent => getAgentCategory(agent) === selectedCategory);

  // Reset carousel when category changes
  useEffect(() => {
    setCarouselIndex(0);
  }, [selectedCategory]);

  // Carousel navigation functions
  const nextCarousel = () => {
    setCarouselIndex((prev) => (prev + 1) % filteredAgents.length);
  };

  const prevCarousel = () => {
    setCarouselIndex((prev) => (prev - 1 + filteredAgents.length) % filteredAgents.length);
  };

  const goToCarouselIndex = (index) => {
    setCarouselIndex(index);
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'ArrowLeft') {
        prevCarousel();
      } else if (e.key === 'ArrowRight') {
        nextCarousel();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [filteredAgents.length]);



  // Touch/swipe support for mobile

  const onTouchStart = (e) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;

    if (isLeftSwipe) {
      nextCarousel();
    } else if (isRightSwipe) {
      prevCarousel();
    }
  };



  if (isLoading) {
    return (
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        gap: '24px'
      }}>
        <LoadingSpinner size="large" variant="light" />
        <p style={{ color: '#6b7280', fontSize: '16px' }}>Loading agents...</p>
      </div>
    );
  }

  return (
    <div style={{
      width: '100%',
      maxWidth: '100%',
      margin: '0',
      padding: '12px 16px 32px 16px',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      backgroundColor: '#ffffff',
      height: containerHeight,
      overflow: 'auto',
      display: 'flex',
      flexDirection: 'column',
      borderRadius: '0',
      boxShadow: 'none'
    }}>
      {/* Hero Section */}
      <div style={{
        textAlign: 'center',
        marginBottom: '16px',
        padding: '12px 0',
        flexShrink: 0
      }}>
        <div style={{
          maxWidth: '700px',
          margin: '0 auto'
        }}>
          <h1 style={{
            fontSize: '1.875rem',
            fontWeight: '600',
            color: '#1f2937',
            margin: '0 0 12px 0',
            lineHeight: '1.2',
            letterSpacing: '-0.025em'
          }}>
            Choose Your AI Agent
          </h1>
          <p style={{
            fontSize: '1rem',
            color: '#6b7280',
            margin: '0 0 16px 0',
            lineHeight: '1.5',
            maxWidth: '500px',
            marginLeft: 'auto',
            marginRight: 'auto',
            fontWeight: '400'
          }}>
            Select from our collection of specialized AI agents to help you automate tasks, 
            analyze data, and boost your productivity.
          </p>
          
          {/* Stats */}
          <div style={{
            display: 'flex',
            justifyContent: 'center',
            gap: '24px',
            marginTop: '12px',
            padding: '12px 0',
            borderTop: '1px solid #f3f4f6'
          }}>
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '8px'
            }}>
              <span style={{
                fontSize: '1.5rem',
                fontWeight: '700',
                color: '#1f2937',
                lineHeight: '1'
              }}>{agents.length}</span>
              <span style={{
                fontSize: '0.875rem',
                color: '#9ca3af',
                fontWeight: '500',
                textTransform: 'uppercase',
                letterSpacing: '0.05em'
              }}>Available Agents</span>
            </div>
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '8px'
            }}>
              <span style={{
                fontSize: '1.5rem',
                fontWeight: '700',
                color: '#1f2937',
                lineHeight: '1'
              }}>24/7</span>
              <span style={{
                fontSize: '0.875rem',
                color: '#9ca3af',
                fontWeight: '500',
                textTransform: 'uppercase',
                letterSpacing: '0.05em'
              }}>Availability</span>
            </div>
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '8px'
            }}>
              <span style={{
                fontSize: '1.5rem',
                fontWeight: '700',
                color: '#1f2937',
                lineHeight: '1'
              }}>∞</span>
              <span style={{
                fontSize: '0.875rem',
                color: '#9ca3af',
                fontWeight: '500',
                textTransform: 'uppercase',
                letterSpacing: '0.05em'
              }}>Possibilities</span>
            </div>
          </div>
        </div>
      </div>

      {/* Category Filter */}
      <div style={{
        marginBottom: '16px',
        flexShrink: 0
      }}>
        <div style={{
          display: 'flex',
          gap: '8px',
          flexWrap: 'wrap',
          justifyContent: 'center'
        }}>
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                padding: '8px 16px',
                borderRadius: '6px',
                border: selectedCategory === category.id ? '1px solid #1f2937' : '1px solid #e5e7eb',
                backgroundColor: selectedCategory === category.id ? '#1f2937' : 'white',
                color: selectedCategory === category.id ? 'white' : '#6b7280',
                cursor: 'pointer',
                fontSize: '13px',
                fontWeight: '500',
                transition: 'all 0.2s ease',
                boxShadow: selectedCategory === category.id ? '0 2px 8px rgba(31, 41, 55, 0.15)' : '0 1px 3px rgba(0, 0, 0, 0.1)'
              }}
              onMouseEnter={(e) => {
                if (selectedCategory !== category.id) {
                  e.target.style.backgroundColor = '#f9fafb';
                  e.target.style.borderColor = '#d1d5db';
                }
              }}
              onMouseLeave={(e) => {
                if (selectedCategory !== category.id) {
                  e.target.style.backgroundColor = 'white';
                  e.target.style.borderColor = '#e5e7eb';
                }
              }}
            >
              {category.icon}
              {category.name}
              <span style={{
                backgroundColor: selectedCategory === category.id ? 'rgba(255, 255, 255, 0.2)' : '#f3f4f6',
                color: selectedCategory === category.id ? 'white' : '#6b7280',
                padding: '2px 8px',
                borderRadius: '6px',
                fontSize: '12px',
                fontWeight: '500',
                minWidth: '20px',
                textAlign: 'center'
              }}>
                {category.count}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Agents Grid */}
      {/* Carousel Container */}
      <div 
        style={{
          position: 'relative',
          height: '360px',
          marginBottom: '16px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          overflow: 'hidden'
        }}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      >
        {/* Carousel Navigation Buttons */}
        <button
          onClick={prevCarousel}
          style={{
            position: 'absolute',
            left: '20px',
            top: '50%',
            transform: 'translateY(-50%)',
            zIndex: 10,
            background: 'rgba(31, 41, 55, 0.95)',
            border: '1px solid #4b5563',
            borderRadius: '50%',
            width: '44px',
            height: '44px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)'
          }}
          onMouseEnter={(e) => {
            e.target.style.background = 'rgba(31, 41, 55, 1)';
            e.target.style.transform = 'translateY(-50%) scale(1.05)';
          }}
          onMouseLeave={(e) => {
            e.target.style.background = 'rgba(31, 41, 55, 0.95)';
            e.target.style.transform = 'translateY(-50%) scale(1)';
          }}
        >
          <FaArrowRight style={{ transform: 'rotate(180deg)', color: '#d1d5db' }} />
        </button>

        <button
          onClick={nextCarousel}
          style={{
            position: 'absolute',
            right: '20px',
            top: '50%',
            transform: 'translateY(-50%)',
            zIndex: 10,
            background: 'rgba(31, 41, 55, 0.95)',
            border: '1px solid #4b5563',
            borderRadius: '50%',
            width: '44px',
            height: '44px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)'
          }}
          onMouseEnter={(e) => {
            e.target.style.background = 'rgba(31, 41, 55, 1)';
            e.target.style.transform = 'translateY(-50%) scale(1.05)';
          }}
          onMouseLeave={(e) => {
            e.target.style.background = 'rgba(31, 41, 55, 0.95)';
            e.target.style.transform = 'translateY(-50%) scale(1)';
          }}
        >
          <FaArrowRight style={{ color: '#d1d5db' }} />
        </button>



        {/* Carousel Cards */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '24px',
          height: '100%',
          width: '100%'
        }}>
          {filteredAgents.map((agent, index) => {
            const distance = Math.abs(index - carouselIndex);
            const isMain = index === carouselIndex;
            const isLeft = index < carouselIndex;
            const isRight = index > carouselIndex;
            
            let transform = '';
            let scale = 1;
            let opacity = 1;
            let zIndex = 1;
            
            if (isMain) {
              transform = 'translateX(0) scale(1)';
              scale = 1;
              opacity = 1;
              zIndex = 10;
            } else if (isLeft) {
              transform = `translateX(-${(distance * 140)}px) scale(${Math.max(0.75, 1 - distance * 0.08)})`;
              scale = Math.max(0.75, 1 - distance * 0.08);
              opacity = Math.max(0.4, 1 - distance * 0.15);
              zIndex = 5 - distance;
            } else if (isRight) {
              transform = `translateX(${distance * 140}px) scale(${Math.max(0.75, 1 - distance * 0.08)})`;
              scale = Math.max(0.75, 1 - distance * 0.08);
              opacity = Math.max(0.4, 1 - distance * 0.15);
              zIndex = 5 - distance;
            }

            return (
              <div 
                key={agent.id} 
                style={{
                  background: isMain ? '#1f2937' : '#374151',
                  borderRadius: '12px',
                  padding: '20px',
                  border: isMain ? '2px solid #3b82f6' : '1px solid #4b5563',
                  cursor: 'pointer',
                  transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
                  transform: transform,
                  scale: scale,
                  opacity: opacity,
                  boxShadow: isMain 
                    ? '0 20px 40px rgba(59, 130, 246, 0.25)' 
                    : '0 8px 16px rgba(0, 0, 0, 0.2)',
                  position: 'absolute',
                  width: '380px',
                  height: '260px',
                  display: 'flex',
                  flexDirection: 'column',
                  zIndex: zIndex,
                  filter: isMain ? 'none' : 'blur(1px)'
                }}
                onClick={() => onAgentSelect(agent)}
                onMouseEnter={() => setHoveredAgent(agent.id)}
                onMouseLeave={() => setHoveredAgent(null)}
              >
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'flex-start',
                  marginBottom: '16px'
                }}>
                  <div style={{
                    width: '48px',
                    height: '48px',
                    borderRadius: '10px',
                    background: isMain ? '#3b82f6' : '#4b5563',
                    border: isMain ? '2px solid #60a5fa' : '1px solid #6b7280',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: isMain ? 'white' : '#d1d5db',
                    fontSize: '20px',
                    transition: 'all 0.3s ease'
                  }}>
                    {getAgentIcon(agent.name || agent.id)}
                  </div>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    padding: '6px 12px',
                    backgroundColor: isMain ? '#10b981' : '#f3f4f6',
                    borderRadius: '8px',
                    border: isMain ? '1px solid #059669' : '1px solid #e5e7eb'
                  }}>
                    <div style={{
                      width: '6px',
                      height: '6px',
                      backgroundColor: isMain ? 'white' : '#10b981',
                      borderRadius: '50%'
                    }} />
                    <span style={{
                      fontSize: '11px',
                      fontWeight: '600',
                      color: isMain ? 'white' : '#6b7280'
                    }}>Available</span>
                  </div>
                </div>
                
                <div style={{
                  marginBottom: '16px',
                  flex: 1,
                  display: 'flex',
                  flexDirection: 'column'
                }}>
                  <h3 style={{
                    fontSize: '1.1rem',
                    fontWeight: '700',
                    color: isMain ? 'white' : '#d1d5db',
                    margin: '0 0 8px 0',
                    lineHeight: '1.3',
                    transition: 'color 0.3s ease'
                  }}>
                    {agent.name || agent.id}
                  </h3>
                  <p style={{
                    fontSize: '13px',
                    color: isMain ? '#d1d5db' : '#9ca3af',
                    margin: 0,
                    lineHeight: '1.4',
                    flex: 1,
                    overflow: 'hidden',
                    display: '-webkit-box',
                    WebkitLineClamp: 3,
                    WebkitBoxOrient: 'vertical',
                    transition: 'color 0.3s ease'
                  }}>
                    {getAgentDescription(agent)}
                  </p>
                </div>

                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginTop: 'auto'
                }}>
                  <div style={{
                    display: 'flex',
                    gap: '6px'
                  }}>
                    <span style={{
                      padding: '3px 8px',
                      backgroundColor: isMain ? '#3b82f6' : '#4b5563',
                      color: 'white',
                      borderRadius: '6px',
                      fontSize: '10px',
                      fontWeight: '600',
                      border: isMain ? '1px solid #60a5fa' : '1px solid #6b7280',
                      transition: 'all 0.3s ease'
                    }}>
                      AI
                    </span>
                    {agent.tags && agent.tags.slice(0, 2).map((tag, tagIndex) => (
                      <span key={tagIndex} style={{
                        padding: '3px 8px',
                        backgroundColor: isMain ? '#4b5563' : '#374151',
                        color: isMain ? '#d1d5db' : '#9ca3af',
                        borderRadius: '6px',
                        fontSize: '10px',
                        fontWeight: '500',
                        border: isMain ? '1px solid #6b7280' : '1px solid #4b5563',
                        transition: 'all 0.3s ease'
                      }}>
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                    color: isMain ? '#60a5fa' : '#9ca3af',
                    fontWeight: '600',
                    fontSize: '12px',
                    transition: 'all 0.3s ease',
                    transform: hoveredAgent === agent.id ? 'translateX(4px)' : 'translateX(0)'
                  }}>
                    <span>Start Chat</span>
                    <FaArrowRight style={{ fontSize: '11px' }} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Carousel Indicators */}
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        gap: '12px',
        marginBottom: '16px'
      }}>
        {/* Agent counter */}
        <div style={{
          fontSize: '14px',
          color: '#6b7280',
          fontWeight: '500'
        }}>
          {carouselIndex + 1} of {filteredAgents.length}
        </div>
        
        {/* Dot indicators */}
        <div style={{
          display: 'flex',
          gap: '8px'
        }}>
          {filteredAgents.map((_, index) => (
            <button
              key={index}
              onClick={() => goToCarouselIndex(index)}
              style={{
                width: index === carouselIndex ? '24px' : '8px',
                height: '8px',
                borderRadius: '4px',
                background: index === carouselIndex ? '#3b82f6' : '#d1d5db',
                border: 'none',
                cursor: 'pointer',
                transition: 'all 0.3s ease'
              }}
            />
          ))}
        </div>
      </div>





    </div>
  );
};

export default AgentSelection;
