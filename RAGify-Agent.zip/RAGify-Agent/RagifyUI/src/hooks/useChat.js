import { useState, useRef } from 'react';
import searchService from '../services/searchService';
import { stripFence } from '../utils/cleanMarkdown';

export default function useChat() {
  const [messages, setMessages] = useState([]);
  const [query, setQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [selectedCitation, setSelectedCitation] = useState(null);
  const chatContainerRef = useRef(null);

  const handleSearch = async (searchQuery) => {
    try {
      // Handle both string input (from ChatInput) and event input (from form)
      const queryText = typeof searchQuery === 'string' ? searchQuery : query;
      
      if (!queryText.trim() || isSearching) {
        return;
      }
      
      const userMessage = {
        id: Date.now(),
        role: 'user',
        content: queryText,
        timestamp: new Date().toISOString()
      };
      setMessages(prev => [...prev, userMessage]);
      setIsSearching(true);
      
      try {
        const loadingMessage = {
          id: Date.now() + 1,
          role: 'system',
          content: 'Searching...',
          isLoading: true,
          timestamp: new Date().toISOString()
        };
        setMessages(prev => [...prev, loadingMessage]);
        
        setTimeout(() => {
          if (chatContainerRef.current) {
            chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
          }
        }, 100);
        
        // Clear the query if it was passed as a string
        if (typeof searchQuery === 'string') {
          setQuery('');
        }
        
        const response = await searchService.searchQuery(userMessage.content);
        
        setMessages(prev => prev.filter(msg => msg.id !== loadingMessage.id));
        
        const clean = stripFence(response.response_text || "I couldn't find an answer to your query.");
        const aiMessage = {
          id: Date.now() + 2,
          role: 'assistant',
          content: clean,
          timestamp: new Date().toISOString(),
          citations: Array.isArray(response.source_documents)
            ? response.source_documents.map((doc, idx) => ({
                title: doc.file_name,
                snippet: doc.chunk_text,
                page: doc.page || undefined,
                similarity: doc.similarity_score,
                dataset_object_id: doc.dataset_object_id
              }))
            : []
        };
        setMessages(prev => [...prev, aiMessage]);
      } catch (error) {
        setMessages(prev => prev.filter(msg => !msg.isLoading));
        const errorMessage = {
          id: Date.now() + 3,
          role: 'system',
          content: `Error: ${error.message || 'Failed to search documents'}`,
          isError: true,
          timestamp: new Date().toISOString()
        };
        setMessages(prev => [...prev, errorMessage]);
      } finally {
        setIsSearching(false);
        setTimeout(() => {
          if (chatContainerRef.current) {
            chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
          }
        }, 100);
      }
    } catch (error) {
      setIsSearching(false);
    }
  };

  const handleCitationClick = (citation) => setSelectedCitation(citation);
  const closeCitationModal = () => setSelectedCitation(null);

  return {
    messages,
    query,
    setQuery,
    isSearching,
    handleSearch,
    chatContainerRef,
    selectedCitation,
    handleCitationClick,
    closeCitationModal
  };
}
