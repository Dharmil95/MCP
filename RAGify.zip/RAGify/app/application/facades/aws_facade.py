"""AWS S3 Facade for clean abstraction of AWS operations."""

import io
import logging
from typing import Dict, List, Optional, Any

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

logger = logging.getLogger(__name__)


class AWSS3Facade:
    """Facade for AWS S3 operations providing clean abstraction."""

    def __init__(self):
        """Initialize the AWS S3 facade."""
        pass

    async def validate_credentials(
        self,
        aws_access_key_id: str,
        aws_secret_access_key: str,
        bucket_name: str,
        folder_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Validate AWS credentials and S3 access.

        Args:
            aws_access_key_id: AWS access key ID
            aws_secret_access_key: AWS secret access key
            bucket_name: S3 bucket name
            folder_path: Optional folder path within bucket

        Returns:
            Dict containing validation results
        """
        logger.info(f"AWS facade validate_credentials called with:")
        logger.info(f"  aws_access_key_id type: {type(aws_access_key_id)}, value: {repr(aws_access_key_id)}")
        logger.info(f"  aws_secret_access_key type: {type(aws_secret_access_key)}")
        logger.info(f"  bucket_name type: {type(bucket_name)}, value: {repr(bucket_name)}")
        logger.info(f"  folder_path type: {type(folder_path)}, value: {repr(folder_path)}")
        
        try:
            logger.info(f"AWS validation called with bucket_name: '{bucket_name}', folder_path: '{folder_path}'")
            
            # Clean up bucket name if it has trailing slashes or invalid characters
            if bucket_name:
                original_bucket = bucket_name
                bucket_name = bucket_name.strip().rstrip("/")
                if original_bucket != bucket_name:
                    logger.warning(f"Cleaned bucket name from '{original_bucket}' to '{bucket_name}'")
            
            # Validate bucket name format before making AWS calls
            if not bucket_name or "/" in bucket_name or not bucket_name.replace("-", "").replace("_", "").replace(".", "").isalnum():
                logger.error(f"Invalid bucket name received: '{bucket_name}'. Bucket names must be valid.")
                return {
                    "status": "invalid",
                    "message": f"Invalid bucket name: '{bucket_name}'. Please check your S3 configuration.",
                    "bucket_accessible": False,
                    "folder_accessible": False,
                }
            
            # Create S3 client with provided credentials
            s3_client = boto3.client(
                "s3",
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
            )

            # Test bucket access
            s3_client.head_bucket(Bucket=bucket_name)

            # Test folder access if provided
            accessible_files = []
            if folder_path and isinstance(folder_path, str):
                response = s3_client.list_objects_v2(
                    Bucket=bucket_name, Prefix=folder_path, MaxKeys=5
                )
                accessible_files = [
                    obj["Key"] for obj in response.get("Contents", [])
                ]

            return {
                "status": "valid",
                "message": "AWS credentials are valid and bucket is accessible",
                "bucket_accessible": True,
                "folder_accessible": bool(folder_path is None or accessible_files),
                "sample_files": accessible_files[:3],  # Return first 3 files as sample
            }

        except NoCredentialsError:
            return {
                "status": "invalid",
                "message": "Invalid AWS credentials",
                "bucket_accessible": False,
                "folder_accessible": False,
            }
        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code == "403":
                return {
                    "status": "invalid",
                    "message": "Access denied to bucket or folder",
                    "bucket_accessible": False,
                    "folder_accessible": False,
                }
            elif error_code == "404":
                return {
                    "status": "invalid",
                    "message": "Bucket not found",
                    "bucket_accessible": False,
                    "folder_accessible": False,
                }
            else:
                return {
                    "status": "invalid",
                    "message": f"AWS error: {e.response['Error']['Message']}",
                    "bucket_accessible": False,
                    "folder_accessible": False,
                }
        except Exception as e:
            logger.error(f"Unexpected error validating AWS credentials: {str(e)}")
            return {
                "status": "invalid",
                "message": f"Unexpected error: {str(e)}",
                "bucket_accessible": False,
                "folder_accessible": False,
            }

    async def list_bucket_files(
        self,
        aws_access_key_id: str,
        aws_secret_access_key: str,
        bucket_name: str,
        folder_path: Optional[str] = None,
        file_extensions: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        List files in S3 bucket folder.

        Args:
            aws_access_key_id: AWS access key ID
            aws_secret_access_key: AWS secret access key
            bucket_name: S3 bucket name
            folder_path: Folder path within bucket
            file_extensions: Optional list of allowed file extensions

        Returns:
            List of file information dictionaries
        """
        try:
            s3_client = boto3.client(
                "s3",
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
            )

            # Ensure folder_path is a valid string
            if not folder_path or not isinstance(folder_path, str):
                folder_path = ""

            files = []
            paginator = s3_client.get_paginator("list_objects_v2")
            
            for page in paginator.paginate(Bucket=bucket_name, Prefix=folder_path):
                for obj in page.get("Contents", []):
                    file_key = obj["Key"]
                    
                    # Skip if it's a folder (ends with /)
                    if file_key.endswith("/"):
                        continue
                    
                    # Filter by file extensions if provided
                    if file_extensions:
                        file_ext = file_key.lower().split(".")[-1]
                        if file_ext not in [ext.lower().strip(".") for ext in file_extensions]:
                            continue
                    
                    files.append({
                        "bucket": bucket_name,
                        "key": file_key,
                        "size": obj["Size"],
                        "last_modified": obj["LastModified"].isoformat(),
                        "filename": file_key.split("/")[-1],
                        "extension": f".{file_key.lower().split('.')[-1]}" if "." in file_key else "",
                    })

            return files

        except Exception as e:
            logger.error(f"Error listing S3 files: {str(e)}")
            raise

    async def download_file(
        self,
        aws_access_key_id: str,
        aws_secret_access_key: str,
        bucket_name: str,
        file_key: str,
    ) -> bytes:
        """
        Download a file from S3.

        Args:
            aws_access_key_id: AWS access key ID
            aws_secret_access_key: AWS secret access key
            bucket_name: S3 bucket name
            file_key: S3 object key

        Returns:
            File content as bytes
        """
        try:
            s3_client = boto3.client(
                "s3",
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
            )

            response = s3_client.get_object(Bucket=bucket_name, Key=file_key)
            return response["Body"].read()

        except Exception as e:
            logger.error(f"Error downloading file from S3: {str(e)}")
            raise

    async def upload_file(
        self,
        aws_access_key_id: str,
        aws_secret_access_key: str,
        bucket_name: str,
        file_obj: io.BytesIO,
        file_name: str,
        folder_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Upload a file to S3.

        Args:
            aws_access_key_id: AWS access key ID
            aws_secret_access_key: AWS secret access key
            bucket_name: S3 bucket name
            file_obj: File object to upload
            file_name: Name of the file
            folder_path: Optional folder path to upload to

        Returns:
            Upload result dictionary
        """
        try:
            s3_client = boto3.client(
                "s3",
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
            )

            # Construct the S3 key
            s3_key = file_name
            if folder_path:
                s3_key = f"{folder_path.rstrip('/')}/{file_name}"

            # Upload the file
            s3_client.upload_fileobj(file_obj, bucket_name, s3_key)

            return {
                "status": "success",
                "message": "File uploaded successfully",
                "s3_key": s3_key,
                "bucket": bucket_name,
            }

        except Exception as e:
            logger.error(f"Error uploading file to S3: {str(e)}")
            return {
                "status": "error",
                "message": f"Failed to upload file: {str(e)}",
            }
