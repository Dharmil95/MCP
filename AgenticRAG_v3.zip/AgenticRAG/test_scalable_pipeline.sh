#!/bin/bash
# Test script for the scalable RAG pipeline

echo "🚀 Testing Scalable RAG Pipeline"
echo "=================================="

# Set environment variables
export OPENAI_API_KEY="your-openai-api-key-here"

# 1. Start services
echo "📦 Starting services..."
docker-compose up -d

# 2. Wait for services to be ready
echo "⏳ Waiting for services to be ready..."
sleep 30

# 3. Test health check
echo "🔍 Testing health check..."
curl -s http://localhost:8000/health | jq .

# 4. Register a test user
echo "👤 Registering test user..."
curl -X POST http://localhost:8000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "TestPassword123!"
  }' | jq .

# 5. Login to get token
echo "🔑 Logging in..."
LOGIN_RESPONSE=$(curl -s -X POST http://localhost:8000/api/v1/auth/jwt/login \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=test@example.com&password=TestPassword123!")

ACCESS_TOKEN=$(echo $LOGIN_RESPONSE | jq -r '.access_token')
echo "Token: $ACCESS_TOKEN"

# 6. Create a dataset
echo "📊 Creating dataset..."
DATASET_RESPONSE=$(curl -s -X POST http://localhost:8000/api/v1/datasets \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test Dataset",
    "description": "Test dataset for scalable processing",
    "aws_s3_folder_path": "s3://test-bucket/docs/",
    "aws_access_key_id": "test-key",
    "aws_secret_access_key": "test-secret",
    "embedding_model": "text-embedding-ada-002",
    "chunking_strategy": "recursive_character",
    "chunking_parameters": {
      "chunk_size": 512,
      "chunk_overlap": 50
    },
    "allowed_file_types": [".pdf", ".txt", ".md"]
  }')

echo "Dataset created:"
echo $DATASET_RESPONSE | jq .

DATASET_ID=$(echo $DATASET_RESPONSE | jq -r '.id')
echo "Dataset ID: $DATASET_ID"

# 7. Check Celery worker status
echo "🔧 Checking Celery worker status..."
docker-compose logs celery_worker | tail -10

# 8. Check Flower monitoring
echo "🌸 Flower monitoring available at: http://localhost:5555"

# 9. Monitor dataset processing
echo "📈 You can monitor processing at:"
echo "  - Flower: http://localhost:5555"
echo "  - pgAdmin: http://localhost:5050"
echo "  - API Health: http://localhost:8000/health"

echo "✅ Test completed!"
echo "Next steps:"
echo "1. Check Flower dashboard for task monitoring"
echo "2. Add your OpenAI API key to process real documents"
echo "3. Test with real S3 buckets and files"
