import importlib
import json
import logging
import os
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError
from datetime import datetime, timezone
from typing import Dict, List, Optional

from fastapi import APIRouter, BackgroundTasks, Body, Depends, HTTPException, Request, status

from app.core.config import settings
from app.schemas import SuccessResponse
from app.utils.auth import get_current_user
from app.utils.langfuse_obs import get_langfuse_client, observe_fn
from app.utils.session_store import SessionStore

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/agents", tags=["agents"])

# In-memory task store (replace with Redis in production)
task_store: Dict[str, Dict] = {}


class AgentRegistry:
    """Simple in-memory registry loading LangGraph workflows from a folder.

    Expected agent module contract in `app/agents/<agent_name>.py`:
      - exposes `agent_id: str` or `AGENT_ID`
      - exposes `description: str` or `DESCRIPTION`
      - exposes `graph` (a LangGraph `CompiledGraph` or callable interface)
      - optional `invoke(input: dict, config: dict) -> dict` convenience wrapper
    """

    def __init__(self, agents_dir: Optional[str] = None) -> None:
        self._agents_dir = agents_dir or settings.agents_directory
        self._agents: Dict[str, Dict] = {}

    def refresh(self) -> None:
        self._agents.clear()
        directory = self._agents_dir
        if not os.path.isdir(directory):
            logger.warning("Agents directory not found: %s", directory)
            return
        for file_name in os.listdir(directory):
            if not file_name.endswith(".py") or file_name.startswith("_"):
                continue
            module_name = file_name[:-3]
            import_path = f"app.agents.{module_name}"
            try:
                module = importlib.import_module(import_path)
                agent_id = getattr(module, "agent_id", getattr(module, "AGENT_ID", module_name))
                description = getattr(module, "description", getattr(module, "DESCRIPTION", ""))
                graph = getattr(module, "graph", None)
                invoke_fn = getattr(module, "invoke", None)
                if graph is None and invoke_fn is None:
                    logger.warning("Module %s does not expose 'graph' or 'invoke'", import_path)
                    continue
                self._agents[str(agent_id)] = {
                    "id": str(agent_id),
                    "description": str(description),
                    "graph": graph,
                    "invoke": invoke_fn,
                }
            except Exception as exc:
                logger.exception("Failed to import agent module %s: %s", import_path, exc)

    def list_agents(self) -> List[Dict]:
        if not self._agents:
            self.refresh()
        return [
            {"id": agent["id"], "description": agent.get("description", "")}
            for agent in self._agents.values()
        ]

    def get(self, agent_id: str) -> Optional[Dict]:
        if not self._agents:
            self.refresh()
        return self._agents.get(agent_id)


registry = AgentRegistry()


def run_agent_with_timeout(agent, payload, timeout_seconds=60):
    """Run agent with timeout using ThreadPoolExecutor"""
    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(agent, payload)
        try:
            result = future.result(timeout=timeout_seconds)
            return result
        except FutureTimeoutError:
            logger.error(f"Agent execution timed out after {timeout_seconds} seconds")
            raise TimeoutError(f"Agent execution timed out after {timeout_seconds} seconds")
        except Exception as e:
            logger.error(f"Agent execution failed: {e}")
            raise e


def run_agent_task(task_id: str, agent_id: str, payload: Dict, auth_header: str = None):
    """Background task to run agent execution"""
    try:
        task_store[task_id]["status"] = "running"
        task_store[task_id]["started_at"] = datetime.now(timezone.utc).isoformat()
        
        agent = registry.get(agent_id)
        if not agent:
            task_store[task_id]["status"] = "failed"
            task_store[task_id]["error"] = "Agent not found"
            return

        # Forward auth header if provided
        if auth_header and "auth_header" not in payload:
            payload["auth_header"] = auth_header

        # Prefer explicit invoke wrapper; fallback to graph.invoke
        invoke = agent.get("invoke")
        if invoke is not None:
            try:
                result = run_agent_with_timeout(invoke, payload, timeout_seconds=60)
                task_store[task_id]["status"] = "completed"
                task_store[task_id]["result"] = result
                task_store[task_id]["completed_at"] = datetime.now(timezone.utc).isoformat()
            except TimeoutError:
                task_store[task_id]["status"] = "failed"
                task_store[task_id]["error"] = "Agent execution timed out after 60 seconds"
            except Exception as e:
                task_store[task_id]["status"] = "failed"
                task_store[task_id]["error"] = f"Agent execution failed: {str(e)}"
            return

        graph = agent.get("graph")
        if graph is None:
            task_store[task_id]["status"] = "failed"
            task_store[task_id]["error"] = "Agent has no invokable interface"
            return

        # LangGraph CompiledGraph supports .invoke(input, config={})
        config = {}
        result = graph.invoke(payload, config=config)
        task_store[task_id]["status"] = "completed"
        task_store[task_id]["result"] = result
        task_store[task_id]["completed_at"] = datetime.now(timezone.utc).isoformat()
        
    except Exception as e:
        logger.error(f"Background task failed: {e}")
        task_store[task_id]["status"] = "failed"
        task_store[task_id]["error"] = str(e)


@router.get("", response_model=List[Dict[str, str]])
async def list_agents(_: dict = Depends(get_current_user)):
    return registry.list_agents()


@router.post("/register", response_model=SuccessResponse)
async def refresh_agents(_: dict = Depends(get_current_user)):
    registry.refresh()
    return SuccessResponse(message="Agents refreshed", data={"count": len(registry.list_agents())})


@router.post("/{agent_id}/interact")
async def interact_with_agent(
    agent_id: str,
    request: Request,
    background_tasks: BackgroundTasks,
    payload: Dict = Body(default_factory=dict),
    user=Depends(get_current_user),
):
    agent = registry.get(agent_id)
    if not agent:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Agent not found")

    # Generate task ID for tracking
    task_id = str(uuid.uuid4())
    
    # Initialize task in store
    task_store[task_id] = {
        "id": task_id,
        "agent_id": agent_id,
        "status": "pending",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "payload": payload,
    }

    # Get auth header for background task
    auth_header = request.headers.get("authorization")

    # Add background task
    background_tasks.add_task(run_agent_task, task_id, agent_id, payload, auth_header)

    # Persist session state if session_id provided
    session_id = str(payload.get("session_id") or payload.get("sessionId") or "")
    if session_id:
        state = SessionStore.get_session(session_id)
        if state is None:
            SessionStore.create_session(session_id)
            state = {}
        history = list(state.get("history", []))
        now_iso = datetime.now(timezone.utc).isoformat()
        history.append({
            "role": "user",
            "agent": agent_id,
            "payload": payload,
            "timestamp": now_iso,
            "task_id": task_id,
        })
        SessionStore.update_session(session_id, {"history": history})

    return {
        "task_id": task_id,
        "status": "pending",
        "message": f"Agent {agent_id} task started. Use /agents/tasks/{task_id} to check status."
    }


@router.get("/tasks/{task_id}")
async def get_task_status(task_id: str, _: dict = Depends(get_current_user)):
    """Get the status of a background agent task"""
    if task_id not in task_store:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Task not found")
    
    task = task_store[task_id]
    
    # If task is completed, update session state
    if task["status"] == "completed" and "result" in task:
        session_id = str(task.get("payload", {}).get("session_id") or task.get("payload", {}).get("sessionId") or "")
        if session_id:
            state = SessionStore.get_session(session_id)
            if state:
                history = list(state.get("history", []))
                now_iso = datetime.now(timezone.utc).isoformat()
                history.append({
                    "role": "agent",
                    "agent": task["agent_id"],
                    "response": task["result"],
                    "timestamp": now_iso,
                    "task_id": task_id,
                })
                SessionStore.update_session(session_id, {"history": history, "last_result": task["result"]})
    
    return task


@router.delete("/tasks/{task_id}")
async def cancel_task(task_id: str, _: dict = Depends(get_current_user)):
    """Cancel a pending or running task"""
    if task_id not in task_store:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Task not found")
    
    task = task_store[task_id]
    if task["status"] in ["completed", "failed"]:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Cannot cancel completed or failed task")
    
    task["status"] = "cancelled"
    task["cancelled_at"] = datetime.now(timezone.utc).isoformat()
    
    return {"message": f"Task {task_id} cancelled successfully"}


